# Kira — Publisher Intelligence Agent

CRM מלא לפבלישר outreach, מותאם ל-Railway. Migration מ-Manus.

---

## Stack

- **Frontend:** React 19 + TypeScript + tRPC + Tailwind + shadcn/ui + wouter
- **Backend:** Node 20 + Express + tRPC + Drizzle ORM
- **DB:** MySQL
- **LLM:** Anthropic Claude (`claude-sonnet-4-5-20250929` by default)
- **Browser automation:** Playwright + system Chromium
- **Email:** Gmail OAuth (`googleapis`)
- **Notifications:** Telegram Bot (אופציונלי)
- **Auth:** Simple password + JWT cookie

---

## מה הוחלף בהגירה מ-Manus

| מה | היה ב-Manus | עכשיו |
|---|---|---|
| LLM | `forge.manus.im` (Gemini 2.5 Flash) | Anthropic Claude ישיר |
| Notifications | `forge.manus.im` notification API | Telegram Bot |
| Auth | Manus OAuth (`/app-auth`) | Simple password + JWT |
| Gmail | `manus-mcp-cli` shell-out | `googleapis` SDK |
| Playwright | `manus-mcp-cli` shell-out | `playwright` ישיר |
| Storage | `forge.manus.im` proxy | מבוטל (no-op) |
| Vite plugin | `vite-plugin-manus-runtime` | הוסר |

---

## Deploy ל-Railway (מהאייפון, 5 דקות)

### 1. צור פרויקט חדש ב-Railway

1. תיכנס ל-[railway.app](https://railway.app) (תומך ב-GitHub login)
2. **New Project** → **Deploy from GitHub repo**
3. בחר את ה-repo שלך (`NiziNizi1/Agent...`)
4. Railway יזהה את ה-`Dockerfile` ו-`railway.json` אוטומטית

### 2. הוסף MySQL

1. בתוך הפרויקט: **+ New** → **Database** → **Add MySQL**
2. Railway יוצר אוטומטית את ה-`DATABASE_URL` ומחבר אותו ל-app

### 3. הגדר Env Variables

ב-tab **Variables** של ה-service (לא ה-DB), הדבק את אלה:

```env
ANTHROPIC_API_KEY=sk-ant-...
SESSION_SECRET=<generate-with-openssl-rand-base64-32>
APP_PASSWORD=<choose-strong-password>

# אופציונלי — Snov.io
SNOV_CLIENT_ID=
SNOV_CLIENT_SECRET=

# אופציונלי — Gmail (אם רוצה לשלוח מיילים)
GOOGLE_CLIENT_ID=
GOOGLE_CLIENT_SECRET=
GOOGLE_REFRESH_TOKEN=
GOOGLE_SENDER_EMAIL=niv.zilberberg@ad-maven.com

# אופציונלי — Telegram
TELEGRAM_BOT_TOKEN=
TELEGRAM_CHAT_ID=
```

לא צריך להגדיר `DATABASE_URL` — Railway עושה את זה אוטומטית.
לא צריך להגדיר `PORT` — Railway קובע אותו.

### 4. Deploy

Railway יבנה את ה-Docker image (~3-5 דקות בפעם הראשונה כי הוא מתקין Chromium).
כשהבילד מסתיים, **Generate Domain** ב-Settings → Networking.

### 5. Push DB Schema (פעם אחת)

באייפון:
1. תיכנס ל-Railway
2. בחר את ה-service של Kira → **Settings** → **One-off command** (או Deployments → ⋯ → Run command)
3. הרץ: `npx drizzle-kit push`

זה יוצר את כל הטבלאות ב-MySQL.

### 6. Login

תפתח את ה-domain שיצרת. תקבל את דף ה-Login. הזן את ה-`APP_PASSWORD` שהגדרת ב-step 3.

---

## Scraping Engine — Apify + Playwright

Kira משתמש ב-**dual-stack scraping** עם routing אוטומטי:

```
┌──────────────────┐
│  scrape.contacts │  ──┐
│  scrape.ads      │    │
└──────────────────┘    │
                        ▼
              ┌──────────────────┐
              │   Orchestrator   │
              └────────┬─────────┘
                       │
        ┌──────────────┴──────────────┐
        ▼                             ▼
   ┌─────────┐                  ┌──────────────┐
   │  Apify  │   fallback ───▶  │  Playwright  │
   │  cloud  │   on failure     │  (in-process)│
   └─────────┘                  └──────────────┘
```

**ב-Production (אם הגדרת `APIFY_API_KEY`):** כל בקשת scraping רצה דרך Apify. אם Apify לא זמין, נכשל, או החזיר שום דבר שימושי — נופל אוטומטית ל-Playwright.

**ב-Local Dev (בלי Apify key):** ישר ל-Playwright. אין צורך לשנות שום קוד.

**Strategy override** דרך `SCRAPER_STRATEGY` env var:

| ערך | התנהגות | מתי להשתמש |
|---|---|---|
| `auto` (default) | Apify-first, Playwright fallback | Production |
| `apify` | רק Apify, בלי fallback | קונטרול עלויות |
| `playwright` | רק Playwright | Local dev / debug |
| `merge` | שני המנועים במקביל, ממוזג | מקרי edge / אנליזה עמוקה |

**Per-call override** ב-tRPC:

```ts
trpc.scrape.contacts.mutate({ publisherId, strategy: "merge" });
```

---

## API Endpoints (Smart Scraping)

- `trpc.scrape.contacts({ publisherId, strategy? })` — emails + phones + socials, persisted
- `trpc.scrape.ads({ publisherId, strategy? })` — ad networks, persisted to `ad_detections`
- `trpc.scrape.status()` — debug: returns `{ apifyConfigured, strategy, ... }`

ה-routes הישנים (`trpc.apify.*`, `trpc.publishers.scrapeWebsite`) עדיין קיימים לאחור-תאימות, אבל מומלץ להעביר את ה-frontend לשתמש ב-`scrape.*`.

---

## LLM Cache (Cost Control)

כל קריאה ל-Claude נכנסת אוטומטית למטמון MySQL. בקריאה זהה (אותו model + system + messages + schema) המערכת מחזירה את התשובה הקאשד במקום לקרוא ל-API שוב.

**מתי הקאש פעיל:**
- רק לבקשות דטרמיניסטיות (בלי tools, בלי `bypassCache: true`)
- TTL ברירת מחדל: 30 ימים
- Background cleanup רץ אוטומטית פעם ביום

**למה זה חשוב:**

על 1000 publishers, ~60% מקריאות ה-LLM הן זהות (אותם prompts ל-extraction, classification, similar-site discovery). הקאש חוסך ~$30-60 בכל ריצה.

**ניהול:**

```ts
// סטטיסטיקות חיסכון:
trpc.cache.stats.query()
// → { totalEntries: 412, totalHits: 287, estimatedCostSavedUSD: 41.23, byModel: [...] }

// ניקוי אחרי שינוי prompts (כדי שהקאש לא יחזיר תשובות ישנות):
trpc.cache.clear.mutate()
```

**כיבוי זמני** (לדוגמה במהלך פיתוח prompts):

```env
LLM_CACHE_DISABLED=true
```

**Per-call bypass:**

```ts
await invokeLLM({ messages, bypassCache: true })  // לא נכנס ל-cache
await invokeLLM({ messages, cacheTtlMs: 60_000 })  // TTL מותאם של 60 שניות
```

ה-Cache יושב בטבלת `llm_cache` ב-MySQL. אחרי deploy ראשון תריץ `npx drizzle-kit push` (כפי שמתואר בהוראות הdeploy) - זה ייצור את הטבלה אוטומטית.

---

## Local Development

```bash
# Install deps (pnpm 10+)
pnpm install

# Copy env template
cp .env.example .env

# Start MySQL locally (or point DATABASE_URL to a remote MySQL)
# Then push schema:
pnpm db:push

# Run dev server
pnpm dev
```

App will be at `http://localhost:3000`.

---

## Gmail OAuth Setup (אם רוצה לשלוח מיילים)

1. לך ל-[console.cloud.google.com](https://console.cloud.google.com/) → Create new project
2. **APIs & Services** → **Library** → enable **Gmail API**
3. **Credentials** → **+ CREATE CREDENTIALS** → **OAuth 2.0 Client ID**
   - Type: **Desktop app**
4. הורד את ה-JSON, תיקח ממנו `client_id` ו-`client_secret`
5. לך ל-[OAuth 2.0 Playground](https://developers.google.com/oauthplayground/):
   - לחץ על ⚙️ בפינה הימנית → ✅ **Use your own OAuth credentials** → הזן client id + secret
   - בצד שמאל, scope: הקלד `https://www.googleapis.com/auth/gmail.send` → **Authorize APIs**
   - אשר עם החשבון שממנו תרצה לשלוח (`niv.zilberberg@ad-maven.com`)
   - **Exchange authorization code for tokens** → תקבל `refresh_token`
6. תכניס ב-Railway: `GOOGLE_CLIENT_ID`, `GOOGLE_CLIENT_SECRET`, `GOOGLE_REFRESH_TOKEN`, `GOOGLE_SENDER_EMAIL`

---

## Telegram Bot Setup (אופציונלי)

1. בטלגרם, פתח שיחה עם `@BotFather` → `/newbot` → תן שם → תקבל token
2. שלח לבוט שלך הודעה כלשהי (`/start`)
3. פתח: `https://api.telegram.org/bot<YOUR_TOKEN>/getUpdates`
4. תמצא `"chat":{"id":123456789}` — זה ה-`TELEGRAM_CHAT_ID` שלך
5. תוסיף ב-Railway: `TELEGRAM_BOT_TOKEN`, `TELEGRAM_CHAT_ID`

---

## Health Check

`GET /api/health` → `{ ok: true, ts: ... }` — רץ גם בלי DB. משמש את Railway כ-liveness probe.

## Auth Endpoints

- `POST /api/auth/login` — body: `{ "password": "..." }` → סט cookie אם הסיסמה נכונה
- `POST /api/auth/logout` — ניקוי cookie
- `GET  /api/auth/me` — `{ authenticated: boolean }`

---

## Troubleshooting

**Container won't start, error mentions Chromium:**
ה-image מתקין `chromium` ב-`/usr/bin/chromium` ומגדיר `PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH` אוטומטית. אם הבעיה ב-puppeteer-core, בדוק ש-`PUPPETEER_EXECUTABLE_PATH=/usr/bin/chromium` קיים (מוגדר ב-Dockerfile).

**Login לא עובד:**
ודא ש-`APP_PASSWORD` ו-`SESSION_SECRET` שניהם מוגדרים ב-Railway. ה-cookie נשלח עם `secure` flag ב-production, אז ודא שאתה ב-HTTPS (Railway domains תמיד HTTPS).

**`UNAUTHED_ERR_MSG` לולאה:**
אם אתה רואה שה-app חוזר ל-`/login` אחרי הצלחה — `SESSION_SECRET` כנראה שונה בין deployments. תקבע ערך קבוע.

**LLM calls נכשלים:**
ודא ש-`ANTHROPIC_API_KEY` תקין. ה-default model הוא `claude-sonnet-4-5-20250929`. אם תרצה מודל אחר, הגדר `ANTHROPIC_MODEL` ב-env.

**DB connection refused:**
תוודא ש-MySQL plugin של Railway באותו project ושאתה משתמש ב-`DATABASE_URL` שהוא הזריק. הריץ `pnpm db:push` פעם אחת אחרי deploy ראשון.

---

## File Map (קבצים מרכזיים אחרי ההגירה)

```
server/_core/
  llm.ts          ← Anthropic Claude wrapper (cache-aware)
  llm-cache.ts    ← MySQL-backed response cache + cost reporting ⭐
  notification.ts ← Telegram bot
  sdk.ts          ← Password auth + JWT
  oauth.ts        ← /api/auth/login, /api/auth/logout, /api/auth/me
  env.ts          ← Env vars (Manus forge keys removed)
  storageProxy.ts ← No-op stub
  index.ts        ← Express entry, /api/health, listens on $PORT

server/
  ad-detection.ts        ← Direct Playwright + network sniffing
  apify.ts               ← Apify cloud scraping (contacts + ads)
  scrape-orchestrator.ts ← Smart routing: Apify-first, Playwright-fallback ⭐
  contact-discovery.ts   ← Direct Playwright + Snov + WHOIS + LLM
  mcp-integrations.ts    ← Gmail (googleapis) + Playwright contact scraper
  routers.ts             ← tRPC routes (incl. new scrape.* router)

client/src/
  pages/Login.tsx ← מסך הסיסמה
  App.tsx        ← /login route + authenticated routes
  const.ts       ← getLoginUrl() → "/login"
```

Manus-specific files שהוסרו: `storage.ts`, `voiceTranscription.ts`, `imageGeneration.ts`, `map.ts`, `dataApi.ts`, `types/manusTypes.ts`, `vite.config.ts.bak`, `patches/wouter@3.7.1.patch`, `client/public/__manus__/`.
