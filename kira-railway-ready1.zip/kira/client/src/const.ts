export { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";

/**
 * Internal login route. Replaces the original Manus-OAuth redirect flow.
 * The /login page is rendered by client/src/pages/Login.tsx and posts to
 * /api/auth/login on success.
 */
export const getLoginUrl = () => "/login";
