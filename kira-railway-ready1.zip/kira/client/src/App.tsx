import { Toaster } from "@/components/ui/sonner";
import { TooltipProvider } from "@/components/ui/tooltip";
import NotFound from "@/pages/NotFound";
import { Route, Switch } from "wouter";
import ErrorBoundary from "./components/ErrorBoundary";
import { ThemeProvider } from "./contexts/ThemeContext";
import Home from "./pages/Home";
import Pipeline from "./pages/Pipeline";
import LeadDetail from "./pages/LeadDetail";
import Discovery from "./pages/Discovery";
import Import from "./pages/Import";
import Agent from "./pages/Agent";
import Login from "./pages/Login";
import DashboardLayout from "./components/DashboardLayout";

/**
 * Authenticated routes — wrapped in DashboardLayout (sidebar + chrome).
 */
function AuthenticatedRoutes() {
  return (
    <DashboardLayout>
      <Switch>
        <Route path={"/"} component={Home} />
        <Route path={"/pipeline"} component={Pipeline} />
        <Route path={"/leads/:id"} component={LeadDetail} />
        <Route path={"/discovery"} component={Discovery} />
        <Route path={"/import"} component={Import} />
        <Route path={"/agent"} component={Agent} />
        <Route path={"/404"} component={NotFound} />
        <Route component={NotFound} />
      </Switch>
    </DashboardLayout>
  );
}

function Router() {
  return (
    <Switch>
      {/* /login renders standalone — no sidebar / dashboard chrome */}
      <Route path={"/login"} component={Login} />
      {/* Everything else goes through the authenticated layout. If the user
          is not authenticated, tRPC will return UNAUTHED_ERR_MSG and main.tsx
          will redirect to /login automatically. */}
      <Route component={AuthenticatedRoutes} />
    </Switch>
  );
}

function App() {
  return (
    <ErrorBoundary>
      <ThemeProvider defaultTheme="dark">
        <TooltipProvider>
          <Toaster />
          <Router />
        </TooltipProvider>
      </ThemeProvider>
    </ErrorBoundary>
  );
}

export default App;
