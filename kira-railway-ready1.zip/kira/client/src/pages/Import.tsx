import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Upload, FileText, Loader2, CheckCircle } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

export default function Import() {
  const [textInput, setTextInput] = useState("");
  const [importResult, setImportResult] = useState<{ imported: number } | null>(null);
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const bulkImport = trpc.publishers.bulkImport.useMutation({
    onSuccess: (data) => {
      setImportResult(data);
      utils.publishers.list.invalidate();
      utils.publishers.stats.invalidate();
      toast.success(`Successfully imported ${data.imported} domains`);
    },
    onError: (err) => toast.error(err.message),
  });

  const handleImport = () => {
    const domains = textInput
      .split(/[\n,\s]+/)
      .map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
      .filter((d) => d.length > 0 && d.includes('.'));

    if (domains.length === 0) {
      toast.error("No valid domains found. Please enter domains separated by commas or newlines.");
      return;
    }

    bulkImport.mutate({ domains });
  };

  const handleFileUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    if (!file) return;

    const reader = new FileReader();
    reader.onload = (event) => {
      const text = event.target?.result as string;
      setTextInput(text);
    };
    reader.readAsText(file);
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Import Domains</h1>
        <p className="text-muted-foreground mt-1">Bulk import publisher domains into your pipeline</p>
      </div>

      <Card className="bg-card border-border/50">
        <CardHeader>
          <CardTitle className="text-base font-medium">Paste or Upload Domains</CardTitle>
        </CardHeader>
        <CardContent className="space-y-4">
          <div className="relative">
            <textarea
              className="w-full h-64 p-4 bg-input border border-border rounded-lg text-sm font-mono resize-none focus:outline-none focus:ring-2 focus:ring-ring"
              placeholder={`Enter domains, one per line or comma-separated:\n\nkatfile.com\nuploaded.net\nrapidgator.net\nnitroflare.com\n\nOr paste a list from any source...`}
              value={textInput}
              onChange={(e) => setTextInput(e.target.value)}
            />
          </div>

          <div className="flex items-center gap-4">
            <label className="flex items-center gap-2 px-4 py-2 border border-border rounded-lg cursor-pointer hover:bg-accent/50 transition-colors">
              <FileText className="h-4 w-4 text-muted-foreground" />
              <span className="text-sm">Upload File (.txt, .csv)</span>
              <input
                type="file"
                accept=".txt,.csv"
                className="hidden"
                onChange={handleFileUpload}
              />
            </label>

            <div className="flex-1" />

            <Button
              onClick={handleImport}
              disabled={bulkImport.isPending || !textInput.trim()}
              size="lg"
            >
              {bulkImport.isPending ? (
                <Loader2 className="h-4 w-4 animate-spin mr-2" />
              ) : (
                <Upload className="h-4 w-4 mr-2" />
              )}
              Import Domains
            </Button>
          </div>

          {textInput.trim() && (
            <p className="text-xs text-muted-foreground">
              {textInput.split(/[\n,\s]+/).filter((d) => d.trim().length > 0 && d.includes('.')).length} domains detected
            </p>
          )}
        </CardContent>
      </Card>

      {importResult && (
        <Card className="bg-card border-emerald-500/20">
          <CardContent className="p-6">
            <div className="flex items-center gap-4">
              <div className="w-12 h-12 rounded-full bg-emerald-500/10 flex items-center justify-center">
                <CheckCircle className="h-6 w-6 text-emerald-400" />
              </div>
              <div>
                <h3 className="font-medium">Import Complete</h3>
                <p className="text-sm text-muted-foreground mt-0.5">
                  {importResult.imported} domains have been added to your pipeline.
                </p>
              </div>
              <div className="flex-1" />
              <Button variant="outline" onClick={() => setLocation("/pipeline")}>
                View Pipeline
              </Button>
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
