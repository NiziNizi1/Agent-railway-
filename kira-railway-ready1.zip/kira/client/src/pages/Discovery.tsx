import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Search, Plus, Loader2, Globe } from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";

export default function Discovery() {
  const [seedInput, setSeedInput] = useState("");
  const [results, setResults] = useState<Array<{ domain: string; reason: string }>>([]);
  const utils = trpc.useUtils();

  const findSimilar = trpc.discovery.findSimilar.useMutation({
    onSuccess: (data) => {
      setResults(data);
      toast.success(`Found ${data.length} similar domains`);
    },
    onError: (err) => toast.error(err.message),
  });

  const createPublisher = trpc.publishers.create.useMutation({
    onSuccess: () => {
      utils.publishers.list.invalidate();
      toast.success("Added to pipeline");
    },
    onError: (err) => toast.error(err.message),
  });

  const handleSearch = () => {
    const seeds = seedInput
      .split(/[,\n]/)
      .map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
      .filter(Boolean);
    if (seeds.length === 0) {
      toast.error("Please enter at least one seed domain");
      return;
    }
    findSimilar.mutate({ seedDomains: seeds });
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Discovery</h1>
        <p className="text-muted-foreground mt-1">Find similar publisher websites from seed domains</p>
      </div>

      {/* Search Input */}
      <Card className="bg-card border-border/50">
        <CardContent className="p-6">
          <div className="space-y-4">
            <label className="text-sm font-medium">Seed Domains</label>
            <div className="flex gap-3">
              <Input
                placeholder="Enter domains separated by commas (e.g., katfile.com, uploaded.net)"
                value={seedInput}
                onChange={(e) => setSeedInput(e.target.value)}
                onKeyDown={(e) => e.key === "Enter" && handleSearch()}
                className="bg-input border-border"
              />
              <Button
                onClick={handleSearch}
                disabled={findSimilar.isPending || !seedInput.trim()}
                className="shrink-0"
              >
                {findSimilar.isPending ? (
                  <Loader2 className="h-4 w-4 animate-spin mr-2" />
                ) : (
                  <Search className="h-4 w-4 mr-2" />
                )}
                Find Similar
              </Button>
            </div>
            <p className="text-xs text-muted-foreground">
              Enter one or more domains. The AI will analyze them and suggest similar websites that could be potential publisher partners.
            </p>
          </div>
        </CardContent>
      </Card>

      {/* Results */}
      {findSimilar.isPending && (
        <Card className="bg-card border-border/50">
          <CardContent className="p-12 flex flex-col items-center justify-center gap-4">
            <Loader2 className="h-8 w-8 animate-spin text-primary" />
            <p className="text-muted-foreground">Analyzing domains and finding similar publishers...</p>
          </CardContent>
        </Card>
      )}

      {results.length > 0 && (
        <Card className="bg-card border-border/50">
          <CardHeader>
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Globe className="h-4 w-4 text-primary" />
              Discovered Publishers ({results.length})
            </CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {results.map((result, idx) => (
                <div
                  key={idx}
                  className="flex items-center justify-between p-4 rounded-lg border border-border/50 hover:border-primary/20 transition-colors"
                >
                  <div className="flex items-center gap-4">
                    <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
                      <span className="text-sm font-bold text-primary">
                        {result.domain.charAt(0).toUpperCase()}
                      </span>
                    </div>
                    <div>
                      <p className="font-medium">{result.domain}</p>
                      <p className="text-sm text-muted-foreground mt-0.5">{result.reason}</p>
                    </div>
                  </div>
                  <Button
                    variant="outline"
                    size="sm"
                    onClick={() => createPublisher.mutate({ domain: result.domain })}
                    disabled={createPublisher.isPending}
                  >
                    <Plus className="h-3.5 w-3.5 mr-1.5" />
                    Add to Pipeline
                  </Button>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}
