import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Table, TableBody, TableCell, TableHead, TableHeader, TableRow } from "@/components/ui/table";
import { LayoutGrid, List, ExternalLink, Sparkles, Trash2 } from "lucide-react";
import { useState } from "react";
import { useLocation } from "wouter";
import { toast } from "sonner";

const STATUSES = [
  { value: "new", label: "New", color: "bg-indigo-500/10 text-indigo-400 border-indigo-500/20" },
  { value: "cold_outreach_sent", label: "Cold Outreach Sent", color: "bg-amber-500/10 text-amber-400 border-amber-500/20" },
  { value: "follow_up", label: "Follow-up", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  { value: "warm", label: "Warm", color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  { value: "converted", label: "Converted", color: "bg-emerald-500/10 text-emerald-400 border-emerald-500/20" },
  { value: "rejected", label: "Rejected", color: "bg-red-500/10 text-red-400 border-red-500/20" },
];

export default function Pipeline() {
  const [view, setView] = useState<"table" | "kanban">("table");
  const [filterStatus, setFilterStatus] = useState<string>("all");
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const { data: publishers, isLoading } = trpc.publishers.list.useQuery(
    filterStatus !== "all" ? { status: filterStatus } : undefined
  );

  const updateStatus = trpc.publishers.updateStatus.useMutation({
    onSuccess: () => {
      utils.publishers.list.invalidate();
      utils.publishers.stats.invalidate();
      toast.success("Status updated");
    },
  });

  const enrichMutation = trpc.publishers.enrich.useMutation({
    onSuccess: () => {
      utils.publishers.list.invalidate();
      toast.success("Domain enriched successfully");
    },
    onError: (err) => toast.error(err.message),
  });

  const deleteMutation = trpc.publishers.delete.useMutation({
    onSuccess: () => {
      utils.publishers.list.invalidate();
      utils.publishers.stats.invalidate();
      toast.success("Lead deleted");
    },
  });

  return (
    <div className="space-y-6">
      <div className="flex items-center justify-between">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Pipeline</h1>
          <p className="text-muted-foreground mt-1">Manage your publisher leads</p>
        </div>
        <div className="flex items-center gap-3">
          <Select value={filterStatus} onValueChange={setFilterStatus}>
            <SelectTrigger className="w-[180px] bg-card">
              <SelectValue placeholder="Filter by status" />
            </SelectTrigger>
            <SelectContent>
              <SelectItem value="all">All Statuses</SelectItem>
              {STATUSES.map((s) => (
                <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
              ))}
            </SelectContent>
          </Select>
          <div className="flex items-center border border-border rounded-lg overflow-hidden">
            <button
              onClick={() => setView("table")}
              className={`p-2 ${view === "table" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}`}
            >
              <List className="h-4 w-4" />
            </button>
            <button
              onClick={() => setView("kanban")}
              className={`p-2 ${view === "kanban" ? "bg-primary/10 text-primary" : "text-muted-foreground hover:text-foreground"}`}
            >
              <LayoutGrid className="h-4 w-4" />
            </button>
          </div>
        </div>
      </div>

      {isLoading ? (
        <Card className="bg-card border-border/50">
          <CardContent className="p-8">
            <div className="animate-pulse space-y-4">
              {[...Array(5)].map((_, i) => <div key={i} className="h-12 bg-muted rounded" />)}
            </div>
          </CardContent>
        </Card>
      ) : view === "table" ? (
        <Card className="bg-card border-border/50">
          <CardContent className="p-0">
            <Table>
              <TableHeader>
                <TableRow className="border-border/50 hover:bg-transparent">
                  <TableHead className="text-muted-foreground">Domain</TableHead>
                  <TableHead className="text-muted-foreground">Category</TableHead>
                  <TableHead className="text-muted-foreground">Traffic</TableHead>
                  <TableHead className="text-muted-foreground">Score</TableHead>
                  <TableHead className="text-muted-foreground">Status</TableHead>
                  <TableHead className="text-muted-foreground text-right">Actions</TableHead>
                </TableRow>
              </TableHeader>
              <TableBody>
                {publishers && publishers.length > 0 ? publishers.map((pub: any) => (
                  <TableRow
                    key={pub.id}
                    className="border-border/30 cursor-pointer hover:bg-accent/50"
                    onClick={() => setLocation(`/leads/${pub.id}`)}
                  >
                    <TableCell className="font-medium">
                      <div className="flex items-center gap-2">
                        <div className="w-7 h-7 rounded bg-primary/10 flex items-center justify-center shrink-0">
                          <span className="text-xs font-bold text-primary">{pub.domain.charAt(0).toUpperCase()}</span>
                        </div>
                        {pub.domain}
                      </div>
                    </TableCell>
                    <TableCell className="text-muted-foreground">{pub.category || "—"}</TableCell>
                    <TableCell className="text-muted-foreground">{pub.trafficTier || "—"}</TableCell>
                    <TableCell>
                      {pub.score ? (
                        <span className={`text-sm font-medium ${pub.score >= 70 ? "text-emerald-400" : pub.score >= 40 ? "text-amber-400" : "text-red-400"}`}>
                          {pub.score}
                        </span>
                      ) : "—"}
                    </TableCell>
                    <TableCell>
                      <Select
                        value={pub.status}
                        onValueChange={(val) => {
                          updateStatus.mutate({ id: pub.id, status: val as any });
                        }}
                      >
                        <SelectTrigger
                          className={`w-[160px] h-7 text-xs border ${STATUSES.find(s => s.value === pub.status)?.color || ""}`}
                          onClick={(e) => e.stopPropagation()}
                        >
                          <SelectValue />
                        </SelectTrigger>
                        <SelectContent>
                          {STATUSES.map((s) => (
                            <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
                          ))}
                        </SelectContent>
                      </Select>
                    </TableCell>
                    <TableCell className="text-right">
                      <div className="flex items-center justify-end gap-1" onClick={(e) => e.stopPropagation()}>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7"
                          onClick={() => enrichMutation.mutate({ id: pub.id })}
                          disabled={enrichMutation.isPending}
                        >
                          <Sparkles className="h-3.5 w-3.5" />
                        </Button>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive hover:text-destructive"
                          onClick={() => deleteMutation.mutate({ id: pub.id })}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    </TableCell>
                  </TableRow>
                )) : (
                  <TableRow>
                    <TableCell colSpan={6} className="text-center py-12 text-muted-foreground">
                      No leads yet. Import domains or use Discovery to find publishers.
                    </TableCell>
                  </TableRow>
                )}
              </TableBody>
            </Table>
          </CardContent>
        </Card>
      ) : (
        /* Kanban View */
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 xl:grid-cols-6 gap-4">
          {STATUSES.map((status) => {
            const statusPublishers = publishers?.filter((p: any) => p.status === status.value) || [];
            return (
              <div key={status.value} className="space-y-3">
                <div className="flex items-center justify-between px-1">
                  <h3 className="text-sm font-medium text-muted-foreground">{status.label}</h3>
                  <Badge variant="secondary" className="text-xs">{statusPublishers.length}</Badge>
                </div>
                <div className="space-y-2 min-h-[200px]">
                  {statusPublishers.map((pub: any) => (
                    <Card
                      key={pub.id}
                      className="bg-card border-border/50 cursor-pointer hover:border-primary/30 transition-colors"
                      onClick={() => setLocation(`/leads/${pub.id}`)}
                    >
                      <CardContent className="p-3">
                        <p className="text-sm font-medium truncate">{pub.domain}</p>
                        <p className="text-xs text-muted-foreground mt-1">{pub.category || "Uncategorized"}</p>
                        {pub.score && (
                          <div className="mt-2">
                            <div className="w-full h-1.5 bg-muted rounded-full overflow-hidden">
                              <div
                                className="h-full bg-primary rounded-full"
                                style={{ width: `${pub.score}%` }}
                              />
                            </div>
                          </div>
                        )}
                      </CardContent>
                    </Card>
                  ))}
                </div>
              </div>
            );
          })}
        </div>
      )}
    </div>
  );
}
