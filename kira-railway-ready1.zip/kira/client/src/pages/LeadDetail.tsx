import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Badge } from "@/components/ui/badge";
import { Input } from "@/components/ui/input";
import { Select, SelectContent, SelectItem, SelectTrigger, SelectValue } from "@/components/ui/select";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  ArrowLeft, Globe, Mail, Linkedin, Phone, MessageSquare,
  Sparkles, Plus, Loader2, Clock, Send, User, ExternalLink, Trash2, Scan, Search
} from "lucide-react";
import { useState } from "react";
import { useLocation, useParams } from "wouter";
import { toast } from "sonner";

const STATUSES = [
  { value: "new", label: "New" },
  { value: "cold_outreach_sent", label: "Cold Outreach Sent" },
  { value: "follow_up", label: "Follow-up" },
  { value: "warm", label: "Warm" },
  { value: "converted", label: "Converted" },
  { value: "rejected", label: "Rejected" },
];

const CONTACT_TYPES = [
  { value: "email", label: "Email", icon: Mail },
  { value: "linkedin", label: "LinkedIn", icon: Linkedin },
  { value: "phone", label: "Phone", icon: Phone },
  { value: "telegram", label: "Telegram", icon: MessageSquare },
  { value: "other", label: "Other", icon: Globe },
];

export default function LeadDetail() {
  const params = useParams<{ id: string }>();
  const id = parseInt(params.id || "0");
  const [, setLocation] = useLocation();
  const utils = trpc.useUtils();

  const { data: publisher, isLoading } = trpc.publishers.getById.useQuery({ id });
  const { data: contacts } = trpc.contacts.getByPublisher.useQuery({ publisherId: id });
  const { data: outreach } = trpc.outreach.getByPublisher.useQuery({ publisherId: id });
  const { data: drafts } = trpc.drafts.getByPublisher.useQuery({ publisherId: id });
  const { data: persistedDetections } = trpc.adDetection.getDetections.useQuery({ publisherId: id });

  const [newContactType, setNewContactType] = useState("email");
  const [newContactValue, setNewContactValue] = useState("");
  const [newContactName, setNewContactName] = useState("");

  const updateStatus = trpc.publishers.updateStatus.useMutation({
    onSuccess: () => {
      utils.publishers.getById.invalidate({ id });
      utils.publishers.list.invalidate();
      toast.success("Status updated");
    },
  });

  const enrichMutation = trpc.publishers.enrich.useMutation({
    onSuccess: () => {
      utils.publishers.getById.invalidate({ id });
      toast.success("Domain enriched");
    },
    onError: (err) => toast.error(err.message),
  });

  const addContact = trpc.contacts.create.useMutation({
    onSuccess: () => {
      utils.contacts.getByPublisher.invalidate({ publisherId: id });
      setNewContactValue("");
      setNewContactName("");
      toast.success("Contact added");
    },
  });

  const deleteContact = trpc.contacts.delete.useMutation({
    onSuccess: () => {
      utils.contacts.getByPublisher.invalidate({ publisherId: id });
      toast.success("Contact removed");
    },
  });

  const generateDraft = trpc.drafts.generate.useMutation({
    onSuccess: () => {
      utils.drafts.getByPublisher.invalidate({ publisherId: id });
      toast.success("Email draft generated");
    },
    onError: (err) => toast.error(err.message),
  });

  const logOutreach = trpc.outreach.create.useMutation({
    onSuccess: () => {
      utils.outreach.getByPublisher.invalidate({ publisherId: id });
      toast.success("Outreach logged");
    },
  });

  const sendGmail = trpc.gmail.send.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        utils.outreach.getByPublisher.invalidate({ publisherId: id });
        utils.publishers.getById.invalidate({ id });
        toast.success("Email sent via Gmail!");
      } else {
        toast.error(data.error || "Failed to send email");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const scrapeContacts = trpc.scraper.scrapeContacts.useMutation({
    onSuccess: (data) => {
      utils.contacts.getByPublisher.invalidate({ publisherId: id });
      if (data.addedCount > 0) {
        toast.success(`Found and added ${data.addedCount} new contacts!`);
      } else if (data.emails.length === 0 && data.socialLinks.length === 0) {
        toast.info("No contacts found on this website");
      } else {
        toast.info("All found contacts already exist");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const snovFindEmails = trpc.snov.findEmails.useMutation({
    onSuccess: (data) => {
      utils.contacts.getByPublisher.invalidate({ publisherId: id });
      if (data.addedCount > 0) {
        toast.success(`Snov.io found ${data.emails.length} emails, added ${data.addedCount} new contacts!`);
      } else if (data.emails.length > 0) {
        toast.info(`Found ${data.emails.length} emails (all already exist)`);
      } else {
        toast.info("No emails found via Snov.io for this domain");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const snovVerify = trpc.snov.verifyEmail.useMutation({
    onSuccess: (data) => {
      if (data.success) {
        toast.success(`Verification result: ${data.result}`);
      } else {
        toast.error(data.error || "Verification failed");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const deepSearch = trpc.deepSearch.findContacts.useMutation({
    onSuccess: (data) => {
      utils.contacts.getByPublisher.invalidate({ publisherId: id });
      if (data.addedCount > 0) {
        toast.success(`Deep Search found ${data.total} contacts across ${data.sources.join(', ')}! Added ${data.addedCount} new.`);
      } else if (data.total > 0) {
        toast.info(`Found ${data.total} contacts (all already exist). Sources: ${data.sources.join(', ')}`);
      } else {
        toast.info(`No contacts found. Searched: ${data.sources.join(', ')}`);
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const apifyScrape = trpc.apify.scrapeContacts.useMutation({
    onSuccess: (data) => {
      utils.contacts.getByPublisher.invalidate({ publisherId: id });
      utils.publishers.getById.invalidate({ id });
      if (data.addedCount > 0) {
        toast.success(`Apify found ${data.emails.length} emails, added ${data.addedCount} contacts!`);
      } else if (data.emails.length > 0) {
        toast.info(`Found ${data.emails.length} emails (already exist)`);
      } else {
        toast.info("No contacts found via Apify");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const apifyDetectAds = trpc.apify.detectAds.useMutation({
    onSuccess: (data) => {
      utils.publishers.getById.invalidate({ id });
      utils.adDetection.getDetections.invalidate({ publisherId: id });
      if (data.adSignals && data.adSignals.length > 0) {
        toast.success(`Apify detected ${data.adSignals.length} ad networks: ${data.adSignals.join(", ")}`);
      } else {
        toast.info("No ad networks detected via Apify");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  const detectAds = trpc.adDetection.detect.useMutation({
    onSuccess: (data) => {
      utils.publishers.getById.invalidate({ id });
      if (data.detectedAds.length > 0) {
        toast.success(`Detected ${data.detectedAds.length} ad networks!`);
      } else if (data.error) {
        toast.error(`Detection failed: ${data.error}`);
      } else {
        toast.info("No known ad networks detected on this site");
      }
    },
    onError: (err) => toast.error(err.message),
  });

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div className="animate-pulse space-y-4">
          <div className="h-8 w-48 bg-muted rounded" />
          <div className="h-64 bg-muted rounded" />
        </div>
      </div>
    );
  }

  if (!publisher) {
    return (
      <div className="flex flex-col items-center justify-center py-20 gap-4">
        <p className="text-muted-foreground">Publisher not found</p>
        <Button variant="outline" onClick={() => setLocation("/pipeline")}>
          <ArrowLeft className="h-4 w-4 mr-2" /> Back to Pipeline
        </Button>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      {/* Header */}
      <div className="flex items-center gap-4">
        <Button variant="ghost" size="icon" onClick={() => setLocation("/pipeline")}>
          <ArrowLeft className="h-4 w-4" />
        </Button>
        <div className="flex-1">
          <div className="flex items-center gap-3">
            <div className="w-10 h-10 rounded-lg bg-primary/10 flex items-center justify-center">
              <span className="text-lg font-bold text-primary">{publisher.domain.charAt(0).toUpperCase()}</span>
            </div>
            <div>
              <h1 className="text-xl font-semibold">{publisher.domain}</h1>
              <p className="text-sm text-muted-foreground">{publisher.description || "No description"}</p>
            </div>
          </div>
        </div>
        <Select
          value={publisher.status}
          onValueChange={(val) => updateStatus.mutate({ id, status: val as any })}
        >
          <SelectTrigger className="w-[180px]">
            <SelectValue />
          </SelectTrigger>
          <SelectContent>
            {STATUSES.map((s) => (
              <SelectItem key={s.value} value={s.value}>{s.label}</SelectItem>
            ))}
          </SelectContent>
        </Select>
        <Button onClick={() => enrichMutation.mutate({ id })} disabled={enrichMutation.isPending}>
          {enrichMutation.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Sparkles className="h-4 w-4 mr-2" />}
          Enrich
        </Button>
        <Button variant="outline" onClick={() => detectAds.mutate({ publisherId: id })} disabled={detectAds.isPending}>
          {detectAds.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Scan className="h-4 w-4 mr-2" />}
          Detect Ads
        </Button>
        <Button variant="outline" onClick={() => apifyDetectAds.mutate({ publisherId: id })} disabled={apifyDetectAds.isPending} title="Detect ads via Apify (more accurate)">
          {apifyDetectAds.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Scan className="h-4 w-4 mr-2" />}
          Apify Detect
        </Button>
      </div>

      {/* Enrichment Data */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-4 gap-4">
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Category</p>
            <p className="text-sm font-medium mt-1">{publisher.category || "—"}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Traffic Tier</p>
            <p className="text-sm font-medium mt-1">{publisher.trafficTier || "—"}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Language</p>
            <p className="text-sm font-medium mt-1">{publisher.language || "—"}</p>
          </CardContent>
        </Card>
        <Card className="bg-card border-border/50">
          <CardContent className="p-4">
            <p className="text-xs text-muted-foreground">Score</p>
            <p className="text-sm font-medium mt-1">{publisher.score ? `${publisher.score}/100` : "—"}</p>
          </CardContent>
        </Card>
      </div>

      {/* SimilarWeb Metrics */}
      {((publisher as any).globalRank || (publisher as any).bounceRate || (publisher as any).estimatedMonthlyVisits) && (
        <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
          {(publisher as any).globalRank && (
            <Card className="bg-card border-border/50">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">Global Rank</p>
                <p className="text-sm font-medium mt-1">#{(publisher as any).globalRank?.toLocaleString()}</p>
              </CardContent>
            </Card>
          )}
          {(publisher as any).bounceRate && (
            <Card className="bg-card border-border/50">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">Bounce Rate</p>
                <p className="text-sm font-medium mt-1">{((publisher as any).bounceRate * 100).toFixed(1)}%</p>
              </CardContent>
            </Card>
          )}
          {(publisher as any).estimatedMonthlyVisits && (
            <Card className="bg-card border-border/50">
              <CardContent className="p-4">
                <p className="text-xs text-muted-foreground">Monthly Visits</p>
                <p className="text-sm font-medium mt-1">{((publisher as any).estimatedMonthlyVisits / 1000).toFixed(0)}K</p>
              </CardContent>
            </Card>
          )}
        </div>
      )}

      {/* Ad Networks Section */}
      {(Array.isArray(publisher.adFormats) && publisher.adFormats.length > 0) || detectAds.data || (persistedDetections && persistedDetections.length > 0) ? (
        <Card className="bg-card border-border/50">
          <CardHeader className="flex flex-row items-center justify-between pb-3">
            <CardTitle className="text-base font-medium flex items-center gap-2">
              <Scan className="h-4 w-4 text-primary" />
              Detected Ad Networks
            </CardTitle>
          </CardHeader>
          <CardContent>
            {/* Show live results or persisted results */}
            {(() => {
              const liveAds = detectAds.data?.detectedAds || [];
              const savedAds = persistedDetections || [];
              const adsToShow: any[] = liveAds.length > 0 ? liveAds : savedAds;
              if (adsToShow.length > 0) return (
                <div className="grid grid-cols-1 md:grid-cols-2 gap-3">
                  {adsToShow.map((ad: any, i: number) => (
                    <div key={i} className="flex items-center justify-between p-3 rounded-lg border border-border/40 bg-muted/20">
                      <div>
                        <p className="text-sm font-medium">{ad.network}</p>
                        <p className="text-xs text-muted-foreground">{ad.format}</p>
                      </div>
                      <Badge
                        variant="secondary"
                        className={`text-xs ${
                          ad.confidence === 'high' ? 'bg-emerald-500/10 text-emerald-400' :
                          ad.confidence === 'medium' ? 'bg-amber-500/10 text-amber-400' :
                          'bg-muted text-muted-foreground'
                        }`}
                      >
                        {ad.confidence}
                      </Badge>
                    </div>
                  ))}
                </div>
              );
              return (
                <div className="flex flex-wrap gap-2">
                  {(publisher.adFormats as any[]).map((format: any, i: number) => (
                    <Badge key={i} variant="secondary" className="text-xs">{String(format)}</Badge>
                  ))}
                </div>
              );
            })()}
          </CardContent>
        </Card>
      ) : null}

      {/* Tabs */}
      <Tabs defaultValue="contacts" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="contacts">Contacts</TabsTrigger>
          <TabsTrigger value="outreach">Outreach History</TabsTrigger>
          <TabsTrigger value="drafts">AI Pitch Generator</TabsTrigger>
        </TabsList>

        {/* Contacts Tab */}
        <TabsContent value="contacts" className="space-y-4">
          <Card className="bg-card border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base font-medium">Contact Information</CardTitle>
              <div className="flex flex-wrap gap-2">
                <Button
                  size="sm"
                  onClick={() => deepSearch.mutate({ publisherId: id })}
                  disabled={deepSearch.isPending}
                  className="bg-primary/90 hover:bg-primary"
                >
                  {deepSearch.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Search className="h-3.5 w-3.5 mr-1.5" />}
                  Deep Search
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => snovFindEmails.mutate({ publisherId: id })}
                  disabled={snovFindEmails.isPending}
                >
                  {snovFindEmails.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Mail className="h-3.5 w-3.5 mr-1.5" />}
                  Snov.io Search
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => apifyScrape.mutate({ publisherId: id })}
                  disabled={apifyScrape.isPending}
                  title="Scrape contacts via Apify (more reliable)"
                >
                  {apifyScrape.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Globe className="h-3.5 w-3.5 mr-1.5" />}
                  Apify Scrape
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => scrapeContacts.mutate({ publisherId: id })}
                  disabled={scrapeContacts.isPending}
                >
                  {scrapeContacts.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Globe className="h-3.5 w-3.5 mr-1.5" />}
                  Scrape Website
                </Button>
              </div>
            </CardHeader>
            <CardContent className="space-y-4">
              {contacts && contacts.length > 0 ? (
                <div className="space-y-2">
                  {contacts.map((contact: any) => {
                    const typeInfo = CONTACT_TYPES.find(t => t.value === contact.type);
                    const Icon = typeInfo?.icon || Globe;
                    return (
                      <div key={contact.id} className="flex items-center justify-between p-3 rounded-lg border border-border/30">
                        <div className="flex items-center gap-3">
                          <Icon className="h-4 w-4 text-muted-foreground" />
                          <div>
                            <p className="text-sm font-medium">{contact.value}</p>
                            {contact.name && <p className="text-xs text-muted-foreground">{contact.name} {contact.role ? `• ${contact.role}` : ""}</p>}
                          </div>
                        </div>
                        <Button
                          variant="ghost"
                          size="icon"
                          className="h-7 w-7 text-destructive"
                          onClick={() => deleteContact.mutate({ id: contact.id })}
                        >
                          <Trash2 className="h-3.5 w-3.5" />
                        </Button>
                      </div>
                    );
                  })}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground py-4 text-center">No contacts added yet</p>
              )}

              {/* Add Contact Form */}
              <div className="flex items-end gap-3 pt-4 border-t border-border/30">
                <div className="w-32">
                  <Select value={newContactType} onValueChange={setNewContactType}>
                    <SelectTrigger className="bg-input">
                      <SelectValue />
                    </SelectTrigger>
                    <SelectContent>
                      {CONTACT_TYPES.map((t) => (
                        <SelectItem key={t.value} value={t.value}>{t.label}</SelectItem>
                      ))}
                    </SelectContent>
                  </Select>
                </div>
                <Input
                  placeholder="Contact value (email, URL, etc.)"
                  value={newContactValue}
                  onChange={(e) => setNewContactValue(e.target.value)}
                  className="bg-input"
                />
                <Input
                  placeholder="Name (optional)"
                  value={newContactName}
                  onChange={(e) => setNewContactName(e.target.value)}
                  className="bg-input w-40"
                />
                <Button
                  onClick={() => {
                    if (!newContactValue.trim()) return;
                    addContact.mutate({
                      publisherId: id,
                      type: newContactType as any,
                      value: newContactValue,
                      name: newContactName || undefined,
                    });
                  }}
                  disabled={!newContactValue.trim()}
                  size="icon"
                >
                  <Plus className="h-4 w-4" />
                </Button>
              </div>
            </CardContent>
          </Card>
        </TabsContent>

        {/* Outreach History Tab */}
        <TabsContent value="outreach" className="space-y-4">
          <Card className="bg-card border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base font-medium">Outreach Timeline</CardTitle>
              <Button
                variant="outline"
                size="sm"
                onClick={() => logOutreach.mutate({
                  publisherId: id,
                  type: "email_sent",
                  subject: "Manual outreach logged",
                  content: "Outreach sent manually",
                })}
              >
                <Send className="h-3.5 w-3.5 mr-1.5" />
                Log Outreach
              </Button>
            </CardHeader>
            <CardContent>
              {outreach && outreach.length > 0 ? (
                <div className="relative pl-6 space-y-6">
                  <div className="absolute left-2 top-2 bottom-2 w-px bg-border/50" />
                  {outreach.map((entry: any) => (
                    <div key={entry.id} className="relative">
                      <div className="absolute -left-4 top-1 w-3 h-3 rounded-full bg-primary border-2 border-background" />
                      <div className="pl-4">
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs capitalize">
                            {entry.type.replace(/_/g, " ")}
                          </Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(entry.createdAt).toLocaleDateString()} {new Date(entry.createdAt).toLocaleTimeString([], { hour: '2-digit', minute: '2-digit' })}
                          </span>
                        </div>
                        {entry.subject && <p className="text-sm font-medium mt-1">{entry.subject}</p>}
                        {entry.content && <p className="text-sm text-muted-foreground mt-0.5">{entry.content}</p>}
                      </div>
                    </div>
                  ))}
                </div>
              ) : (
                <p className="text-sm text-muted-foreground py-8 text-center">No outreach history yet</p>
              )}
            </CardContent>
          </Card>
        </TabsContent>

        {/* AI Pitch Generator Tab */}
        <TabsContent value="drafts" className="space-y-4">
          <Card className="bg-card border-border/50">
            <CardHeader className="flex flex-row items-center justify-between">
              <CardTitle className="text-base font-medium">AI Email Generator</CardTitle>
              <div className="flex gap-2">
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => generateDraft.mutate({ publisherId: id, type: "cold" })}
                  disabled={generateDraft.isPending}
                >
                  {generateDraft.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Sparkles className="h-3.5 w-3.5 mr-1.5" />}
                  Cold Email
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => generateDraft.mutate({ publisherId: id, type: "warm" })}
                  disabled={generateDraft.isPending}
                >
                  Warm Email
                </Button>
                <Button
                  variant="outline"
                  size="sm"
                  onClick={() => generateDraft.mutate({ publisherId: id, type: "follow_up" })}
                  disabled={generateDraft.isPending}
                >
                  Follow-up
                </Button>
              </div>
            </CardHeader>
            <CardContent>
              {generateDraft.isPending && (
                <div className="flex items-center justify-center py-8 gap-3">
                  <Loader2 className="h-5 w-5 animate-spin text-primary" />
                  <span className="text-muted-foreground">Generating personalized email...</span>
                </div>
              )}

              {drafts && drafts.length > 0 ? (
                <div className="space-y-6">
                  {drafts.map((draft: any) => (
                    <div key={draft.id} className="border border-border/50 rounded-lg p-4 space-y-3">
                      <div className="flex items-center justify-between">
                        <div className="flex items-center gap-2">
                          <Badge variant="secondary" className="text-xs capitalize">{draft.type}</Badge>
                          <span className="text-xs text-muted-foreground">
                            {new Date(draft.createdAt).toLocaleDateString()}
                          </span>
                        </div>
                        {contacts && contacts.length > 0 && contacts.find((c: any) => c.type === 'email') && (
                          <Button
                            variant="default"
                            size="sm"
                            onClick={() => {
                              const emailContact = contacts.find((c: any) => c.type === 'email');
                              if (emailContact) {
                                sendGmail.mutate({
                                  publisherId: id,
                                  to: emailContact.value,
                                  subject: draft.subjectVariantA,
                                  content: draft.body.replace(/<[^>]*>/g, ''),
                                });
                              }
                            }}
                            disabled={sendGmail.isPending}
                          >
                            {sendGmail.isPending ? <Loader2 className="h-3.5 w-3.5 animate-spin mr-1.5" /> : <Send className="h-3.5 w-3.5 mr-1.5" />}
                            Send via Gmail
                          </Button>
                        )}
                      </div>
                      <div className="space-y-2">
                        <div>
                          <p className="text-xs text-muted-foreground">Subject A:</p>
                          <p className="text-sm font-medium">{draft.subjectVariantA}</p>
                        </div>
                        {draft.subjectVariantB && (
                          <div>
                            <p className="text-xs text-muted-foreground">Subject B (A/B):</p>
                            <p className="text-sm font-medium">{draft.subjectVariantB}</p>
                          </div>
                        )}
                        <div className="pt-2 border-t border-border/30">
                          <p className="text-xs text-muted-foreground mb-1">Body:</p>
                          <div className="text-sm prose prose-invert max-w-none" dangerouslySetInnerHTML={{ __html: draft.body }} />
                        </div>
                      </div>
                    </div>
                  ))}
                </div>
              ) : !generateDraft.isPending ? (
                <p className="text-sm text-muted-foreground py-8 text-center">
                  Click a button above to generate a personalized email draft using AI
                </p>
              ) : null}
            </CardContent>
          </Card>
        </TabsContent>
      </Tabs>
    </div>
  );
}
