import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Button } from "@/components/ui/button";
import { Input } from "@/components/ui/input";
import { Badge } from "@/components/ui/badge";
import { Switch } from "@/components/ui/switch";
import { Tabs, TabsContent, TabsList, TabsTrigger } from "@/components/ui/tabs";
import {
  Bot, Play, Loader2, CheckCircle, XCircle, Search, Sparkles, Globe, Mail,
  Zap, Target, Users, ArrowRight, Plus
} from "lucide-react";
import { useState } from "react";
import { toast } from "sonner";
import { useLocation } from "wouter";

const PIPELINE_STEPS = [
  { key: "discovery", label: "Discover Similar Sites", icon: Search, description: "AI finds publisher websites similar to your seeds" },
  { key: "import", label: "Import to Pipeline", icon: Zap, description: "Add discovered domains to your CRM pipeline" },
  { key: "enrich", label: "Enrich Domains", icon: Sparkles, description: "Analyze each site: category, traffic, score, ad formats" },
  { key: "scrape", label: "Scrape Contacts", icon: Globe, description: "Auto-discover emails and social links from websites" },
  { key: "pitch", label: "Generate Pitches", icon: Mail, description: "AI creates personalized outreach emails with A/B subjects" },
];

const COMPETITOR_NETWORKS = [
  { name: "Monetag", color: "bg-orange-500/10 text-orange-400 border-orange-500/20" },
  { name: "PropellerAds", color: "bg-blue-500/10 text-blue-400 border-blue-500/20" },
  { name: "AdSterra", color: "bg-purple-500/10 text-purple-400 border-purple-500/20" },
  { name: "Galaksion", color: "bg-green-500/10 text-green-400 border-green-500/20" },
  { name: "PopAds", color: "bg-yellow-500/10 text-yellow-400 border-yellow-500/20" },
  { name: "PopCash", color: "bg-red-500/10 text-red-400 border-red-500/20" },
  { name: "ClickAdu", color: "bg-cyan-500/10 text-cyan-400 border-cyan-500/20" },
  { name: "HilltopAds", color: "bg-pink-500/10 text-pink-400 border-pink-500/20" },
];

export default function Agent() {
  const [, setLocation] = useLocation();

  // Standard pipeline state
  const [seedInput, setSeedInput] = useState("");
  const [autoEnrich, setAutoEnrich] = useState(true);
  const [autoScrape, setAutoScrape] = useState(true);
  const [autoGeneratePitch, setAutoGeneratePitch] = useState(true);
  const [pipelineResult, setPipelineResult] = useState<any>(null);

  // Competitor targeting state
  const [competitorSeedInput, setCompetitorSeedInput] = useState("");
  const [selectedNetworks, setSelectedNetworks] = useState<string[]>(["Monetag", "PropellerAds", "AdSterra", "Galaksion"]);
  const [similarPerDomain, setSimilarPerDomain] = useState(10);
  const [competitorResult, setCompetitorResult] = useState<any>(null);

  const utils = trpc.useUtils();

  const runPipeline = trpc.agent.runFullPipeline.useMutation({
    onSuccess: (data) => {
      setPipelineResult(data);
      utils.publishers.list.invalidate();
      utils.publishers.stats.invalidate();
      toast.success("Agent pipeline completed!");
    },
    onError: (err) => toast.error(err.message),
  });

  const bulkEnrich = trpc.agent.bulkEnrich.useMutation({
    onSuccess: (data) => {
      utils.publishers.list.invalidate();
      toast.success(`Enriched ${data.enriched} leads`);
    },
    onError: (err) => toast.error(err.message),
  });

  const runCompetitorDiscovery = trpc.competitorDiscovery.runBulk.useMutation({
    onSuccess: (data) => {
      setCompetitorResult(data);
      utils.publishers.list.invalidate();
      utils.publishers.stats.invalidate();
      toast.success(`Found ${data.totalFound} similar sites, imported ${data.importedCount} new leads!`);
    },
    onError: (err) => toast.error(err.message),
  });

  const handleRunPipeline = () => {
    const seeds = seedInput
      .split(/[,\n]/)
      .map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
      .filter(Boolean);
    if (seeds.length === 0) {
      toast.error("Enter at least one seed domain");
      return;
    }
    setPipelineResult(null);
    runPipeline.mutate({ seedDomains: seeds, autoEnrich, autoScrape, autoGeneratePitch });
  };

  const handleRunCompetitor = () => {
    const seeds = competitorSeedInput
      .split(/[,\n]/)
      .map((d) => d.trim().toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, ''))
      .filter(Boolean);
    if (seeds.length === 0) {
      toast.error("Enter at least one seed domain that uses competitor ads");
      return;
    }
    if (selectedNetworks.length === 0) {
      toast.error("Select at least one competitor network");
      return;
    }
    setCompetitorResult(null);
    runCompetitorDiscovery.mutate({
      seedDomains: seeds,
      competitorNetworks: selectedNetworks,
      similarPerDomain,
      autoImport: true,
    });
  };

  const toggleNetwork = (name: string) => {
    setSelectedNetworks(prev =>
      prev.includes(name) ? prev.filter(n => n !== name) : [...prev, name]
    );
  };

  const getStepStatus = (stepKey: string) => {
    if (!pipelineResult?.log) return "idle";
    const stepLogs = pipelineResult.log.filter((l: any) => l.step === stepKey);
    const lastLog = stepLogs[stepLogs.length - 1];
    return lastLog?.status || "idle";
  };

  const getStepDetail = (stepKey: string) => {
    if (!pipelineResult?.log) return null;
    const stepLogs = pipelineResult.log.filter((l: any) => l.step === stepKey);
    const lastLog = stepLogs[stepLogs.length - 1];
    return lastLog?.detail || null;
  };

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight flex items-center gap-3">
          <Bot className="h-6 w-6 text-primary" />
          Autonomous Agent
        </h1>
        <p className="text-muted-foreground mt-1">
          Automated publisher discovery, enrichment, and outreach pipeline
        </p>
      </div>

      <Tabs defaultValue="competitor" className="space-y-4">
        <TabsList className="bg-muted/50">
          <TabsTrigger value="competitor" className="flex items-center gap-2">
            <Target className="h-3.5 w-3.5" />
            Competitor Targeting
          </TabsTrigger>
          <TabsTrigger value="standard" className="flex items-center gap-2">
            <Search className="h-3.5 w-3.5" />
            Standard Pipeline
          </TabsTrigger>
        </TabsList>

        {/* ─── COMPETITOR TARGETING TAB ─── */}
        <TabsContent value="competitor" className="space-y-4">
          <Card className="bg-card border-border/50">
            <CardHeader>
              <CardTitle className="text-base font-medium flex items-center gap-2">
                <Target className="h-4 w-4 text-primary" />
                Competitor Targeting Mode
              </CardTitle>
              <p className="text-sm text-muted-foreground">
                Enter domains that use competitor pop-up networks. For each domain, the AI will find
                <strong className="text-foreground"> {similarPerDomain} similar sites</strong> and import them to your pipeline.
              </p>
            </CardHeader>
            <CardContent className="space-y-5">
              {/* Seed Domains */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Seed Domains (using competitor ads)</label>
                <Input
                  placeholder="fmovies.to, katfile.com, uploaded.net, ..."
                  value={competitorSeedInput}
                  onChange={(e) => setCompetitorSeedInput(e.target.value)}
                  className="bg-input border-border"
                />
                <p className="text-xs text-muted-foreground">
                  These are sites you know use competitor pop-up networks. The agent will find similar sites.
                </p>
              </div>

              {/* Competitor Networks */}
              <div className="space-y-2">
                <label className="text-sm font-medium">Target Competitor Networks</label>
                <div className="flex flex-wrap gap-2">
                  {COMPETITOR_NETWORKS.map((net) => (
                    <button
                      key={net.name}
                      onClick={() => toggleNetwork(net.name)}
                      className={`px-3 py-1.5 rounded-full text-xs font-medium border transition-all ${
                        selectedNetworks.includes(net.name)
                          ? net.color
                          : "bg-muted/30 text-muted-foreground border-border/30 opacity-50"
                      }`}
                    >
                      {net.name}
                    </button>
                  ))}
                </div>
                <p className="text-xs text-muted-foreground">
                  Sites using these networks are your best prospects — they already monetize with pop-ups.
                </p>
              </div>

              {/* Similar per domain */}
              <div className="flex items-center justify-between p-3 rounded-lg border border-border/50">
                <div>
                  <p className="text-sm font-medium">Similar Sites per Domain</p>
                  <p className="text-xs text-muted-foreground">How many similar sites to find for each seed</p>
                </div>
                <div className="flex items-center gap-2">
                  <button
                    onClick={() => setSimilarPerDomain(Math.max(5, similarPerDomain - 5))}
                    className="w-7 h-7 rounded border border-border flex items-center justify-center text-sm hover:bg-accent"
                  >-</button>
                  <span className="text-sm font-bold w-6 text-center">{similarPerDomain}</span>
                  <button
                    onClick={() => setSimilarPerDomain(Math.min(20, similarPerDomain + 5))}
                    className="w-7 h-7 rounded border border-border flex items-center justify-center text-sm hover:bg-accent"
                  >+</button>
                </div>
              </div>

              <Button
                onClick={handleRunCompetitor}
                disabled={runCompetitorDiscovery.isPending || !competitorSeedInput.trim()}
                size="lg"
                className="w-full"
              >
                {runCompetitorDiscovery.isPending ? (
                  <Loader2 className="h-5 w-5 animate-spin mr-2" />
                ) : (
                  <Target className="h-5 w-5 mr-2" />
                )}
                {runCompetitorDiscovery.isPending
                  ? `Finding ${similarPerDomain} similar sites per domain...`
                  : `Find ${similarPerDomain} Similar Sites per Domain`}
              </Button>
            </CardContent>
          </Card>

          {/* Competitor Results */}
          {runCompetitorDiscovery.isPending && (
            <Card className="bg-card border-border/50">
              <CardContent className="p-8 flex flex-col items-center gap-3">
                <Loader2 className="h-8 w-8 animate-spin text-primary" />
                <p className="text-muted-foreground">Running parallel discovery across all seed domains...</p>
                <p className="text-xs text-muted-foreground">This may take 30-60 seconds</p>
              </CardContent>
            </Card>
          )}

          {competitorResult && (
            <Card className="bg-card border-primary/20">
              <CardHeader>
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-400" />
                  Discovery Complete
                </CardTitle>
              </CardHeader>
              <CardContent className="space-y-4">
                <div className="grid grid-cols-3 gap-4">
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{competitorResult.totalFound}</p>
                    <p className="text-xs text-muted-foreground">Sites Found</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold text-emerald-400">{competitorResult.importedCount}</p>
                    <p className="text-xs text-muted-foreground">Imported</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{competitorResult.byDomain?.length || 0}</p>
                    <p className="text-xs text-muted-foreground">Seed Domains</p>
                  </div>
                </div>

                {/* Per-domain breakdown */}
                {competitorResult.byDomain && competitorResult.byDomain.length > 0 && (
                  <div className="space-y-3">
                    <p className="text-sm font-medium">Results by Seed Domain:</p>
                    {competitorResult.byDomain.map((item: any, i: number) => (
                      <div key={i} className="p-3 rounded-lg border border-border/40">
                        <div className="flex items-center justify-between mb-2">
                          <span className="text-sm font-medium">{item.seedDomain}</span>
                          <Badge variant="secondary" className="text-xs">{item.competitorNetwork}</Badge>
                        </div>
                        <div className="flex flex-wrap gap-1.5">
                          {item.similarSites.slice(0, 5).map((site: any, j: number) => (
                            <span
                              key={j}
                              className="text-xs px-2 py-0.5 rounded bg-primary/10 text-primary cursor-pointer hover:bg-primary/20"
                              onClick={() => setLocation('/pipeline')}
                            >
                              {site.domain}
                            </span>
                          ))}
                          {item.similarSites.length > 5 && (
                            <span className="text-xs text-muted-foreground">+{item.similarSites.length - 5} more</span>
                          )}
                        </div>
                      </div>
                    ))}
                  </div>
                )}

                <Button variant="outline" onClick={() => setLocation('/pipeline')} className="w-full">
                  <Users className="h-4 w-4 mr-2" />
                  View All in Pipeline
                </Button>
              </CardContent>
            </Card>
          )}
        </TabsContent>

        {/* ─── STANDARD PIPELINE TAB ─── */}
        <TabsContent value="standard" className="space-y-4">
          <Card className="bg-card border-border/50">
            <CardHeader>
              <CardTitle className="text-base font-medium">Standard Pipeline Configuration</CardTitle>
            </CardHeader>
            <CardContent className="space-y-6">
              <div className="space-y-2">
                <label className="text-sm font-medium">Seed Domains</label>
                <Input
                  placeholder="katfile.com, uploaded.net, rapidgator.net"
                  value={seedInput}
                  onChange={(e) => setSeedInput(e.target.value)}
                  className="bg-input border-border"
                />
              </div>

              <div className="grid grid-cols-1 md:grid-cols-3 gap-4">
                <div className="flex items-center justify-between p-3 rounded-lg border border-border/50">
                  <div>
                    <p className="text-sm font-medium">Auto-Enrich</p>
                    <p className="text-xs text-muted-foreground">Analyze domains with AI</p>
                  </div>
                  <Switch checked={autoEnrich} onCheckedChange={setAutoEnrich} />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg border border-border/50">
                  <div>
                    <p className="text-sm font-medium">Auto-Scrape</p>
                    <p className="text-xs text-muted-foreground">Find contacts on sites</p>
                  </div>
                  <Switch checked={autoScrape} onCheckedChange={setAutoScrape} />
                </div>
                <div className="flex items-center justify-between p-3 rounded-lg border border-border/50">
                  <div>
                    <p className="text-sm font-medium">Auto-Pitch</p>
                    <p className="text-xs text-muted-foreground">Generate outreach emails</p>
                  </div>
                  <Switch checked={autoGeneratePitch} onCheckedChange={setAutoGeneratePitch} />
                </div>
              </div>

              <div className="flex gap-3">
                <Button
                  onClick={handleRunPipeline}
                  disabled={runPipeline.isPending || !seedInput.trim()}
                  size="lg"
                  className="flex-1"
                >
                  {runPipeline.isPending ? (
                    <Loader2 className="h-5 w-5 animate-spin mr-2" />
                  ) : (
                    <Play className="h-5 w-5 mr-2" />
                  )}
                  {runPipeline.isPending ? "Running..." : "Run Full Pipeline"}
                </Button>
                <Button
                  variant="outline"
                  onClick={() => bulkEnrich.mutate({ limit: 10 })}
                  disabled={bulkEnrich.isPending}
                >
                  {bulkEnrich.isPending ? <Loader2 className="h-4 w-4 animate-spin mr-2" /> : <Sparkles className="h-4 w-4 mr-2" />}
                  Bulk Enrich
                </Button>
              </div>
            </CardContent>
          </Card>

          {/* Pipeline Steps */}
          <Card className="bg-card border-border/50">
            <CardHeader>
              <CardTitle className="text-base font-medium">Pipeline Steps</CardTitle>
            </CardHeader>
            <CardContent>
              <div className="space-y-4">
                {PIPELINE_STEPS.map((step, idx) => {
                  const status = getStepStatus(step.key);
                  const detail = getStepDetail(step.key);
                  const Icon = step.icon;

                  return (
                    <div
                      key={step.key}
                      className={`flex items-center gap-4 p-4 rounded-lg border transition-colors ${
                        status === "done" ? "border-emerald-500/30 bg-emerald-500/5" :
                        status === "running" ? "border-primary/30 bg-primary/5" :
                        status === "error" ? "border-red-500/30 bg-red-500/5" :
                        "border-border/50"
                      }`}
                    >
                      <div className={`w-10 h-10 rounded-lg flex items-center justify-center shrink-0 ${
                        status === "done" ? "bg-emerald-500/10" :
                        status === "running" ? "bg-primary/10" :
                        status === "error" ? "bg-red-500/10" :
                        "bg-muted"
                      }`}>
                        {status === "done" ? <CheckCircle className="h-5 w-5 text-emerald-400" /> :
                         status === "running" ? <Loader2 className="h-5 w-5 text-primary animate-spin" /> :
                         status === "error" ? <XCircle className="h-5 w-5 text-red-400" /> :
                         <Icon className="h-5 w-5 text-muted-foreground" />}
                      </div>
                      <div className="flex-1">
                        <div className="flex items-center gap-2">
                          <p className="text-sm font-medium">{step.label}</p>
                          {status !== "idle" && (
                            <Badge variant="secondary" className={`text-xs ${
                              status === "done" ? "bg-emerald-500/10 text-emerald-400" :
                              status === "running" ? "bg-primary/10 text-primary" :
                              status === "error" ? "bg-red-500/10 text-red-400" : ""
                            }`}>
                              {status}
                            </Badge>
                          )}
                        </div>
                        <p className="text-xs text-muted-foreground mt-0.5">
                          {detail || step.description}
                        </p>
                      </div>
                    </div>
                  );
                })}
              </div>
            </CardContent>
          </Card>

          {/* Results Summary */}
          {pipelineResult?.summary && (
            <Card className="bg-card border-primary/20">
              <CardHeader>
                <CardTitle className="text-base font-medium flex items-center gap-2">
                  <CheckCircle className="h-4 w-4 text-emerald-400" />
                  Pipeline Complete
                </CardTitle>
              </CardHeader>
              <CardContent>
                <div className="grid grid-cols-2 md:grid-cols-5 gap-4">
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{pipelineResult.summary.discovered}</p>
                    <p className="text-xs text-muted-foreground">Discovered</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{pipelineResult.summary.imported}</p>
                    <p className="text-xs text-muted-foreground">Imported</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{pipelineResult.summary.enriched}</p>
                    <p className="text-xs text-muted-foreground">Enriched</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{pipelineResult.summary.contactsScraped}</p>
                    <p className="text-xs text-muted-foreground">Contacts</p>
                  </div>
                  <div className="text-center p-3 rounded-lg bg-muted/30">
                    <p className="text-2xl font-bold">{pipelineResult.summary.pitchesGenerated}</p>
                    <p className="text-xs text-muted-foreground">Pitches</p>
                  </div>
                </div>
              </CardContent>
            </Card>
          )}
        </TabsContent>
      </Tabs>
    </div>
  );
}
