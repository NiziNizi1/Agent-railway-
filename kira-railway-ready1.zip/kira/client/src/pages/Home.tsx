import { trpc } from "@/lib/trpc";
import { Card, CardContent, CardHeader, CardTitle } from "@/components/ui/card";
import { Users, Mail, MessageSquare, TrendingUp, Target, CheckCircle } from "lucide-react";
import { BarChart, Bar, XAxis, YAxis, CartesianGrid, Tooltip, ResponsiveContainer, PieChart, Pie, Cell } from "recharts";

const STATUS_COLORS: Record<string, string> = {
  new: "#6366f1",
  cold_outreach_sent: "#f59e0b",
  follow_up: "#3b82f6",
  warm: "#f97316",
  converted: "#10b981",
  rejected: "#ef4444",
};

const STATUS_LABELS: Record<string, string> = {
  new: "New",
  cold_outreach_sent: "Cold Outreach Sent",
  follow_up: "Follow-up",
  warm: "Warm",
  converted: "Converted",
  rejected: "Rejected",
};

export default function Home() {
  const { data: stats, isLoading } = trpc.publishers.stats.useQuery();
  const { data: publishers } = trpc.publishers.list.useQuery();

  const pipelineData = stats?.byStatus
    ? Object.entries(stats.byStatus).map(([status, count]) => ({
        name: STATUS_LABELS[status] || status,
        value: count as number,
        color: STATUS_COLORS[status] || "#6b7280",
      }))
    : [];

  const metricsCards = [
    { title: "Total Leads", value: stats?.total || 0, icon: Users, color: "text-primary" },
    { title: "Emails Sent", value: stats?.totalEmailsSent || 0, icon: Mail, color: "text-amber-400" },
    { title: "Replies", value: stats?.totalReplies || 0, icon: MessageSquare, color: "text-emerald-400" },
    { title: "Open Rate", value: `${stats?.openRate || 0}%`, icon: Target, color: "text-blue-400" },
    { title: "Reply Rate", value: `${stats?.replyRate || 0}%`, icon: TrendingUp, color: "text-orange-400" },
    { title: "Conversion", value: `${stats?.conversionRate || 0}%`, icon: CheckCircle, color: "text-emerald-400" },
  ];

  if (isLoading) {
    return (
      <div className="space-y-6">
        <div>
          <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
          <p className="text-muted-foreground mt-1">Campaign performance overview</p>
        </div>
        <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
          {[...Array(6)].map((_, i) => (
            <Card key={i} className="animate-pulse">
              <CardContent className="p-6">
                <div className="h-16 bg-muted rounded" />
              </CardContent>
            </Card>
          ))}
        </div>
      </div>
    );
  }

  return (
    <div className="space-y-6">
      <div>
        <h1 className="text-2xl font-semibold tracking-tight">Dashboard</h1>
        <p className="text-muted-foreground mt-1">Campaign performance overview</p>
      </div>

      {/* Metrics Cards */}
      <div className="grid grid-cols-1 md:grid-cols-2 lg:grid-cols-3 gap-4">
        {metricsCards.map((metric) => (
          <Card key={metric.title} className="bg-card border-border/50 hover:border-border transition-colors">
            <CardContent className="p-6">
              <div className="flex items-center justify-between">
                <div>
                  <p className="text-sm text-muted-foreground">{metric.title}</p>
                  <p className="text-3xl font-bold mt-1">{metric.value}</p>
                </div>
                <metric.icon className={`h-8 w-8 ${metric.color} opacity-80`} />
              </div>
            </CardContent>
          </Card>
        ))}
      </div>

      {/* Charts */}
      <div className="grid grid-cols-1 lg:grid-cols-2 gap-6">
        {/* Pipeline Distribution */}
        <Card className="bg-card border-border/50">
          <CardHeader>
            <CardTitle className="text-base font-medium">Pipeline Distribution</CardTitle>
          </CardHeader>
          <CardContent>
            {pipelineData.length > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <PieChart>
                  <Pie
                    data={pipelineData}
                    cx="50%"
                    cy="50%"
                    innerRadius={60}
                    outerRadius={100}
                    paddingAngle={2}
                    dataKey="value"
                  >
                    {pipelineData.map((entry, index) => (
                      <Cell key={`cell-${index}`} fill={entry.color} />
                    ))}
                  </Pie>
                  <Tooltip
                    contentStyle={{ backgroundColor: 'oklch(0.19 0.012 260)', border: '1px solid oklch(0.28 0.012 260)', borderRadius: '8px' }}
                    labelStyle={{ color: 'oklch(0.93 0.005 260)' }}
                    itemStyle={{ color: 'oklch(0.85 0.005 260)' }}
                  />
                </PieChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[280px] text-muted-foreground">
                No data yet. Import domains to get started.
              </div>
            )}
            {pipelineData.length > 0 && (
              <div className="flex flex-wrap gap-3 mt-4">
                {pipelineData.map((entry) => (
                  <div key={entry.name} className="flex items-center gap-2 text-xs">
                    <div className="w-3 h-3 rounded-full" style={{ backgroundColor: entry.color }} />
                    <span className="text-muted-foreground">{entry.name}: {entry.value}</span>
                  </div>
                ))}
              </div>
            )}
          </CardContent>
        </Card>

        {/* Campaign Performance */}
        <Card className="bg-card border-border/50">
          <CardHeader>
            <CardTitle className="text-base font-medium">Campaign Metrics</CardTitle>
          </CardHeader>
          <CardContent>
            {(stats?.totalEmailsSent || 0) > 0 ? (
              <ResponsiveContainer width="100%" height={280}>
                <BarChart data={[
                  { name: "Sent", value: stats?.totalEmailsSent || 0 },
                  { name: "Opened", value: Math.round((stats?.totalEmailsSent || 0) * (stats?.openRate || 0) / 100) },
                  { name: "Replied", value: stats?.totalReplies || 0 },
                  { name: "Converted", value: (stats?.byStatus as any)?.converted || 0 },
                ]}>
                  <CartesianGrid strokeDasharray="3 3" stroke="oklch(0.28 0.012 260)" />
                  <XAxis dataKey="name" stroke="oklch(0.65 0.015 260)" fontSize={12} />
                  <YAxis stroke="oklch(0.65 0.015 260)" fontSize={12} />
                  <Tooltip
                    contentStyle={{ backgroundColor: 'oklch(0.19 0.012 260)', border: '1px solid oklch(0.28 0.012 260)', borderRadius: '8px' }}
                    labelStyle={{ color: 'oklch(0.93 0.005 260)' }}
                    itemStyle={{ color: 'oklch(0.85 0.005 260)' }}
                  />
                  <Bar dataKey="value" fill="oklch(0.65 0.19 250)" radius={[4, 4, 0, 0]} />
                </BarChart>
              </ResponsiveContainer>
            ) : (
              <div className="flex items-center justify-center h-[280px] text-muted-foreground">
                No campaign data yet. Send outreach to see metrics.
              </div>
            )}
          </CardContent>
        </Card>
      </div>

      {/* Recent Leads */}
      {publishers && publishers.length > 0 && (
        <Card className="bg-card border-border/50">
          <CardHeader>
            <CardTitle className="text-base font-medium">Recent Leads</CardTitle>
          </CardHeader>
          <CardContent>
            <div className="space-y-3">
              {publishers.slice(0, 5).map((pub: any) => (
                <div key={pub.id} className="flex items-center justify-between py-2 border-b border-border/30 last:border-0">
                  <div className="flex items-center gap-3">
                    <div className="w-8 h-8 rounded-lg bg-primary/10 flex items-center justify-center">
                      <span className="text-xs font-medium text-primary">{pub.domain.charAt(0).toUpperCase()}</span>
                    </div>
                    <div>
                      <p className="text-sm font-medium">{pub.domain}</p>
                      <p className="text-xs text-muted-foreground">{pub.category || "Uncategorized"}</p>
                    </div>
                  </div>
                  <div className="flex items-center gap-3">
                    {pub.score && (
                      <span className="text-xs font-medium px-2 py-1 rounded-full bg-primary/10 text-primary">
                        Score: {pub.score}
                      </span>
                    )}
                    <span className={`text-xs px-2 py-1 rounded-full ${getStatusStyle(pub.status)}`}>
                      {STATUS_LABELS[pub.status] || pub.status}
                    </span>
                  </div>
                </div>
              ))}
            </div>
          </CardContent>
        </Card>
      )}
    </div>
  );
}

function getStatusStyle(status: string): string {
  switch (status) {
    case "new": return "bg-indigo-500/10 text-indigo-400";
    case "cold_outreach_sent": return "bg-amber-500/10 text-amber-400";
    case "follow_up": return "bg-blue-500/10 text-blue-400";
    case "warm": return "bg-orange-500/10 text-orange-400";
    case "converted": return "bg-emerald-500/10 text-emerald-400";
    case "rejected": return "bg-red-500/10 text-red-400";
    default: return "bg-muted text-muted-foreground";
  }
}
