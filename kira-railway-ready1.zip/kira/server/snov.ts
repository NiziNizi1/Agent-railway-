/**
 * Snov.io API Integration
 * - OAuth2 token authentication
 * - Domain email search
 * - Email verification
 * - Email finder by domain + name
 */
import axios from "axios";

const SNOV_API_BASE = "https://api.snov.io";

let cachedToken: { token: string; expiresAt: number } | null = null;

/**
 * Get OAuth2 access token from Snov.io
 */
async function getAccessToken(): Promise<string> {
  // Return cached token if still valid
  if (cachedToken && Date.now() < cachedToken.expiresAt) {
    return cachedToken.token;
  }

  const clientId = process.env.SNOV_CLIENT_ID;
  const clientSecret = process.env.SNOV_CLIENT_SECRET;

  if (!clientId || !clientSecret) {
    throw new Error("Snov.io credentials not configured");
  }

  const response = await axios.post(`${SNOV_API_BASE}/v1/oauth/access_token`, {
    grant_type: "client_credentials",
    client_id: clientId,
    client_secret: clientSecret,
  });

  const token = response.data.access_token;
  // Cache for 1 hour (Snov tokens typically last longer, but be safe)
  cachedToken = { token, expiresAt: Date.now() + 3600 * 1000 };
  return token;
}

/**
 * Search for emails by domain
 */
export async function snovDomainSearch(domain: string, limit: number = 10): Promise<{
  success: boolean;
  emails: Array<{
    email: string;
    firstName?: string;
    lastName?: string;
    position?: string;
    type?: string;
    status?: string;
  }>;
  error?: string;
}> {
  try {
    const token = await getAccessToken();
    // Use GET request with query params (not POST)
    const response = await axios.get(`${SNOV_API_BASE}/v2/domain-emails-with-info`, {
      params: {
        access_token: token,
        domain,
        type: "all",
        limit,
      },
    });

    if (response.data && response.data.data) {
      return {
        success: true,
        emails: response.data.data.map((e: any) => ({
          email: e.email,
          firstName: e.firstName || e.first_name,
          lastName: e.lastName || e.last_name,
          position: e.position,
          type: e.type,
          status: e.status,
        })),
      };
    }

    return { success: true, emails: [] };
  } catch (error: any) {
    return {
      success: false,
      emails: [],
      error: error.response?.data?.errors?.title || error.response?.data?.message || error.message || "Snov.io API error",
    };
  }
}

/**
 * Verify an email address
 */
export async function snovVerifyEmail(email: string): Promise<{
  success: boolean;
  result?: string;
  error?: string;
}> {
  try {
    const token = await getAccessToken();

    // First, add email to verification list
    await axios.post(`${SNOV_API_BASE}/v1/add-emails-to-verification`, {
      access_token: token,
      emails: [email],
    });

    // Then check verification status
    const response = await axios.post(`${SNOV_API_BASE}/v1/get-emails-verification-status`, {
      access_token: token,
      emails: [email],
    });

    if (response.data && response.data.length > 0) {
      return {
        success: true,
        result: response.data[0]?.result || "pending",
      };
    }

    return { success: true, result: "pending" };
  } catch (error: any) {
    return {
      success: false,
      error: error.response?.data?.message || error.message || "Verification failed",
    };
  }
}

/**
 * Get email count for a domain (lightweight check)
 */
export async function snovGetEmailCount(domain: string): Promise<{
  success: boolean;
  count?: number;
  error?: string;
}> {
  try {
    const token = await getAccessToken();
    const response = await axios.post(`${SNOV_API_BASE}/v1/get-domain-emails-count`, {
      access_token: token,
      domain,
    });

    return {
      success: true,
      count: response.data?.result || 0,
    };
  } catch (error: any) {
    return {
      success: false,
      error: error.response?.data?.message || error.message || "API error",
    };
  }
}

/**
 * Test the Snov.io connection (used for credential validation)
 */
export async function testSnovConnection(): Promise<{ success: boolean; error?: string }> {
  try {
    await getAccessToken();
    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
