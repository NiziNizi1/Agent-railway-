/**
 * Smart Scrape Orchestrator (Railway-ready, production-grade)
 *
 * Single entry point for all publisher scraping operations.
 * Strategy: try Apify first (cloud, residential proxies, scaling), fall back
 * to in-process Playwright if Apify is unavailable, fails, or returns nothing
 * useful. This gives us:
 *
 *   - Zero-config local dev:        Apify key absent → Playwright runs
 *   - Production scale:             Apify key present → Apify runs
 *   - Resilience:                   Apify timeout/error → Playwright takes over
 *   - Dual-stack confidence:        Optional MERGE mode runs both and merges
 *
 * Forced override via `SCRAPER_STRATEGY` env var:
 *   - "apify"      → only Apify; never falls back (good for cost control)
 *   - "playwright" → only Playwright; never tries Apify
 *   - "auto"       → Apify with Playwright fallback (DEFAULT)
 *   - "merge"      → run both, merge results (highest recall, 2x cost)
 *
 * Per-call override is also supported via the `strategy` argument — useful
 * for operations where you know one path is better (e.g., always use Apify
 * for high-traffic sites, always use Playwright for protocol-heavy detection).
 */

import {
  apifyScrapeContacts,
  apifyScrapeAdNetworks,
} from "./apify";
import {
  scrapeContactsFromWebsite,
  type ScrapedContacts,
} from "./mcp-integrations";
import {
  detectAdsOnWebsite,
  type AdDetectionResult,
  type DetectedAd,
} from "./ad-detection";

// ─── Types ──────────────────────────────────────────────────────────────────

export type ScraperStrategy = "auto" | "apify" | "playwright" | "merge";

export interface UnifiedContactResult {
  emails: string[];
  phones: string[];
  socialLinks: string[];
  title?: string;
  description?: string;
  /** Which engine produced these results. */
  source: "apify" | "playwright" | "merge";
  /** True if at least one engine succeeded. */
  success: boolean;
  error?: string;
}

export interface UnifiedAdDetectionResult {
  detectedAds: DetectedAd[];
  scripts: string[];
  source: "apify" | "playwright" | "merge";
  success: boolean;
  error?: string;
}

// ─── Strategy resolution ────────────────────────────────────────────────────

function resolveStrategy(override?: ScraperStrategy): ScraperStrategy {
  if (override) return override;
  const envStrat = (process.env.SCRAPER_STRATEGY || "auto").toLowerCase() as ScraperStrategy;
  if (envStrat === "apify" || envStrat === "playwright" || envStrat === "merge") {
    return envStrat;
  }
  return "auto";
}

function isApifyConfigured(): boolean {
  return Boolean(process.env.APIFY_API_KEY && process.env.APIFY_API_KEY.length > 10);
}

function dedupe(arr: string[]): string[] {
  const seen = new Set<string>();
  const out: string[] = [];
  for (const item of arr) {
    if (!item) continue;
    const key = item.toLowerCase();
    if (seen.has(key)) continue;
    seen.add(key);
    out.push(item);
  }
  return out;
}

/**
 * Heuristic: does this contact result actually contain anything useful?
 * Used to decide whether to fall back to the secondary engine in "auto" mode.
 */
function isContactResultUseful(result: UnifiedContactResult): boolean {
  return (
    result.success &&
    (result.emails.length > 0 ||
      result.socialLinks.length > 0 ||
      result.phones.length > 0)
  );
}

function isAdResultUseful(result: UnifiedAdDetectionResult): boolean {
  return result.success && result.detectedAds.length > 0;
}

// ─── Adapters: convert engine-specific shapes → unified shape ───────────────

function adaptApifyContacts(
  domain: string,
  raw: Awaited<ReturnType<typeof apifyScrapeContacts>>
): UnifiedContactResult {
  return {
    emails: dedupe(raw.emails || []),
    phones: dedupe(raw.phones || []),
    socialLinks: dedupe(raw.socialLinks || []),
    title: raw.title,
    description: raw.description,
    source: "apify",
    success: raw.success,
    error: raw.error,
  };
}

function adaptPlaywrightContacts(
  raw: ScrapedContacts
): UnifiedContactResult {
  return {
    emails: dedupe(raw.emails || []),
    phones: dedupe(raw.phones || []),
    socialLinks: dedupe(raw.socialLinks || []),
    source: "playwright",
    success: !raw.error,
    error: raw.error,
  };
}

function adaptApifyAds(
  raw: Awaited<ReturnType<typeof apifyScrapeAdNetworks>>
): UnifiedAdDetectionResult {
  // apify.ts returns { adSignals: string[] }; normalize to DetectedAd shape.
  // We mark these as "high" confidence because Apify's analysis runs against
  // the rendered page (same standard our local detector uses).
  const detectedAds: DetectedAd[] = (raw.adSignals || []).map(network => ({
    network,
    format: "Detected via Apify",
    confidence: "high" as const,
    evidence: "Apify ad-network scraper",
  }));

  return {
    detectedAds,
    scripts: raw.scripts || [],
    source: "apify",
    success: raw.success,
    error: raw.error,
  };
}

function adaptPlaywrightAds(raw: AdDetectionResult): UnifiedAdDetectionResult {
  return {
    detectedAds: raw.detectedAds || [],
    scripts: raw.scripts || [],
    source: "playwright",
    success: !raw.error,
    error: raw.error,
  };
}

// ─── Merge logic (for SCRAPER_STRATEGY=merge) ───────────────────────────────

function mergeContacts(
  a: UnifiedContactResult,
  b: UnifiedContactResult
): UnifiedContactResult {
  return {
    emails: dedupe([...a.emails, ...b.emails]),
    phones: dedupe([...a.phones, ...b.phones]),
    socialLinks: dedupe([...a.socialLinks, ...b.socialLinks]),
    title: a.title || b.title,
    description: a.description || b.description,
    source: "merge",
    success: a.success || b.success,
    error: a.success || b.success ? undefined : a.error || b.error,
  };
}

function mergeAds(
  a: UnifiedAdDetectionResult,
  b: UnifiedAdDetectionResult
): UnifiedAdDetectionResult {
  // Prefer "high" confidence detection if the same network shows up in both
  const byNetwork = new Map<string, DetectedAd>();
  for (const ad of [...a.detectedAds, ...b.detectedAds]) {
    const existing = byNetwork.get(ad.network);
    if (!existing) {
      byNetwork.set(ad.network, ad);
      continue;
    }
    // Upgrade confidence if the new one is higher
    const order = { high: 3, medium: 2, low: 1 };
    if (order[ad.confidence] > order[existing.confidence]) {
      byNetwork.set(ad.network, ad);
    }
  }

  return {
    detectedAds: Array.from(byNetwork.values()),
    scripts: dedupe([...a.scripts, ...b.scripts]),
    source: "merge",
    success: a.success || b.success,
    error: a.success || b.success ? undefined : a.error || b.error,
  };
}

// ─── Public API: contact scraping ───────────────────────────────────────────

export async function scrapeContacts(
  domain: string,
  override?: ScraperStrategy
): Promise<UnifiedContactResult> {
  const strategy = resolveStrategy(override);
  const apifyAvailable = isApifyConfigured();

  // Forced strategies
  if (strategy === "apify") {
    if (!apifyAvailable) {
      return {
        emails: [],
        phones: [],
        socialLinks: [],
        source: "apify",
        success: false,
        error: "APIFY_API_KEY is not configured",
      };
    }
    return adaptApifyContacts(domain, await apifyScrapeContacts(domain));
  }

  if (strategy === "playwright") {
    return adaptPlaywrightContacts(await scrapeContactsFromWebsite(domain));
  }

  if (strategy === "merge") {
    if (!apifyAvailable) {
      return adaptPlaywrightContacts(await scrapeContactsFromWebsite(domain));
    }
    const [apifyRes, pwRes] = await Promise.allSettled([
      apifyScrapeContacts(domain),
      scrapeContactsFromWebsite(domain),
    ]);
    const a =
      apifyRes.status === "fulfilled"
        ? adaptApifyContacts(domain, apifyRes.value)
        : adaptApifyContacts(domain, {
            success: false,
            emails: [],
            phones: [],
            socialLinks: [],
            error: String(apifyRes.reason),
          });
    const b =
      pwRes.status === "fulfilled"
        ? adaptPlaywrightContacts(pwRes.value)
        : adaptPlaywrightContacts({ emails: [], phones: [], socialLinks: [], error: String(pwRes.reason) });
    return mergeContacts(a, b);
  }

  // strategy === "auto" — Apify-first with Playwright fallback
  if (apifyAvailable) {
    try {
      const apifyResult = adaptApifyContacts(
        domain,
        await apifyScrapeContacts(domain)
      );
      if (isContactResultUseful(apifyResult)) return apifyResult;

      // Apify ran but found nothing useful — try Playwright as fallback
      console.log(
        `[scrape] Apify returned no useful contacts for ${domain}, falling back to Playwright`
      );
      const pwResult = adaptPlaywrightContacts(
        await scrapeContactsFromWebsite(domain)
      );
      // Return the better of the two (prefer the one with more emails)
      return pwResult.emails.length > apifyResult.emails.length
        ? pwResult
        : apifyResult;
    } catch (err: any) {
      console.warn(
        `[scrape] Apify threw for ${domain}, falling back to Playwright:`,
        err?.message || err
      );
      return adaptPlaywrightContacts(await scrapeContactsFromWebsite(domain));
    }
  }

  // No Apify key → Playwright only
  return adaptPlaywrightContacts(await scrapeContactsFromWebsite(domain));
}

// ─── Public API: ad-network detection ───────────────────────────────────────

export async function detectAds(
  domain: string,
  override?: ScraperStrategy
): Promise<UnifiedAdDetectionResult> {
  const strategy = resolveStrategy(override);
  const apifyAvailable = isApifyConfigured();

  if (strategy === "apify") {
    if (!apifyAvailable) {
      return {
        detectedAds: [],
        scripts: [],
        source: "apify",
        success: false,
        error: "APIFY_API_KEY is not configured",
      };
    }
    return adaptApifyAds(await apifyScrapeAdNetworks(domain));
  }

  if (strategy === "playwright") {
    return adaptPlaywrightAds(await detectAdsOnWebsite(domain));
  }

  if (strategy === "merge") {
    if (!apifyAvailable) {
      return adaptPlaywrightAds(await detectAdsOnWebsite(domain));
    }
    const [apifyRes, pwRes] = await Promise.allSettled([
      apifyScrapeAdNetworks(domain),
      detectAdsOnWebsite(domain),
    ]);
    const a =
      apifyRes.status === "fulfilled"
        ? adaptApifyAds(apifyRes.value)
        : adaptApifyAds({
            success: false,
            scripts: [],
            adSignals: [],
            error: String(apifyRes.reason),
          });
    const b =
      pwRes.status === "fulfilled"
        ? adaptPlaywrightAds(pwRes.value)
        : adaptPlaywrightAds({ detectedAds: [], scripts: [], error: String(pwRes.reason) });
    return mergeAds(a, b);
  }

  // strategy === "auto" — Apify-first
  if (apifyAvailable) {
    try {
      const apifyResult = adaptApifyAds(await apifyScrapeAdNetworks(domain));
      if (isAdResultUseful(apifyResult)) return apifyResult;

      // Apify found nothing — Playwright with network sniffing usually catches
      // more (it sees actual fired requests, not just static HTML).
      console.log(
        `[detect-ads] Apify returned no signals for ${domain}, falling back to Playwright`
      );
      const pwResult = adaptPlaywrightAds(await detectAdsOnWebsite(domain));
      return pwResult.detectedAds.length > apifyResult.detectedAds.length
        ? pwResult
        : apifyResult;
    } catch (err: any) {
      console.warn(
        `[detect-ads] Apify threw for ${domain}, falling back to Playwright:`,
        err?.message || err
      );
      return adaptPlaywrightAds(await detectAdsOnWebsite(domain));
    }
  }

  return adaptPlaywrightAds(await detectAdsOnWebsite(domain));
}

// ─── Diagnostics (for the `/api/scraper/status` debug endpoint) ────────────

export function getScraperStatus() {
  return {
    apifyConfigured: isApifyConfigured(),
    strategy: resolveStrategy(),
    playwrightChromiumPath:
      process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || "(default)",
  };
}
