import { describe, expect, it } from "vitest";
import { appRouter } from "./routers";
import type { TrpcContext } from "./_core/context";

type AuthenticatedUser = NonNullable<TrpcContext["user"]>;

function createAuthContext(): { ctx: TrpcContext } {
  const user: AuthenticatedUser = {
    id: 1,
    openId: "test-user",
    email: "test@example.com",
    name: "Test User",
    loginMethod: "manus",
    role: "admin",
    createdAt: new Date(),
    updatedAt: new Date(),
    lastSignedIn: new Date(),
  };

  const ctx: TrpcContext = {
    user,
    req: {
      protocol: "https",
      headers: {},
    } as TrpcContext["req"],
    res: {
      clearCookie: () => {},
    } as TrpcContext["res"],
  };

  return { ctx };
}

describe("publishers router", () => {
  it("stats returns expected shape", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const stats = await caller.publishers.stats();

    expect(stats).toHaveProperty("total");
    expect(stats).toHaveProperty("byStatus");
    expect(stats).toHaveProperty("avgScore");
    expect(stats).toHaveProperty("totalEmailsSent");
    expect(stats).toHaveProperty("totalReplies");
    expect(stats).toHaveProperty("openRate");
    expect(stats).toHaveProperty("replyRate");
    expect(stats).toHaveProperty("conversionRate");
    expect(typeof stats.total).toBe("number");
  });

  it("list returns an array", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const publishers = await caller.publishers.list();

    expect(Array.isArray(publishers)).toBe(true);
  });

  it("notifications list returns an array", async () => {
    const { ctx } = createAuthContext();
    const caller = appRouter.createCaller(ctx);

    const notifications = await caller.notifications.list();

    expect(Array.isArray(notifications)).toBe(true);
  });
});
