/**
 * Ad Network Detection Module — Direct Playwright (Railway-ready)
 *
 * Replaces the original `manus-mcp-cli` shell-out approach with in-process
 * Playwright. We also intercept network requests during page load — this gives
 * a much stronger signal than DOM scraping alone, because most ad networks
 * load their tags via redirect chains that don't leave persistent script tags.
 */

import { chromium, type Browser, type Request as PWRequest } from "playwright";

export interface DetectedAd {
  network: string;
  format: string;
  confidence: "high" | "medium" | "low";
  evidence: string;
}

export interface AdDetectionResult {
  detectedAds: DetectedAd[];
  scripts: string[];
  error?: string;
}

// Known ad network signatures (script URLs, domains, variable names)
const AD_SIGNATURES: Array<{ network: string; format: string; patterns: string[] }> = [
  // Pop-ups / Pop-unders
  { network: "Monetag", format: "Pop-under", patterns: ["monetag.com", "trk.monetag", "d-aa.com", "mczbf.com", "a-ads.com/monetag"] },
  { network: "AdSterra", format: "Pop-under", patterns: ["adsterra.com", "astrfrm.com", "adstera", "ad6media", "susession.com"] },
  { network: "PropellerAds", format: "Pop-under", patterns: ["propellerads.com", "propeller-tracking", "propu.sh", "pushprofit.net", "oapropu"] },
  { network: "AdMaven", format: "Pop-under", patterns: ["admaven.com", "ad-maven.com", "admnv.com", "servedbyadmaven"] },
  { network: "PopAds", format: "Pop-under", patterns: ["popads.net", "serve.popads"] },
  { network: "PopCash", format: "Pop-under", patterns: ["popcash.net", "serve.popcash"] },
  { network: "Clickadu", format: "Pop-under", patterns: ["clickadu.com", "vfrfrm.com", "syndication.clickadu"] },

  // Interstitials / Push
  { network: "AdCash", format: "Interstitial/Push", patterns: ["adcash.com", "surfe.pro", "adcash-cdn", "syndication.adcash"] },
  { network: "RichPush", format: "Push", patterns: ["richpush.com", "richpush.co"] },
  { network: "Pushground", format: "Push", patterns: ["pushground.com", "pushground.net"] },
  { network: "Evadav", format: "Push/Native", patterns: ["evadav.com", "syndication.evadav"] },

  // Banners / Display
  { network: "Google AdSense", format: "Banner/Display", patterns: ["pagead2.googlesyndication.com", "adsbygoogle", "google_ad_client", "googleads.g.doubleclick"] },
  { network: "Media.net", format: "Banner/Display", patterns: ["media.net", "contextual.media.net"] },
  { network: "Ezoic", format: "Banner/Display", patterns: ["ezoic.com", "ezoic.net", "ezodn.com"] },
  { network: "Infolinks", format: "Banner/In-text", patterns: ["infolinks.com", "resources.infolinks"] },

  // Native
  { network: "Taboola", format: "Native", patterns: ["taboola.com", "cdn.taboola", "trc.taboola"] },
  { network: "Outbrain", format: "Native", patterns: ["outbrain.com", "widgets.outbrain"] },
  { network: "MGID", format: "Native", patterns: ["mgid.com", "servicer.mgid", "jsc.mgid"] },
  { network: "Revcontent", format: "Native", patterns: ["revcontent.com", "trends.revcontent"] },

  // Video
  { network: "ExoClick", format: "Video/Banner", patterns: ["exoclick.com", "syndication.exoclick"] },
  { network: "TrafficStars", format: "Video/Banner", patterns: ["trafficstars.com", "tsyndicate.com"] },
  { network: "JuicyAds", format: "Video/Banner", patterns: ["juicyads.com", "ads.juicyads"] },

  // Other networks
  { network: "HilltopAds", format: "Pop/Banner", patterns: ["hilltopads.com", "hilltopads.net"] },
  { network: "TrafficForce", format: "Banner/Pop", patterns: ["trafficforce.com", "cdn.trafficforce"] },
  { network: "Bidvertiser", format: "Banner/Pop", patterns: ["bidvertiser.com", "bdv.bidvertiser"] },
  { network: "AdxAd", format: "Pop/Push", patterns: ["adxad.com", "syndication.adxad"] },
];

let _sharedBrowser: Browser | null = null;

async function getBrowser(): Promise<Browser> {
  if (_sharedBrowser && _sharedBrowser.isConnected()) return _sharedBrowser;
  _sharedBrowser = await chromium.launch({
    headless: true,
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || undefined,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
    ],
  });
  return _sharedBrowser;
}

/**
 * Detect ad networks on a website using direct Playwright + network sniffing.
 *
 * Strategy:
 *   1. Open page, capture every outbound request URL.
 *   2. After load, also scrape <script src>, <iframe src>, <link href>, inline scripts.
 *   3. Match known signatures against (a) request URLs and (b) DOM content.
 *      Network-request matches → "high" confidence (ad actually fired).
 *      DOM-URL matches         → "high" confidence (ad tag is embedded).
 *      Inline-script matches   → "medium" confidence (configured but maybe not loaded).
 */
export async function detectAdsOnWebsite(domain: string): Promise<AdDetectionResult> {
  const result: AdDetectionResult = { detectedAds: [], scripts: [] };

  let context;
  let page;
  const requestUrls: string[] = [];

  try {
    const browser = await getBrowser();
    context = await browser.newContext({
      userAgent:
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      viewport: { width: 1366, height: 768 },
    });
    page = await context.newPage();

    page.on("request", (req: PWRequest) => {
      try {
        requestUrls.push(req.url());
      } catch {
        /* ignore */
      }
    });

    const url = `https://${domain}`;
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 25_000 });

    // Wait for ads to load (they often fire 2-3s after DOMContentLoaded)
    await page.waitForTimeout(3500);

    const pageData = await page.evaluate(() => {
      const scripts = Array.from(document.querySelectorAll("script[src]"))
        .map(s => (s as HTMLScriptElement).src);
      const iframes = Array.from(document.querySelectorAll("iframe[src]"))
        .map(f => (f as HTMLIFrameElement).src);
      const links = Array.from(document.querySelectorAll("link[href]"))
        .map(l => (l as HTMLLinkElement).href);
      const inlineScripts = Array.from(
        document.querySelectorAll("script:not([src])")
      ).map(s => (s.textContent || "").substring(0, 500));
      const htmlSnippet = (document.documentElement.innerHTML || "").substring(0, 50_000);
      return { scripts, iframes, links, inlineScripts, htmlSnippet };
    });

    result.scripts = pageData.scripts.slice(0, 20);

    const allUrls: string[] = [
      ...pageData.scripts,
      ...pageData.iframes,
      ...pageData.links,
      ...requestUrls,
    ];

    const allUrlsLower = allUrls.map(u => u.toLowerCase());
    const inlineScriptsLower = pageData.inlineScripts.map(s => s.toLowerCase());
    const htmlSnippetLower = (pageData.htmlSnippet || "").toLowerCase();

    for (const sig of AD_SIGNATURES) {
      for (const pattern of sig.patterns) {
        const patternLower = pattern.toLowerCase();

        const inUrls = allUrlsLower.some(u => u.includes(patternLower));
        const inInline = inlineScriptsLower.some(s => s.includes(patternLower));
        const inHtml = htmlSnippetLower.includes(patternLower);

        if (!inUrls && !inInline && !inHtml) continue;

        if (result.detectedAds.find(a => a.network === sig.network)) break;

        let confidence: "high" | "medium" | "low" = "low";
        let evidence = `Found "${pattern}"`;
        if (inUrls) {
          confidence = "high";
          evidence = `Network/script request to "${pattern}"`;
        } else if (inInline) {
          confidence = "medium";
          evidence = `Inline script references "${pattern}"`;
        } else {
          confidence = "low";
          evidence = `Mention of "${pattern}" in HTML`;
        }

        result.detectedAds.push({
          network: sig.network,
          format: sig.format,
          confidence,
          evidence,
        });
        break;
      }
    }
  } catch (error: any) {
    result.error = error?.message || "Ad detection failed";
  } finally {
    try {
      await page?.close();
    } catch {}
    try {
      await context?.close();
    } catch {}
  }

  return result;
}

/**
 * Returns the list of known ad-network signatures (used by the LLM-fallback
 * path when Playwright is unavailable, and by frontend filters).
 */
export function getAdSignatures() {
  return AD_SIGNATURES.map(s => ({ network: s.network, format: s.format }));
}
