import { describe, expect, it } from "vitest";
import { testApifyConnection } from "./apify";

describe("Apify integration", () => {
  it("can authenticate with Apify API", async () => {
    const result = await testApifyConnection();
    expect(result.success).toBe(true);
    expect(result.error).toBeUndefined();
  }, 15000);
});
