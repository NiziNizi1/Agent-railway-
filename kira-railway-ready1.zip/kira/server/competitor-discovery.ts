/**
 * Competitor-Based Discovery Module
 * 
 * Strategy:
 * 1. Take a list of seed domains that use competitor ad networks (Monetag, PropellerAds, AdSterra, Galaksion)
 * 2. For each seed domain, use SimilarWeb to find 10 similar sites
 * 3. Run parallel processing on all discovered sites
 * 4. Filter out sites already in our pipeline
 */
import { exec } from "child_process";
import { promisify } from "util";
import { parseLLMJson } from "./llm-utils";
import { invokeLLM } from "./_core/llm";

const execAsync = promisify(exec);

export interface SimilarSite {
  domain: string;
  reason: string;
  trafficTier?: string;
  category?: string;
}

export interface CompetitorDiscoveryResult {
  seedDomain: string;
  competitorNetwork: string;
  similarSites: SimilarSite[];
  error?: string;
}

// Target competitor networks
export const TARGET_COMPETITORS = [
  "Monetag",
  "PropellerAds", 
  "AdSterra",
  "Galaksion",
  "PopAds",
  "PopCash",
  "ClickAdu",
  "HilltopAds",
];

/**
 * Find similar sites to a domain using SimilarWeb API (via Python sandbox)
 */
async function getSimilarSitesFromSimilarWeb(domain: string): Promise<string[]> {
  try {
    const script = `
import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
import json
try:
    from data_api import ApiClient
    client = ApiClient()
    
    # Get similar sites using SimilarWeb
    # We'll use the visits data to find related domains
    result = client.call_api('SimilarWeb/get_visits_total',
        path_params={'domain': '${domain}'},
        query={'country': 'world', 'granularity': 'monthly'})
    
    print(json.dumps({'visits': result, 'domain': '${domain}'}))
except Exception as e:
    print(json.dumps({'error': str(e)}))
`.replace(/'/g, "'\\''");

    const { stdout } = await execAsync(`python3 -c '${script}'`, { timeout: 20000 });
    const data = JSON.parse(stdout.trim());
    if (data.error) return [];
    return []; // SimilarWeb doesn't have a direct "similar sites" API, use LLM instead
  } catch (e) {
    return [];
  }
}

/**
 * Find 10 similar sites to a domain using LLM with competitor context
 */
export async function findSimilarSitesForCompetitor(
  domain: string, 
  competitorNetwork: string,
  count: number = 10
): Promise<SimilarSite[]> {
  try {
    const response = await invokeLLM({
      messages: [
        {
          role: "system",
          content: `You are a web analyst specializing in ad network publisher discovery.
Given a website that uses ${competitorNetwork} for monetization, find ${count} similar websites that likely also use pop-under or push notification ad networks.

Focus on finding sites that are:
- Similar content type (same niche/category)
- Similar traffic tier
- Likely to be monetizing with pop-under, push, or interstitial ads
- Good candidates for AdMaven partnership

Return ONLY valid JSON with a "sites" array. Each site has: domain (string), reason (why it's similar), trafficTier (High/Medium/Low), category (string).`
        },
        {
          role: "user",
          content: `Find ${count} similar websites to "${domain}" which uses ${competitorNetwork} pop-under/push ads. These should be sites that would benefit from switching to or adding AdMaven.`
        }
      ],
      response_format: {
        type: "json_schema",
        json_schema: {
          name: "similar_sites",
          strict: true,
          schema: {
            type: "object",
            properties: {
              sites: {
                type: "array",
                items: {
                  type: "object",
                  properties: {
                    domain: { type: "string" },
                    reason: { type: "string" },
                    trafficTier: { type: "string" },
                    category: { type: "string" },
                  },
                  required: ["domain", "reason", "trafficTier", "category"],
                  additionalProperties: false,
                },
              },
            },
            required: ["sites"],
            additionalProperties: false,
          },
        },
      },
    });

    const result = parseLLMJson<{ sites: SimilarSite[] }>(
      response.choices[0].message.content,
      { sites: [] }
    );

    return result.sites || [];
  } catch (e: any) {
    return [];
  }
}

/**
 * Run competitor-based discovery for multiple seed domains in parallel
 */
export async function runCompetitorDiscovery(
  seedDomains: string[],
  competitorNetworks: string[],
  similarPerDomain: number = 10
): Promise<{
  allDiscovered: SimilarSite[];
  byDomain: CompetitorDiscoveryResult[];
  totalFound: number;
}> {
  const byDomain: CompetitorDiscoveryResult[] = [];
  const allDiscovered: SimilarSite[] = [];
  const seenDomains = new Set(seedDomains.map(d => d.toLowerCase()));

  // Process all seed domains in parallel (batches of 3 to avoid rate limits)
  const batchSize = 3;
  for (let i = 0; i < seedDomains.length; i += batchSize) {
    const batch = seedDomains.slice(i, i + batchSize);
    
    const batchResults = await Promise.all(
      batch.map(async (domain) => {
        // Use first competitor network as context (or cycle through them)
        const network = competitorNetworks[i % competitorNetworks.length] || "Monetag";
        
        try {
          const sites = await findSimilarSitesForCompetitor(domain, network, similarPerDomain);
          
          // Filter out already-known domains
          const newSites = sites.filter(s => !seenDomains.has(s.domain.toLowerCase()));
          newSites.forEach(s => seenDomains.add(s.domain.toLowerCase()));
          
          return {
            seedDomain: domain,
            competitorNetwork: network,
            similarSites: newSites,
          };
        } catch (e: any) {
          return {
            seedDomain: domain,
            competitorNetwork: network,
            similarSites: [],
            error: e.message,
          };
        }
      })
    );

    byDomain.push(...batchResults);
    batchResults.forEach(r => allDiscovered.push(...r.similarSites));
  }

  return {
    allDiscovered,
    byDomain,
    totalFound: allDiscovered.length,
  };
}
