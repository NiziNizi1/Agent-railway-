/**
 * Storage proxy — Disabled stub (Railway-ready)
 *
 * The original Manus implementation proxied storage requests through
 * `forge.manus.im`. That backend is not available on Railway, so this is
 * a no-op stub that preserves the import in `_core/index.ts` without
 * registering any routes.
 *
 * If file storage is needed later, replace this with an S3 / R2 / local-disk
 * implementation.
 */

import type { Express } from "express";

export function registerStorageProxy(_app: Express): void {
  // Intentionally empty — file storage is disabled in the Railway build.
  // No /api/storage routes are registered.
}
