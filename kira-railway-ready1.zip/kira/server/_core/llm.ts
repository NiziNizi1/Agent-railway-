/**
 * LLM wrapper — Anthropic Claude (Railway-ready)
 *
 * Replaces the original Manus `forge.manus.im` (Gemini) wrapper.
 * Preserves the EXACT exported types and `invokeLLM()` signature, so the 13
 * existing call sites across the codebase keep working without changes.
 *
 * Translation strategy:
 *   - OpenAI-style messages[] (system / user / assistant / tool) → Anthropic format
 *     (system as top-level string; messages user/assistant only; tool_result blocks).
 *   - OpenAI tools[].function.parameters (JSON Schema) → Anthropic input_schema.
 *   - OpenAI response_format.json_schema → instructions injected into system prompt
 *     plus assistant-prefill ("{") to force JSON-only output. Anthropic follows
 *     this pattern with very high reliability.
 *   - Anthropic response → mapped back into OpenAI-shaped InvokeResult.
 */

import Anthropic from "@anthropic-ai/sdk";
import {
  computeCacheKey,
  isCacheable,
  readFromCache,
  writeToCache,
} from "./llm-cache";

// ─── Public types (UNCHANGED — call sites depend on these) ──────────────────

export type Role = "system" | "user" | "assistant" | "tool" | "function";

export type TextContent = { type: "text"; text: string };

export type ImageContent = {
  type: "image_url";
  image_url: { url: string; detail?: "auto" | "low" | "high" };
};

export type FileContent = {
  type: "file_url";
  file_url: {
    url: string;
    mime_type?: "audio/mpeg" | "audio/wav" | "application/pdf" | "audio/mp4" | "video/mp4";
  };
};

export type MessageContent = string | TextContent | ImageContent | FileContent;

export type Message = {
  role: Role;
  content: MessageContent | MessageContent[];
  name?: string;
  tool_call_id?: string;
};

export type Tool = {
  type: "function";
  function: {
    name: string;
    description?: string;
    parameters?: Record<string, unknown>;
  };
};

export type ToolChoicePrimitive = "none" | "auto" | "required";
export type ToolChoiceByName = { name: string };
export type ToolChoiceExplicit = { type: "function"; function: { name: string } };
export type ToolChoice = ToolChoicePrimitive | ToolChoiceByName | ToolChoiceExplicit;

export type InvokeParams = {
  messages: Message[];
  tools?: Tool[];
  toolChoice?: ToolChoice;
  tool_choice?: ToolChoice;
  maxTokens?: number;
  max_tokens?: number;
  outputSchema?: OutputSchema;
  output_schema?: OutputSchema;
  responseFormat?: ResponseFormat;
  response_format?: ResponseFormat;
};

export type ToolCall = {
  id: string;
  type: "function";
  function: { name: string; arguments: string };
};

export type InvokeResult = {
  id: string;
  created: number;
  model: string;
  choices: Array<{
    index: number;
    message: {
      role: Role;
      content: string | Array<TextContent | ImageContent | FileContent>;
      tool_calls?: ToolCall[];
    };
    finish_reason: string | null;
  }>;
  usage?: {
    prompt_tokens: number;
    completion_tokens: number;
    total_tokens: number;
  };
};

export type JsonSchema = {
  name: string;
  schema: Record<string, unknown>;
  strict?: boolean;
};

export type OutputSchema = JsonSchema;

export type ResponseFormat =
  | { type: "text" }
  | { type: "json_object" }
  | { type: "json_schema"; json_schema: JsonSchema };

// ─── Configuration ──────────────────────────────────────────────────────────

const DEFAULT_MODEL = process.env.ANTHROPIC_MODEL || "claude-sonnet-4-5-20250929";
const DEFAULT_MAX_TOKENS = 8192;

let _client: Anthropic | null = null;
function getClient(): Anthropic {
  if (!_client) {
    const apiKey = process.env.ANTHROPIC_API_KEY;
    if (!apiKey) {
      throw new Error(
        "ANTHROPIC_API_KEY is not configured. Set it in Railway environment variables."
      );
    }
    _client = new Anthropic({ apiKey });
  }
  return _client;
}

// ─── Helpers ────────────────────────────────────────────────────────────────

const ensureArray = <T>(value: T | T[]): T[] => (Array.isArray(value) ? value : [value]);

function partToText(part: MessageContent): string {
  if (typeof part === "string") return part;
  if (part.type === "text") return part.text;
  if (part.type === "image_url") return `[image: ${part.image_url.url}]`;
  if (part.type === "file_url") return `[file: ${part.file_url.url}]`;
  return "";
}

function messageToText(msg: Message): string {
  return ensureArray(msg.content).map(partToText).join("\n").trim();
}

function convertMessages(messages: Message[]): {
  system: string;
  anthropicMessages: Anthropic.MessageParam[];
} {
  const systemParts: string[] = [];
  const out: Anthropic.MessageParam[] = [];

  for (const msg of messages) {
    if (msg.role === "system") {
      systemParts.push(messageToText(msg));
      continue;
    }

    if (msg.role === "tool" || msg.role === "function") {
      out.push({
        role: "user",
        content: [
          {
            type: "tool_result",
            tool_use_id: msg.tool_call_id || "unknown",
            content: messageToText(msg),
          },
        ],
      });
      continue;
    }

    if (msg.role === "user" || msg.role === "assistant") {
      out.push({
        role: msg.role,
        content: messageToText(msg),
      });
    }
  }

  return { system: systemParts.join("\n\n").trim(), anthropicMessages: out };
}

function convertTools(tools?: Tool[]): Anthropic.Tool[] | undefined {
  if (!tools || tools.length === 0) return undefined;
  return tools.map(t => ({
    name: t.function.name,
    description: t.function.description ?? "",
    input_schema: (t.function.parameters as Anthropic.Tool.InputSchema) ?? {
      type: "object",
      properties: {},
    },
  }));
}

function convertToolChoice(
  toolChoice: ToolChoice | undefined,
  tools: Tool[] | undefined
): Anthropic.MessageCreateParams["tool_choice"] | undefined {
  if (!toolChoice) return undefined;

  if (toolChoice === "none") return { type: "auto", disable_parallel_tool_use: true };
  if (toolChoice === "auto") return { type: "auto" };
  if (toolChoice === "required") {
    if (tools && tools.length === 1) {
      return { type: "tool", name: tools[0].function.name };
    }
    return { type: "any" };
  }
  if (typeof toolChoice === "object" && "name" in toolChoice) {
    return { type: "tool", name: toolChoice.name };
  }
  if (
    typeof toolChoice === "object" &&
    "type" in toolChoice &&
    toolChoice.type === "function"
  ) {
    return { type: "tool", name: toolChoice.function.name };
  }
  return undefined;
}

function resolveJsonRequirement(
  params: InvokeParams
): { mode: "schema"; schema: JsonSchema } | { mode: "json_object" } | null {
  const explicit = params.responseFormat || params.response_format;
  if (explicit) {
    if (explicit.type === "json_schema") {
      if (!explicit.json_schema?.schema) {
        throw new Error("responseFormat json_schema requires a defined schema object");
      }
      return { mode: "schema", schema: explicit.json_schema };
    }
    if (explicit.type === "json_object") return { mode: "json_object" };
    return null;
  }

  const schema = params.outputSchema || params.output_schema;
  if (schema) {
    if (!schema.name || !schema.schema) {
      throw new Error("outputSchema requires both name and schema");
    }
    return { mode: "schema", schema };
  }
  return null;
}

function buildJsonInstructions(
  req: { mode: "schema"; schema: JsonSchema } | { mode: "json_object" }
): string {
  if (req.mode === "json_object") {
    return [
      "",
      "CRITICAL OUTPUT FORMAT:",
      "Respond with ONLY a single valid JSON object.",
      "Do NOT wrap the JSON in markdown code fences.",
      "Do NOT include any prose before or after the JSON.",
    ].join("\n");
  }
  return [
    "",
    "CRITICAL OUTPUT FORMAT:",
    `Respond with ONLY a single valid JSON object that strictly conforms to this JSON Schema (named "${req.schema.name}"):`,
    "```json",
    JSON.stringify(req.schema.schema, null, 2),
    "```",
    "Do NOT wrap the JSON in markdown code fences in your response.",
    "Do NOT include any prose, comments, or explanations before or after the JSON.",
    "Every required field MUST be present. Do NOT include fields not defined in the schema.",
  ].join("\n");
}

function mapStopReason(stop: Anthropic.Message["stop_reason"]): string {
  switch (stop) {
    case "end_turn":
      return "stop";
    case "max_tokens":
      return "length";
    case "tool_use":
      return "tool_calls";
    case "stop_sequence":
      return "stop";
    default:
      return "stop";
  }
}

// ─── Main entrypoint ────────────────────────────────────────────────────────

export async function invokeLLM(
  params: InvokeParams & { bypassCache?: boolean; cacheTtlMs?: number }
): Promise<InvokeResult> {
  const client = getClient();
  const { messages, tools, toolChoice, tool_choice, maxTokens, max_tokens } = params;

  // ─── Cache read ──────────────────────────────────────────────────────────
  // Cache key depends only on inputs that affect output (not maxTokens etc).
  // For cacheable requests (no tools, not bypassed, cache enabled), check
  // the cache first. A miss falls through to the live API call below.
  const cacheable = isCacheable(params);
  let cacheKey: string | null = null;
  if (cacheable) {
    cacheKey = computeCacheKey(DEFAULT_MODEL, params);
    const cached = await readFromCache(cacheKey);
    if (cached) {
      // Return a fresh `created` timestamp + a flag so callers/log analysis
      // can tell cached responses apart from live ones if they care.
      return {
        ...cached,
        created: Math.floor(Date.now() / 1000),
      };
    }
  }

  const { system: baseSystem, anthropicMessages } = convertMessages(messages);

  const jsonReq = resolveJsonRequirement(params);
  let system = baseSystem;
  let prefillJson = false;
  if (jsonReq) {
    system = (system + buildJsonInstructions(jsonReq)).trim();
    prefillJson = true;
  }

  // Prefill assistant turn with "{" — this forces Claude to emit JSON only.
  // Note: prefilling is incompatible with tools, so only do it when no tools are present.
  const useToolPrefill = !tools || tools.length === 0;
  const finalMessages: Anthropic.MessageParam[] =
    prefillJson && useToolPrefill
      ? [...anthropicMessages, { role: "assistant", content: "{" }]
      : anthropicMessages;

  const request: Anthropic.MessageCreateParams = {
    model: DEFAULT_MODEL,
    max_tokens: maxTokens ?? max_tokens ?? DEFAULT_MAX_TOKENS,
    messages: finalMessages,
  };
  if (system) request.system = system;

  const anthropicTools = convertTools(tools);
  if (anthropicTools) {
    request.tools = anthropicTools;
    const tc = convertToolChoice(toolChoice || tool_choice, tools);
    if (tc) request.tool_choice = tc;
  }

  let response: Anthropic.Message;
  try {
    response = await client.messages.create(request);
  } catch (err: any) {
    const detail = err?.message || String(err);
    throw new Error(`LLM invoke failed: ${detail}`);
  }

  const textBlocks = response.content.filter(
    (b): b is Anthropic.TextBlock => b.type === "text"
  );
  const toolUseBlocks = response.content.filter(
    (b): b is Anthropic.ToolUseBlock => b.type === "tool_use"
  );

  let textContent = textBlocks.map(b => b.text).join("");

  // Re-attach the prefill brace if we used it
  if (prefillJson && useToolPrefill && textContent && !textContent.startsWith("{")) {
    textContent = "{" + textContent;
  }

  const toolCalls: ToolCall[] | undefined =
    toolUseBlocks.length > 0
      ? toolUseBlocks.map(b => ({
          id: b.id,
          type: "function" as const,
          function: {
            name: b.name,
            arguments: JSON.stringify(b.input ?? {}),
          },
        }))
      : undefined;

  const result: InvokeResult = {
    id: response.id,
    created: Math.floor(Date.now() / 1000),
    model: response.model,
    choices: [
      {
        index: 0,
        message: {
          role: "assistant",
          content: textContent,
          ...(toolCalls ? { tool_calls: toolCalls } : {}),
        },
        finish_reason: mapStopReason(response.stop_reason),
      },
    ],
    usage: {
      prompt_tokens: response.usage.input_tokens,
      completion_tokens: response.usage.output_tokens,
      total_tokens: response.usage.input_tokens + response.usage.output_tokens,
    },
  };

  // ─── Cache write ─────────────────────────────────────────────────────────
  // Async write — don't block the response on the cache write.
  if (cacheable && cacheKey) {
    void writeToCache(cacheKey, DEFAULT_MODEL, result, params.cacheTtlMs);
  }

  return result;
}
