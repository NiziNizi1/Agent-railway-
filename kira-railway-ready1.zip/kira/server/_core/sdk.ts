/**
 * Auth SDK — Simple password (Railway-ready)
 *
 * Replaces the original Manus SDK that talked to Manus's OAuth server.
 * Single-user app: one password defined in APP_PASSWORD env var.
 * On successful login, server signs a JWT session cookie. All subsequent
 * tRPC requests are authenticated by `authenticateRequest()`.
 *
 * Bypass mode: if AUTH_DISABLED=true, every request is treated as the owner
 * (useful for initial Railway deploy / testing before configuring a password).
 */

import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import { ForbiddenError } from "@shared/_core/errors";
import { parse as parseCookieHeader } from "cookie";
import type { Request } from "express";
import { SignJWT, jwtVerify } from "jose";
import type { User } from "../../drizzle/schema";
import * as db from "../db";

const OWNER_OPEN_ID = "owner";
const OWNER_NAME = "Owner";
const OWNER_EMAIL = process.env.OWNER_EMAIL || "owner@kira.local";

const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.length > 0;

function getSessionSecret(): Uint8Array {
  const secret =
    process.env.SESSION_SECRET ||
    process.env.JWT_SECRET ||
    "kira-default-secret-CHANGE-ME-in-production";
  return new TextEncoder().encode(secret);
}

async function ensureOwnerUser(): Promise<User | null> {
  // Make sure the owner row exists in the users table.
  await db.upsertUser({
    openId: OWNER_OPEN_ID,
    name: OWNER_NAME,
    email: OWNER_EMAIL,
    loginMethod: "password",
    role: "admin",
    lastSignedIn: new Date(),
  });
  return db.getUserByOpenId(OWNER_OPEN_ID);
}

class SDKServer {
  /**
   * Sign a session JWT for the owner.
   */
  async createSessionToken(
    _openId: string = OWNER_OPEN_ID,
    options: { expiresInMs?: number; name?: string } = {}
  ): Promise<string> {
    const issuedAt = Date.now();
    const expiresInMs = options.expiresInMs ?? ONE_YEAR_MS;
    const expirationSeconds = Math.floor((issuedAt + expiresInMs) / 1000);

    return new SignJWT({
      openId: OWNER_OPEN_ID,
      name: options.name || OWNER_NAME,
    })
      .setProtectedHeader({ alg: "HS256", typ: "JWT" })
      .setExpirationTime(expirationSeconds)
      .sign(getSessionSecret());
  }

  /**
   * Validate the password against APP_PASSWORD env var.
   */
  validatePassword(password: string): boolean {
    const expected = process.env.APP_PASSWORD;
    if (!expected) {
      console.error(
        "[Auth] APP_PASSWORD is not set — refusing login. Set APP_PASSWORD in env."
      );
      return false;
    }
    return password === expected;
  }

  async verifySession(
    cookieValue: string | undefined | null
  ): Promise<{ openId: string; name: string } | null> {
    if (!cookieValue) return null;
    try {
      const { payload } = await jwtVerify(cookieValue, getSessionSecret(), {
        algorithms: ["HS256"],
      });
      const { openId, name } = payload as Record<string, unknown>;
      if (!isNonEmptyString(openId)) return null;
      return {
        openId,
        name: isNonEmptyString(name) ? name : OWNER_NAME,
      };
    } catch (error) {
      console.warn("[Auth] Session verification failed:", String(error));
      return null;
    }
  }

  private parseCookies(cookieHeader: string | undefined): Map<string, string> {
    if (!cookieHeader) return new Map();
    const parsed = parseCookieHeader(cookieHeader);
    return new Map(Object.entries(parsed).filter(([, v]) => typeof v === "string")) as Map<
      string,
      string
    >;
  }

  /**
   * Used by the tRPC context to resolve the current user.
   * If AUTH_DISABLED=true, always returns the owner user.
   */
  async authenticateRequest(req: Request): Promise<User> {
    if (process.env.AUTH_DISABLED === "true") {
      const owner = await ensureOwnerUser();
      if (!owner) throw ForbiddenError("Owner user not found");
      return owner;
    }

    const cookies = this.parseCookies(req.headers.cookie);
    const sessionCookie = cookies.get(COOKIE_NAME);
    const session = await this.verifySession(sessionCookie);

    if (!session) {
      throw ForbiddenError("Invalid or missing session cookie");
    }

    const owner = await ensureOwnerUser();
    if (!owner) throw ForbiddenError("Owner user not found");
    return owner;
  }
}

export const sdk = new SDKServer();
