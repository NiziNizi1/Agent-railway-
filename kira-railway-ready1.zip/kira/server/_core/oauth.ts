/**
 * Auth routes — Simple password (Railway-ready)
 *
 * POST /api/auth/login    { password } → sets session cookie
 * POST /api/auth/logout                → clears session cookie
 * GET  /api/auth/me                    → returns { authenticated: boolean }
 */

import { COOKIE_NAME, ONE_YEAR_MS } from "@shared/const";
import type { Express, Request, Response } from "express";
import { getSessionCookieOptions } from "./cookies";
import { sdk } from "./sdk";

export function registerOAuthRoutes(app: Express) {
  // Login — POST { password } → session cookie
  app.post("/api/auth/login", async (req: Request, res: Response) => {
    try {
      const password =
        typeof req.body?.password === "string" ? req.body.password : "";

      if (!sdk.validatePassword(password)) {
        // Short delay to mitigate brute-force timing attacks
        await new Promise(r => setTimeout(r, 500));
        res.status(401).json({ error: "Invalid password" });
        return;
      }

      const sessionToken = await sdk.createSessionToken();
      const cookieOptions = getSessionCookieOptions(req);
      res.cookie(COOKIE_NAME, sessionToken, {
        ...cookieOptions,
        maxAge: ONE_YEAR_MS,
      });

      res.json({ success: true });
    } catch (error) {
      console.error("[Auth] Login failed:", error);
      res.status(500).json({ error: "Login failed" });
    }
  });

  // Logout — clears the session cookie
  app.post("/api/auth/logout", (req: Request, res: Response) => {
    const cookieOptions = getSessionCookieOptions(req);
    res.clearCookie(COOKIE_NAME, cookieOptions);
    res.json({ success: true });
  });

  // Status — used by the frontend to know whether to show the login screen
  app.get("/api/auth/me", async (req: Request, res: Response) => {
    if (process.env.AUTH_DISABLED === "true") {
      res.json({ authenticated: true, mode: "auth_disabled" });
      return;
    }

    try {
      const cookies = req.headers.cookie || "";
      const cookieValue = cookies
        .split(";")
        .map(c => c.trim())
        .find(c => c.startsWith(`${COOKIE_NAME}=`))
        ?.split("=")
        .slice(1)
        .join("=");

      const session = await sdk.verifySession(cookieValue);
      res.json({ authenticated: Boolean(session), mode: "password" });
    } catch {
      res.json({ authenticated: false, mode: "password" });
    }
  });
}
