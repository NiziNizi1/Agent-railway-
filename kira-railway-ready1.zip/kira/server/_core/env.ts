/**
 * Centralized env config (Railway-ready).
 * Manus-specific vars (forge*, OAUTH_SERVER_URL, VITE_APP_ID, OWNER_OPEN_ID)
 * have been removed — they are not used by the Anthropic LLM, Telegram
 * notification, or password-auth implementations.
 */
export const ENV = {
  cookieSecret:
    process.env.SESSION_SECRET ?? process.env.JWT_SECRET ?? "",
  databaseUrl: process.env.DATABASE_URL ?? "",
  isProduction: process.env.NODE_ENV === "production",
  // Kept for backward-compat with any leftover references — always empty now.
  ownerOpenId: "owner",
  appId: "kira",
};
