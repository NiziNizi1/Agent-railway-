/**
 * Notification module — Telegram (Railway-ready)
 *
 * Replaces the original Manus `forge.manus.im` notification service.
 * Sends owner notifications via Telegram Bot API.
 *
 * Graceful degradation: if TELEGRAM_BOT_TOKEN / TELEGRAM_CHAT_ID are not set,
 * notifyOwner() logs to stdout and returns false (callers expect this — they
 * fall back to email/in-app notifications). This means deploys can run before
 * the user has configured a Telegram bot.
 */

import { TRPCError } from "@trpc/server";

export type NotificationPayload = {
  title: string;
  content: string;
};

const TITLE_MAX_LENGTH = 1200;
const CONTENT_MAX_LENGTH = 20000;

const trimValue = (value: string): string => value.trim();
const isNonEmptyString = (value: unknown): value is string =>
  typeof value === "string" && value.trim().length > 0;

const validatePayload = (input: NotificationPayload): NotificationPayload => {
  if (!isNonEmptyString(input.title)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification title is required.",
    });
  }
  if (!isNonEmptyString(input.content)) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: "Notification content is required.",
    });
  }

  const title = trimValue(input.title);
  const content = trimValue(input.content);

  if (title.length > TITLE_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification title must be at most ${TITLE_MAX_LENGTH} characters.`,
    });
  }
  if (content.length > CONTENT_MAX_LENGTH) {
    throw new TRPCError({
      code: "BAD_REQUEST",
      message: `Notification content must be at most ${CONTENT_MAX_LENGTH} characters.`,
    });
  }

  return { title, content };
};

/**
 * Format a notification for Telegram. Uses MarkdownV2-style escaping minimally
 * (we render as plain text inside a code block for the content body to avoid
 * accidental markdown injection from LLM-generated content).
 */
function formatTelegramMessage(title: string, content: string): string {
  // HTML mode is the safest — only need to escape <, >, &
  const escape = (s: string) =>
    s.replace(/&/g, "&amp;").replace(/</g, "&lt;").replace(/>/g, "&gt;");
  return `<b>${escape(title)}</b>\n\n${escape(content)}`;
}

/**
 * Dispatches a project-owner notification via Telegram Bot API.
 *
 * Returns:
 *   - `true`  → notification accepted by Telegram
 *   - `false` → not configured, transient failure, or upstream error
 *               (callers fall back to email/in-app notifications)
 *
 * Throws (TRPCError) only on validation errors so callers can fix the payload.
 */
export async function notifyOwner(
  payload: NotificationPayload
): Promise<boolean> {
  const { title, content } = validatePayload(payload);

  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!botToken || !chatId) {
    console.log(
      `[Notification] Telegram not configured — skipping. Title: "${title}"`
    );
    return false;
  }

  try {
    const response = await fetch(
      `https://api.telegram.org/bot${botToken}/sendMessage`,
      {
        method: "POST",
        headers: { "content-type": "application/json" },
        body: JSON.stringify({
          chat_id: chatId,
          text: formatTelegramMessage(title, content),
          parse_mode: "HTML",
          disable_web_page_preview: true,
        }),
      }
    );

    if (!response.ok) {
      const detail = await response.text().catch(() => "");
      console.warn(
        `[Notification] Telegram returned ${response.status} ${response.statusText}${
          detail ? `: ${detail}` : ""
        }`
      );
      return false;
    }

    return true;
  } catch (error) {
    console.warn("[Notification] Error calling Telegram API:", error);
    return false;
  }
}
