import { describe, expect, it } from "vitest";
import { testSnovConnection, snovGetEmailCount } from "./snov";

describe("Snov.io integration", () => {
  it("can authenticate with Snov.io API", async () => {
    const result = await testSnovConnection();
    expect(result.success).toBe(true);
    expect(result.error).toBeUndefined();
  }, 15000);

  it("can get email count for a domain", async () => {
    const result = await snovGetEmailCount("google.com");
    expect(result.success).toBe(true);
    expect(typeof result.count).toBe("number");
  }, 15000);
});
