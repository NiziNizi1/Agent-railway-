import { eq, desc, gte, and, sql, inArray } from "drizzle-orm";
import { drizzle } from "drizzle-orm/mysql2";
import {
  InsertUser, users,
  publishers, InsertPublisher, Publisher,
  contacts, InsertContact,
  outreachHistory, InsertOutreachHistory,
  emailDrafts, InsertEmailDraft,
  notifications, InsertNotification,
  adDetections,
} from "../drizzle/schema";
import { ENV } from './_core/env';

let _db: ReturnType<typeof drizzle> | null = null;

export async function getDb() {
  if (!_db && process.env.DATABASE_URL) {
    try {
      _db = drizzle(process.env.DATABASE_URL);
    } catch (error) {
      console.warn("[Database] Failed to connect:", error);
      _db = null;
    }
  }
  return _db;
}

// ─── User Helpers ───────────────────────────────────────────────────────────

export async function upsertUser(user: InsertUser): Promise<void> {
  if (!user.openId) {
    throw new Error("User openId is required for upsert");
  }
  const db = await getDb();
  if (!db) {
    console.warn("[Database] Cannot upsert user: database not available");
    return;
  }
  try {
    const values: InsertUser = { openId: user.openId };
    const updateSet: Record<string, unknown> = {};
    const textFields = ["name", "email", "loginMethod"] as const;
    type TextField = (typeof textFields)[number];
    const assignNullable = (field: TextField) => {
      const value = user[field];
      if (value === undefined) return;
      const normalized = value ?? null;
      values[field] = normalized;
      updateSet[field] = normalized;
    };
    textFields.forEach(assignNullable);
    if (user.lastSignedIn !== undefined) {
      values.lastSignedIn = user.lastSignedIn;
      updateSet.lastSignedIn = user.lastSignedIn;
    }
    if (user.role !== undefined) {
      values.role = user.role;
      updateSet.role = user.role;
    } else if (user.openId === ENV.ownerOpenId) {
      values.role = 'admin';
      updateSet.role = 'admin';
    }
    if (!values.lastSignedIn) {
      values.lastSignedIn = new Date();
    }
    if (Object.keys(updateSet).length === 0) {
      updateSet.lastSignedIn = new Date();
    }
    await db.insert(users).values(values).onDuplicateKeyUpdate({ set: updateSet });
  } catch (error) {
    console.error("[Database] Failed to upsert user:", error);
    throw error;
  }
}

export async function getUserByOpenId(openId: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(users).where(eq(users.openId, openId)).limit(1);
  return result.length > 0 ? result[0] : undefined;
}

// ─── Publisher Helpers ───────────────────────────────────────────────────────

export async function createPublisher(data: InsertPublisher) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(publishers).values(data);
  const result = await db.select().from(publishers).where(eq(publishers.domain, data.domain)).limit(1);
  return result[0];
}

export async function bulkCreatePublishers(domains: string[]) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  
  // Clean and deduplicate domains
  const cleanDomains = Array.from(new Set(
    domains
      .map(d => d.toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').trim())
      .filter(d => d.length > 0 && d.includes('.'))
  ));
  
  let imported = 0;
  let skipped = 0;
  
  for (const domain of cleanDomains) {
    try {
      await db.insert(publishers).values({ domain, status: "new" as const });
      imported++;
    } catch (e: any) {
      // Skip duplicates and any other insert errors silently
      skipped++;
    }
  }
  
  return { imported, skipped, total: cleanDomains.length };
}

export async function getPublishers(filters?: { status?: string; minScore?: number }) {
  const db = await getDb();
  if (!db) return [];
  let query = db.select().from(publishers).orderBy(desc(publishers.updatedAt));
  // Filters applied via where clause
  const conditions = [];
  if (filters?.status) {
    conditions.push(eq(publishers.status, filters.status as any));
  }
  if (filters?.minScore) {
    conditions.push(gte(publishers.score, filters.minScore));
  }
  if (conditions.length > 0) {
    query = query.where(and(...conditions)) as any;
  }
  return await query;
}

export async function getPublisherById(id: number) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(publishers).where(eq(publishers.id, id)).limit(1);
  return result[0];
}

export async function getPublisherByDomain(domain: string) {
  const db = await getDb();
  if (!db) return undefined;
  const result = await db.select().from(publishers).where(eq(publishers.domain, domain)).limit(1);
  return result[0];
}

export async function updatePublisher(id: number, data: Partial<InsertPublisher>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(publishers).set(data).where(eq(publishers.id, id));
  return await getPublisherById(id);
}

export async function updatePublisherStatus(id: number, status: string, notes?: string) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  const updateData: any = { status };
  if (notes !== undefined) updateData.notes = notes;
  await db.update(publishers).set(updateData).where(eq(publishers.id, id));
  return await getPublisherById(id);
}

export async function deletePublisher(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(contacts).where(eq(contacts.publisherId, id));
  await db.delete(outreachHistory).where(eq(outreachHistory.publisherId, id));
  await db.delete(emailDrafts).where(eq(emailDrafts.publisherId, id));
  await db.delete(publishers).where(eq(publishers.id, id));
}

export async function getPublisherStats() {
  const db = await getDb();
  if (!db) return { total: 0, byStatus: {}, avgScore: 0, totalEmailsSent: 0, totalReplies: 0 };
  const all = await db.select().from(publishers);
  const byStatus: Record<string, number> = {};
  let totalScore = 0;
  let scoredCount = 0;
  let totalEmailsSent = 0;
  let totalReplies = 0;
  for (const p of all) {
    byStatus[p.status] = (byStatus[p.status] || 0) + 1;
    if (p.score) { totalScore += p.score; scoredCount++; }
    totalEmailsSent += p.emailsSent || 0;
    totalReplies += p.emailsReplied || 0;
  }
  return {
    total: all.length,
    byStatus,
    avgScore: scoredCount > 0 ? Math.round(totalScore / scoredCount) : 0,
    totalEmailsSent,
    totalReplies,
    openRate: totalEmailsSent > 0 ? Math.round(((all.reduce((s, p) => s + (p.emailsOpened || 0), 0)) / totalEmailsSent) * 100) : 0,
    replyRate: totalEmailsSent > 0 ? Math.round((totalReplies / totalEmailsSent) * 100) : 0,
    conversionRate: all.length > 0 ? Math.round(((byStatus['converted'] || 0) / all.length) * 100) : 0,
  };
}

// ─── Contact Helpers ────────────────────────────────────────────────────────

export async function getContactsByPublisher(publisherId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(contacts).where(eq(contacts.publisherId, publisherId));
}

export async function createContact(data: InsertContact) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(contacts).values(data);
  return await getContactsByPublisher(data.publisherId);
}

export async function deleteContact(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.delete(contacts).where(eq(contacts.id, id));
}

// ─── Outreach History Helpers ───────────────────────────────────────────────

export async function getOutreachByPublisher(publisherId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(outreachHistory)
    .where(eq(outreachHistory.publisherId, publisherId))
    .orderBy(desc(outreachHistory.createdAt));
}

export async function createOutreachEntry(data: InsertOutreachHistory) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(outreachHistory).values(data);
}

// ─── Email Draft Helpers ────────────────────────────────────────────────────

export async function getDraftsByPublisher(publisherId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(emailDrafts)
    .where(eq(emailDrafts.publisherId, publisherId))
    .orderBy(desc(emailDrafts.createdAt));
}

export async function createEmailDraft(data: InsertEmailDraft) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(emailDrafts).values(data);
}

// ─── Notification Helpers ───────────────────────────────────────────────────

export async function getNotifications(unreadOnly?: boolean) {
  const db = await getDb();
  if (!db) return [];
  if (unreadOnly) {
    return await db.select().from(notifications)
      .where(eq(notifications.isRead, false))
      .orderBy(desc(notifications.createdAt));
  }
  return await db.select().from(notifications).orderBy(desc(notifications.createdAt)).limit(50);
}

export async function createNotification(data: InsertNotification) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.insert(notifications).values(data);
}

export async function markNotificationRead(id: number) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.id, id));
}

export async function markAllNotificationsRead() {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  await db.update(notifications).set({ isRead: true }).where(eq(notifications.isRead, false));
}

// ─── Ad Detection Helpers ───────────────────────────────────────────────

export async function saveAdDetections(publisherId: number, detections: Array<{ network: string; format: string; confidence: string; evidence?: string }>) {
  const db = await getDb();
  if (!db) throw new Error("Database not available");
  // Delete old detections for this publisher
  await db.delete(adDetections).where(eq(adDetections.publisherId, publisherId));
  // Insert new ones
  if (detections.length > 0) {
    await db.insert(adDetections).values(detections.map(d => ({
      publisherId,
      network: d.network,
      format: d.format,
      confidence: d.confidence as any,
      evidence: d.evidence,
    })));
  }
}

export async function getAdDetectionsByPublisher(publisherId: number) {
  const db = await getDb();
  if (!db) return [];
  return await db.select().from(adDetections).where(eq(adDetections.publisherId, publisherId));
}
