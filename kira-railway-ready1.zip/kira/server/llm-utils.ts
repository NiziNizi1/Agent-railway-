/**
 * Safe LLM response parsing utilities
 * The LLM API can return message.content as either:
 * - string (most common)
 * - Array<TextContent | ImageContent | FileContent> (when using structured output)
 * This helper safely extracts the text content regardless of format.
 */

/**
 * Extract text string from LLM message content (handles both string and array formats)
 */
export function extractLLMText(content: string | Array<any> | null | undefined): string {
  if (!content) return "";
  if (typeof content === "string") return content;
  if (Array.isArray(content)) {
    // Find the first text item
    const textItem = content.find((item: any) => item.type === "text" || typeof item === "string");
    if (!textItem) return "";
    if (typeof textItem === "string") return textItem;
    return textItem.text || "";
  }
  return String(content);
}

/**
 * Safely parse JSON from LLM response content
 * Returns null if parsing fails
 */
export function parseLLMJson<T = any>(content: string | Array<any> | null | undefined, fallback: T): T {
  try {
    const text = extractLLMText(content);
    if (!text) return fallback;
    
    // Strip markdown code blocks if present
    let cleaned = text.trim();
    if (cleaned.startsWith("```")) {
      cleaned = cleaned.replace(/^```(?:json)?\n?/, "").replace(/\n?```$/, "").trim();
    }
    
    return JSON.parse(cleaned) as T;
  } catch (e) {
    console.error("[LLM Parse Error]", e, "Content:", content);
    return fallback;
  }
}
