/**
 * SimilarWeb enrichment helper.
 * Uses a Python subprocess to call the SimilarWeb data API available in the sandbox.
 * Falls back gracefully if the API is not available (e.g., in production).
 */
import { exec } from "child_process";
import { promisify } from "util";

const execAsync = promisify(exec);

export interface SimilarWebData {
  globalRank?: number;
  totalVisits?: number;
  bounceRate?: number;
  trafficSources?: Record<string, number>;
  topCountries?: Array<{ country: string; share: number }>;
}

export async function fetchSimilarWebData(domain: string): Promise<SimilarWebData | null> {
  try {
    const script = `
import sys
sys.path.append('/opt/.manus/.sandbox-runtime')
import json
try:
    from data_api import ApiClient
    client = ApiClient()
    result = {}
    
    # Get global rank
    try:
        rank_data = client.call_api('SimilarWeb/get_global_rank', path_params={'domain': '${domain}'})
        if rank_data:
            result['globalRank'] = rank_data
    except:
        pass
    
    # Get visits total
    try:
        visits_data = client.call_api('SimilarWeb/get_visits_total',
            path_params={'domain': '${domain}'},
            query={'country': 'world', 'granularity': 'monthly'})
        if visits_data:
            result['totalVisits'] = visits_data
    except:
        pass
    
    # Get bounce rate
    try:
        bounce_data = client.call_api('SimilarWeb/get_bounce_rate',
            path_params={'domain': '${domain}'},
            query={'country': 'world', 'granularity': 'monthly'})
        if bounce_data:
            result['bounceRate'] = bounce_data
    except:
        pass
    
    # Get traffic sources
    try:
        sources_data = client.call_api('SimilarWeb/get_traffic_sources_desktop',
            path_params={'domain': '${domain}'},
            query={'country': 'world', 'granularity': 'monthly'})
        if sources_data:
            result['trafficSources'] = sources_data
    except:
        pass
    
    # Get top countries
    try:
        country_data = client.call_api('SimilarWeb/get_total_traffic_by_country',
            path_params={'domain': '${domain}'},
            query={'limit': '5'})
        if country_data:
            result['topCountries'] = country_data
    except:
        pass
    
    print(json.dumps(result))
except Exception as e:
    print(json.dumps({'error': str(e)}))
`;

    const { stdout } = await execAsync(`python3 -c "${script.replace(/"/g, '\\"')}"`, {
      timeout: 30000,
    });

    const data = JSON.parse(stdout.trim());
    if (data.error) {
      console.warn(`[SimilarWeb] Error for ${domain}:`, data.error);
      return null;
    }
    return data;
  } catch (error) {
    console.warn(`[SimilarWeb] Failed to fetch data for ${domain}:`, error);
    return null;
  }
}
