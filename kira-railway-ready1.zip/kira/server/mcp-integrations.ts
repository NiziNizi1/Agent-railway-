/**
 * MCP Integrations — Direct (Railway-ready)
 *
 * Replaces the original `manus-mcp-cli` shell-out calls with direct library
 * usage:
 *   - Gmail   → googleapis OAuth2 + gmail.users.messages.send (RFC 2822 raw mime)
 *   - Playwright → official `playwright` npm package, in-process
 *
 * Same exported function signatures so `routers.ts` keeps working.
 */

import { google } from "googleapis";
import { chromium, type Browser } from "playwright";

// ─── Gmail Integration ──────────────────────────────────────────────────────

export interface SendEmailParams {
  to: string;
  subject: string;
  content: string;
  cc?: string[];
}

let _oauth2Client: ReturnType<typeof google.auth.OAuth2> | null = null;

function getGmailClient() {
  if (!_oauth2Client) {
    const clientId = process.env.GOOGLE_CLIENT_ID;
    const clientSecret = process.env.GOOGLE_CLIENT_SECRET;
    const refreshToken = process.env.GOOGLE_REFRESH_TOKEN;

    if (!clientId || !clientSecret || !refreshToken) {
      throw new Error(
        "Gmail not configured. Set GOOGLE_CLIENT_ID, GOOGLE_CLIENT_SECRET, GOOGLE_REFRESH_TOKEN in env."
      );
    }

    _oauth2Client = new google.auth.OAuth2(clientId, clientSecret);
    _oauth2Client.setCredentials({ refresh_token: refreshToken });
  }
  return google.gmail({ version: "v1", auth: _oauth2Client });
}

/**
 * Build an RFC 2822 message and base64url-encode it for Gmail's API.
 * Uses UTF-8 + Quoted-Printable-friendly headers so non-ASCII subjects work.
 */
function buildRawMessage(params: SendEmailParams, from: string): string {
  const ccLine =
    params.cc && params.cc.length > 0 ? `Cc: ${params.cc.join(", ")}\r\n` : "";

  // RFC 2047 encoding for non-ASCII subject lines
  const encodedSubject = /[^\x20-\x7E]/.test(params.subject)
    ? `=?UTF-8?B?${Buffer.from(params.subject, "utf8").toString("base64")}?=`
    : params.subject;

  const lines = [
    `From: ${from}`,
    `To: ${params.to}`,
    ccLine,
    `Subject: ${encodedSubject}`,
    "MIME-Version: 1.0",
    'Content-Type: text/html; charset="UTF-8"',
    "Content-Transfer-Encoding: base64",
    "",
    Buffer.from(params.content, "utf8").toString("base64"),
  ];

  const raw = lines.join("\r\n");

  // Gmail wants base64url
  return Buffer.from(raw, "utf8")
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

export async function sendEmailViaGmail(
  params: SendEmailParams
): Promise<{ success: boolean; error?: string; messageId?: string }> {
  try {
    const gmail = getGmailClient();
    const from = process.env.GOOGLE_SENDER_EMAIL || "me";
    const raw = buildRawMessage(params, from);

    const response = await gmail.users.messages.send({
      userId: "me",
      requestBody: { raw },
    });

    return { success: true, messageId: response.data.id ?? undefined };
  } catch (error: any) {
    const detail =
      error?.response?.data?.error?.message ||
      error?.message ||
      "Failed to send email";
    console.error("[Gmail] Send failed:", detail);
    return { success: false, error: detail };
  }
}

// ─── Playwright Scraping Integration ────────────────────────────────────────

export interface ScrapedContacts {
  emails: string[];
  phones: string[];
  socialLinks: string[];
  error?: string;
}

let _sharedBrowser: Browser | null = null;

async function getBrowser(): Promise<Browser> {
  if (_sharedBrowser && _sharedBrowser.isConnected()) {
    return _sharedBrowser;
  }
  _sharedBrowser = await chromium.launch({
    headless: true,
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || undefined,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
    ],
  });
  return _sharedBrowser;
}

/**
 * Extract emails / phones / social links from the rendered page.
 * Runs inside the page context so it sees text from JS-rendered content too.
 */
async function extractContactsFromPage(page: any): Promise<{
  emails: string[];
  phones: string[];
  socialLinks: string[];
  contactLinks: string[];
}> {
  return await page.evaluate(() => {
    const text = (document.body?.innerText as string) || "";

    const emailRegex = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
    const emails = Array.from(new Set(text.match(emailRegex) || []));

    const phoneRegex =
      /[\+]?[(]?[0-9]{1,4}[)]?[\-\s\.]?[0-9]{1,4}[\-\s\.]?[0-9]{4,6}/g;
    const phones = Array.from(
      new Set((text.match(phoneRegex) || []).filter(p => p.length >= 7))
    );

    const links = Array.from(document.querySelectorAll("a[href]")) as HTMLAnchorElement[];

    const socialLinks = Array.from(
      new Set(
        links
          .map(a => a.href)
          .filter(
            href =>
              href.includes("linkedin.com") ||
              href.includes("twitter.com") ||
              href.includes("t.me") ||
              href.includes("facebook.com")
          )
      )
    );

    const contactLinks = Array.from(
      new Set(
        links
          .filter(a => {
            const t = (a.textContent || "").toLowerCase();
            const h = (a.href || "").toLowerCase();
            return (
              t.includes("contact") ||
              t.includes("about") ||
              t.includes("advertis") ||
              h.includes("contact") ||
              h.includes("about") ||
              h.includes("advertis")
            );
          })
          .map(a => a.href)
      )
    );

    return { emails, phones, socialLinks, contactLinks };
  });
}

export async function scrapeContactsFromWebsite(
  domain: string
): Promise<ScrapedContacts> {
  const result: ScrapedContacts = { emails: [], phones: [], socialLinks: [] };

  let context;
  let page;
  try {
    const browser = await getBrowser();
    context = await browser.newContext({
      userAgent:
        "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
        "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36",
      viewport: { width: 1280, height: 800 },
    });
    page = await context.newPage();

    const url = `https://${domain}`;
    await page.goto(url, { waitUntil: "domcontentloaded", timeout: 25_000 });

    // Tiny settle delay so JS-rendered content lands
    await page.waitForTimeout(1500);

    const home = await extractContactsFromPage(page);
    result.emails.push(...home.emails);
    result.phones.push(...home.phones);
    result.socialLinks.push(...home.socialLinks);

    // Follow first plausible "contact" page if found
    if (home.contactLinks.length > 0) {
      try {
        await page.goto(home.contactLinks[0], {
          waitUntil: "domcontentloaded",
          timeout: 15_000,
        });
        await page.waitForTimeout(1000);
        const contact = await extractContactsFromPage(page);
        result.emails.push(...contact.emails);
        result.phones.push(...contact.phones);
        result.socialLinks.push(...contact.socialLinks);
      } catch {
        // contact page failed — keep home-page results
      }
    }
  } catch (error: any) {
    result.error = error?.message || "Scraping failed";
  } finally {
    try {
      await page?.close();
    } catch {}
    try {
      await context?.close();
    } catch {}
  }

  // Dedupe + filter common false positives
  result.emails = Array.from(new Set(result.emails)).filter(
    e =>
      !e.includes("example.com") &&
      !e.includes("wixpress") &&
      !e.includes("sentry") &&
      !e.endsWith(".png") &&
      !e.endsWith(".jpg") &&
      !e.endsWith(".gif") &&
      !e.endsWith(".webp")
  );
  result.phones = Array.from(new Set(result.phones));
  result.socialLinks = Array.from(new Set(result.socialLinks));

  return result;
}

/**
 * Optional: clean shutdown of the shared browser instance.
 * Wire this into a SIGTERM/SIGINT handler if you want graceful exits.
 */
export async function closeSharedBrowser(): Promise<void> {
  if (_sharedBrowser) {
    try {
      await _sharedBrowser.close();
    } catch {
      /* ignore */
    } finally {
      _sharedBrowser = null;
    }
  }
}
