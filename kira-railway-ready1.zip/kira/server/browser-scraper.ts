/**
 * Production-ready browser scraper using puppeteer-core + system Chromium
 * Works in both sandbox and production environments
 */
import puppeteer, { Browser, Page } from "puppeteer-core";

const CHROMIUM_PATHS = [
  "/usr/bin/chromium",
  "/usr/bin/chromium-browser",
  "/usr/bin/google-chrome",
  "/usr/bin/google-chrome-stable",
  "/snap/bin/chromium",
];

let browserInstance: Browser | null = null;

async function getChromiumPath(): Promise<string> {
  const { exec } = await import("child_process");
  const { promisify } = await import("util");
  const execAsync = promisify(exec);

  for (const path of CHROMIUM_PATHS) {
    try {
      await execAsync(`test -f ${path}`);
      return path;
    } catch (e) {
      continue;
    }
  }
  // Try which command
  try {
    const { stdout } = await execAsync("which chromium || which chromium-browser || which google-chrome");
    return stdout.trim().split("\n")[0];
  } catch (e) {
    throw new Error("No Chromium installation found");
  }
}

async function getBrowser(): Promise<Browser> {
  if (browserInstance && browserInstance.connected) {
    return browserInstance;
  }

  const executablePath = await getChromiumPath();

  browserInstance = await puppeteer.launch({
    executablePath,
    headless: true,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-accelerated-2d-canvas",
      "--no-first-run",
      "--no-zygote",
      "--disable-gpu",
      "--disable-extensions",
      "--disable-background-networking",
      "--disable-sync",
      "--disable-translate",
      "--mute-audio",
      "--disable-notifications",
      "--disable-popup-blocking",
    ],
  });

  return browserInstance;
}

async function closeBrowser() {
  if (browserInstance) {
    await browserInstance.close().catch(() => {});
    browserInstance = null;
  }
}

export interface ScrapeResult {
  emails: string[];
  phones: string[];
  socialLinks: { type: string; url: string }[];
  title: string;
  description: string;
  scripts: string[];
  error?: string;
}

/**
 * Scrape a website for contact information, bypassing popups
 */
export async function scrapeWebsite(domain: string, timeoutMs = 30000): Promise<ScrapeResult> {
  const result: ScrapeResult = {
    emails: [],
    phones: [],
    socialLinks: [],
    title: "",
    description: "",
    scripts: [],
  };

  let page: Page | null = null;

  try {
    const browser = await getBrowser();
    page = await browser.newPage();

    // Set realistic user agent
    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    );

    // Block heavy resources to speed up loading
    await page.setRequestInterception(true);
    page.on("request", (req) => {
      const type = req.resourceType();
      if (["image", "media", "font", "stylesheet"].includes(type)) {
        req.abort();
      } else {
        req.continue();
      }
    });

    // Navigate to main page
    const url = `https://${domain}`;
    await page.goto(url, {
      waitUntil: "domcontentloaded",
      timeout: timeoutMs,
    });

    // Dismiss popups/dialogs
    page.on("dialog", async (dialog) => {
      await dialog.dismiss().catch(() => {});
    });

    // Wait a bit for dynamic content
    await new Promise(r => setTimeout(r, 2000));

    // Dismiss common popup overlays
    await page.evaluate(() => {
      const selectors = [
        '[class*="popup"]', '[class*="modal"]', '[class*="overlay"]',
        '[class*="cookie"]', '[class*="consent"]', '[class*="gdpr"]',
        '[id*="popup"]', '[id*="modal"]', '[id*="overlay"]',
        '.fc-dialog-container', '.qc-cmp2-container',
        '[class*="close"]', '[aria-label="Close"]',
        '[class*="dismiss"]', '[class*="banner"] button',
      ];
      selectors.forEach(sel => {
        document.querySelectorAll(sel).forEach((el: any) => {
          if (el.offsetParent !== null) {
            try { el.click(); } catch (e) {}
          }
        });
      });
    }).catch(() => {});

    await new Promise(r => setTimeout(r, 500));

    // Extract data from main page
    const mainData = await page.evaluate(() => {
      const text = document.body?.innerText || "";
      const html = document.documentElement?.innerHTML || "";

      // Emails
      const emailRegex = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
      const emails = Array.from(new Set(text.match(emailRegex) || []));

      // Scripts
      const scripts = Array.from(document.querySelectorAll("script[src]"))
        .map((s: any) => s.src)
        .filter(Boolean);

      // Social links
      const socialLinks: { type: string; url: string }[] = [];
      document.querySelectorAll("a[href]").forEach((a: any) => {
        const href = a.href || "";
        if (href.includes("t.me/") || href.includes("telegram.me/")) {
          socialLinks.push({ type: "telegram", url: href });
        } else if (href.includes("discord.gg/") || href.includes("discord.com/invite/")) {
          socialLinks.push({ type: "discord", url: href });
        } else if (href.includes("facebook.com/") && !href.includes("sharer") && !href.includes("share?")) {
          socialLinks.push({ type: "facebook", url: href });
        } else if (href.includes("twitter.com/") && !href.includes("intent") && !href.includes("share")) {
          socialLinks.push({ type: "twitter", url: href });
        } else if (href.includes("linkedin.com/")) {
          socialLinks.push({ type: "linkedin", url: href });
        } else if (href.includes("wa.me/") || href.includes("whatsapp.com/send")) {
          socialLinks.push({ type: "whatsapp", url: href });
        }
      });

      // Title and description
      const title = document.title || "";
      const descMeta = document.querySelector('meta[name="description"]') as any;
      const description = descMeta?.content || "";

      return { emails, scripts: scripts.slice(0, 30), socialLinks, title, description };
    });

    result.emails = mainData.emails.filter((e: string) =>
      !e.includes("example.") && !e.includes("sentry.") && !e.endsWith(".png")
    );
    result.scripts = mainData.scripts;
    result.title = mainData.title;
    result.description = mainData.description;

    // Deduplicate social links
    const seenSocial = new Set<string>();
    for (const link of mainData.socialLinks) {
      if (!seenSocial.has(link.url)) {
        seenSocial.add(link.url);
        result.socialLinks.push(link);
      }
    }

    // Also check contact/about/advertise pages
    const contactPaths = ["/contact", "/contact-us", "/about", "/advertise", "/advertising", "/ads"];
    for (const path of contactPaths.slice(0, 3)) {
      try {
        await page.goto(`https://${domain}${path}`, {
          waitUntil: "domcontentloaded",
          timeout: 10000,
        });
        await new Promise(r => setTimeout(r, 1000));

        const contactData = await page.evaluate(() => {
          const text = document.body?.innerText || "";
          const emailRegex = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
          const emails = Array.from(new Set(text.match(emailRegex) || []));
          const socialLinks: { type: string; url: string }[] = [];
          document.querySelectorAll("a[href]").forEach((a: any) => {
            const href = a.href || "";
            if (href.includes("t.me/") || href.includes("telegram.me/")) {
              socialLinks.push({ type: "telegram", url: href });
            } else if (href.includes("discord.gg/") || href.includes("discord.com/invite/")) {
              socialLinks.push({ type: "discord", url: href });
            }
          });
          return { emails, socialLinks };
        });

        for (const email of contactData.emails) {
          if (!result.emails.includes(email) && !email.includes("example.") && !email.endsWith(".png")) {
            result.emails.push(email);
          }
        }
        for (const link of contactData.socialLinks) {
          if (!seenSocial.has(link.url)) {
            seenSocial.add(link.url);
            result.socialLinks.push(link);
          }
        }
      } catch (e) {
        // Page doesn't exist, continue
      }
    }

  } catch (error: any) {
    result.error = error.message || "Scraping failed";
  } finally {
    if (page) {
      await page.close().catch(() => {});
    }
  }

  return result;
}

/**
 * Detect ad networks on a website using puppeteer
 */
export async function detectAdNetworksPuppeteer(domain: string): Promise<{
  detectedNetworks: Array<{ network: string; format: string; confidence: string }>;
  error?: string;
}> {
  const AD_PATTERNS = [
    { network: "Monetag", format: "Pop-under", patterns: ["monetag.com", "trk.monetag", "d-aa.com", "mczbf.com"] },
    { network: "AdSterra", format: "Pop-under", patterns: ["adsterra.com", "astrfrm.com", "susession.com", "ad6media"] },
    { network: "PropellerAds", format: "Pop-under/Push", patterns: ["propellerads.com", "propu.sh", "pushprofit.net"] },
    { network: "AdMaven", format: "Pop-under", patterns: ["admaven.com", "ad-maven.com", "servedbyadmaven"] },
    { network: "AdCash", format: "Interstitial/Push", patterns: ["adcash.com", "surfe.pro", "syndication.adcash"] },
    { network: "Google AdSense", format: "Banner/Display", patterns: ["pagead2.googlesyndication.com", "adsbygoogle", "google_ad_client"] },
    { network: "Taboola", format: "Native", patterns: ["taboola.com", "cdn.taboola.com"] },
    { network: "Outbrain", format: "Native", patterns: ["outbrain.com", "widgets.outbrain.com"] },
    { network: "ExoClick", format: "Video/Pop", patterns: ["exoclick.com", "exosrv.com"] },
    { network: "Media.net", format: "Banner/Display", patterns: ["media.net", "contextual.media.net"] },
    { network: "PopAds", format: "Pop-under", patterns: ["popads.net"] },
    { network: "PopCash", format: "Pop-under", patterns: ["popcash.net"] },
    { network: "ClickAdu", format: "Pop-under", patterns: ["clickadu.com", "vfrfrm.com"] },
    { network: "HilltopAds", format: "Pop/Banner", patterns: ["hilltopads.com", "hilltopads.net"] },
    { network: "TrafficStars", format: "Video/Banner", patterns: ["trafficstars.com", "tsyndicate.com"] },
    { network: "Galaksion", format: "Pop-under/Push", patterns: ["galaksion.com", "gads.galaksion"] },
    { network: "MGID", format: "Native", patterns: ["mgid.com", "jsc.mgid"] },
    { network: "Ezoic", format: "Banner/Display", patterns: ["ezoic.com", "ezoic.net"] },
  ];

  let page: Page | null = null;

  try {
    const browser = await getBrowser();
    page = await browser.newPage();

    await page.setUserAgent(
      "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36"
    );

    // Collect all network requests
    const requestUrls: string[] = [];
    page.on("request", (req) => {
      requestUrls.push(req.url());
    });

    await page.goto(`https://${domain}`, {
      waitUntil: "domcontentloaded",
      timeout: 25000,
    });

    // Wait for ads to load
    await new Promise(r => setTimeout(r, 3000));

    // Get all scripts and inline content
    const pageContent = await page.evaluate(() => {
      const scripts = Array.from(document.querySelectorAll("script[src]")).map((s: any) => s.src).join(" ");
      const inlineScripts = Array.from(document.querySelectorAll("script:not([src])"))
        .map((s: any) => s.textContent || "")
        .join(" ")
        .substring(0, 10000);
      const iframes = Array.from(document.querySelectorAll("iframe[src]")).map((f: any) => f.src).join(" ");
      return { scripts, inlineScripts, iframes };
    });

    const allContent = [
      pageContent.scripts,
      pageContent.inlineScripts,
      pageContent.iframes,
      requestUrls.join(" "),
    ].join(" ").toLowerCase();

    const detected: Array<{ network: string; format: string; confidence: string }> = [];

    for (const ad of AD_PATTERNS) {
      for (const pattern of ad.patterns) {
        if (allContent.includes(pattern.toLowerCase())) {
          // Check confidence based on source
          const inRequests = requestUrls.some(u => u.toLowerCase().includes(pattern.toLowerCase()));
          detected.push({
            network: ad.network,
            format: ad.format,
            confidence: inRequests ? "high" : "medium",
          });
          break;
        }
      }
    }

    return { detectedNetworks: detected };

  } catch (error: any) {
    return { detectedNetworks: [], error: error.message };
  } finally {
    if (page) {
      await page.close().catch(() => {});
    }
  }
}

// Cleanup on process exit
process.on("exit", closeBrowser);
process.on("SIGINT", closeBrowser);
process.on("SIGTERM", closeBrowser);
