/**
 * Apify Integration Module
 * Uses Apify actors for scalable, reliable web scraping:
 * - Contact/email extraction from publisher websites
 * - Website metadata scraping (title, description, tech stack)
 * - Ad network detection via page source analysis
 */
import axios from "axios";

const APIFY_BASE = "https://api.apify.com/v2";

function getApiKey(): string {
  const key = process.env.APIFY_API_KEY;
  if (!key) throw new Error("APIFY_API_KEY not configured");
  return key;
}

/**
 * Run an Apify actor and wait for results
 */
async function runActor(actorId: string, input: object, timeoutSecs = 60): Promise<any[]> {
  const apiKey = getApiKey();

  // Start the actor run
  const runResp = await axios.post(
    `${APIFY_BASE}/acts/${actorId}/runs?token=${apiKey}&timeout=${timeoutSecs}&memory=256`,
    input,
    { headers: { "Content-Type": "application/json" } }
  );

  const runId = runResp.data?.data?.id;
  if (!runId) throw new Error("Failed to start Apify actor");

  // Poll for completion
  const maxWait = timeoutSecs * 1000;
  const pollInterval = 3000;
  const startTime = Date.now();

  while (Date.now() - startTime < maxWait) {
    await new Promise(r => setTimeout(r, pollInterval));

    const statusResp = await axios.get(
      `${APIFY_BASE}/actor-runs/${runId}?token=${apiKey}`
    );
    const status = statusResp.data?.data?.status;

    if (status === "SUCCEEDED") {
      // Get dataset items
      const datasetId = statusResp.data?.data?.defaultDatasetId;
      if (!datasetId) return [];

      const itemsResp = await axios.get(
        `${APIFY_BASE}/datasets/${datasetId}/items?token=${apiKey}&limit=100`
      );
      return itemsResp.data || [];
    }

    if (["FAILED", "ABORTED", "TIMED-OUT"].includes(status)) {
      throw new Error(`Apify actor run ${status}`);
    }
  }

  throw new Error("Apify actor timed out");
}

/**
 * Scrape contact information from a website using Apify's Cheerio Scraper
 */
export async function apifyScrapeContacts(domain: string): Promise<{
  success: boolean;
  emails: string[];
  phones: string[];
  socialLinks: string[];
  title?: string;
  description?: string;
  error?: string;
}> {
  try {
    const url = `https://${domain}`;

    // Use Apify's built-in Cheerio Scraper (apify/cheerio-scraper)
    // It's fast, lightweight, and great for extracting structured data
    const items = await runActor("apify/cheerio-scraper", {
      startUrls: [{ url }],
      maxCrawlPages: 5,
      maxCrawlDepth: 1,
      pageFunction: `async function pageFunction(context) {
        const { $, request } = context;
        
        // Extract emails
        const text = $('body').text();
        const emailRegex = /[a-zA-Z0-9._%+\\-]+@[a-zA-Z0-9.\\-]+\\.[a-zA-Z]{2,}/g;
        const emails = [...new Set(text.match(emailRegex) || [])];
        
        // Extract phone numbers
        const phoneRegex = /[\\+]?[(]?[0-9]{1,4}[)]?[\\-\\s\\.]?[0-9]{1,4}[\\-\\s\\.]?[0-9]{4,6}/g;
        const phones = [...new Set(text.match(phoneRegex) || [])].filter(p => p.length >= 7);
        
        // Extract social links
        const socialLinks = [];
        $('a[href]').each(function() {
          const href = $(this).attr('href') || '';
          if (href.includes('linkedin.com') || href.includes('twitter.com') || 
              href.includes('t.me') || href.includes('facebook.com')) {
            socialLinks.push(href);
          }
        });
        
        // Get page metadata
        const title = $('title').text().trim();
        const description = $('meta[name="description"]').attr('content') || '';
        
        return {
          url: request.url,
          emails,
          phones,
          socialLinks: [...new Set(socialLinks)],
          title,
          description
        };
      }`,
      proxyConfiguration: { useApifyProxy: true },
    }, 90);

    // Aggregate results from all crawled pages
    const allEmails = new Set<string>();
    const allPhones = new Set<string>();
    const allSocial = new Set<string>();
    let title = "";
    let description = "";

    for (const item of items) {
      (item.emails || []).forEach((e: string) => allEmails.add(e));
      (item.phones || []).forEach((p: string) => allPhones.add(p));
      (item.socialLinks || []).forEach((s: string) => allSocial.add(s));
      if (!title && item.title) title = item.title;
      if (!description && item.description) description = item.description;
    }

    // Filter false positives
    const filteredEmails = Array.from(allEmails).filter(e =>
      !e.includes("example.com") &&
      !e.includes("sentry.io") &&
      !e.endsWith(".png") &&
      !e.endsWith(".jpg") &&
      e.includes("@")
    );

    return {
      success: true,
      emails: filteredEmails,
      phones: Array.from(allPhones).slice(0, 5),
      socialLinks: Array.from(allSocial).slice(0, 10),
      title,
      description,
    };
  } catch (error: any) {
    return {
      success: false,
      emails: [],
      phones: [],
      socialLinks: [],
      error: error.message || "Apify scraping failed",
    };
  }
}

/**
 * Scrape website metadata and ad network signals using Apify
 */
export async function apifyScrapeAdNetworks(domain: string): Promise<{
  success: boolean;
  scripts: string[];
  adSignals: string[];
  error?: string;
}> {
  try {
    const url = `https://${domain}`;

    const items = await runActor("apify/cheerio-scraper", {
      startUrls: [{ url }],
      maxCrawlPages: 1,
      maxCrawlDepth: 0,
      pageFunction: `async function pageFunction(context) {
        const { $, request } = context;
        
        // Get all script sources
        const scripts = [];
        $('script[src]').each(function() {
          scripts.push($(this).attr('src') || '');
        });
        
        // Get inline script content (first 200 chars each)
        const inlineScripts = [];
        $('script:not([src])').each(function() {
          const content = $(this).html() || '';
          if (content.length > 10) inlineScripts.push(content.substring(0, 300));
        });
        
        // Get iframe sources
        const iframes = [];
        $('iframe[src]').each(function() {
          iframes.push($(this).attr('src') || '');
        });
        
        // Get all link hrefs
        const links = [];
        $('link[href]').each(function() {
          links.push($(this).attr('href') || '');
        });
        
        // Combine all for ad network detection
        const allSources = [...scripts, ...iframes, ...links].join(' ');
        const inlineContent = inlineScripts.join(' ');
        
        return {
          url: request.url,
          scripts,
          iframes,
          allSources,
          inlineContent: inlineContent.substring(0, 5000)
        };
      }`,
      proxyConfiguration: { useApifyProxy: true },
    }, 60);

    if (items.length === 0) {
      return { success: true, scripts: [], adSignals: [] };
    }

    const item = items[0];
    const allContent = ((item.allSources || "") + " " + (item.inlineContent || "")).toLowerCase();

    // Known ad network patterns
    const AD_PATTERNS = [
      { name: "Monetag", patterns: ["monetag.com", "trk.monetag", "d-aa.com"] },
      { name: "AdSterra", patterns: ["adsterra.com", "astrfrm.com", "susession.com"] },
      { name: "PropellerAds", patterns: ["propellerads.com", "propu.sh", "pushprofit.net"] },
      { name: "AdMaven", patterns: ["admaven.com", "ad-maven.com", "servedbyadmaven"] },
      { name: "AdCash", patterns: ["adcash.com", "surfe.pro", "syndication.adcash"] },
      { name: "Google AdSense", patterns: ["pagead2.googlesyndication.com", "adsbygoogle", "google_ad_client"] },
      { name: "Taboola", patterns: ["taboola.com", "cdn.taboola.com"] },
      { name: "Outbrain", patterns: ["outbrain.com", "widgets.outbrain.com"] },
      { name: "ExoClick", patterns: ["exoclick.com", "exosrv.com"] },
      { name: "Media.net", patterns: ["media.net", "contextual.media.net"] },
      { name: "Ezoic", patterns: ["ezoic.com", "ezoic.net"] },
      { name: "PopAds", patterns: ["popads.net"] },
      { name: "PopCash", patterns: ["popcash.net"] },
      { name: "ClickAdu", patterns: ["clickadu.com", "vfrfrm.com"] },
      { name: "HilltopAds", patterns: ["hilltopads.com", "hilltopads.net"] },
      { name: "TrafficStars", patterns: ["trafficstars.com", "tsyndicate.com"] },
      { name: "MGID", patterns: ["mgid.com", "jsc.mgid"] },
      { name: "Infolinks", patterns: ["infolinks.com", "resources.infolinks"] },
    ];

    const detected: string[] = [];
    for (const ad of AD_PATTERNS) {
      if (ad.patterns.some(p => allContent.includes(p.toLowerCase()))) {
        detected.push(ad.name);
      }
    }

    return {
      success: true,
      scripts: (item.scripts || []).slice(0, 20),
      adSignals: detected,
    };
  } catch (error: any) {
    return {
      success: false,
      scripts: [],
      adSignals: [],
      error: error.message || "Apify ad detection failed",
    };
  }
}

/**
 * Test Apify connection
 */
export async function testApifyConnection(): Promise<{ success: boolean; error?: string }> {
  try {
    const apiKey = getApiKey();
    const resp = await axios.get(`${APIFY_BASE}/users/me?token=${apiKey}`);
    return { success: resp.status === 200 };
  } catch (error: any) {
    return { success: false, error: error.message };
  }
}
