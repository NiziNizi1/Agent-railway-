/**
 * Multi-Source Contact Discovery Engine
 * 
 * Strategies used (in order):
 * 1. Snov.io domain search (most reliable for emails)
 * 2. Google search for contact pages, social media, advertise pages
 * 3. WHOIS lookup for registrant info
 * 4. Playwright deep scrape with popup bypass
 * 5. LLM-powered extraction from all gathered data
 */
import axios from "axios";
import { exec } from "child_process";
import { promisify } from "util";
import { chromium, type Browser } from "playwright";
import { parseLLMJson } from "./llm-utils";
import { invokeLLM } from "./_core/llm";

const execAsync = promisify(exec);

// Shared browser instance for contact discovery (separate pool from ad-detection
// is fine — Playwright's launch is cheap once the binary is cached).
let _discoveryBrowser: Browser | null = null;
async function getDiscoveryBrowser(): Promise<Browser> {
  if (_discoveryBrowser && _discoveryBrowser.isConnected()) return _discoveryBrowser;
  _discoveryBrowser = await chromium.launch({
    headless: true,
    executablePath: process.env.PLAYWRIGHT_CHROMIUM_EXECUTABLE_PATH || undefined,
    args: [
      "--no-sandbox",
      "--disable-setuid-sandbox",
      "--disable-dev-shm-usage",
      "--disable-gpu",
    ],
  });
  return _discoveryBrowser;
}

const PW_USER_AGENT =
  "Mozilla/5.0 (Macintosh; Intel Mac OS X 10_15_7) AppleWebKit/537.36 " +
  "(KHTML, like Gecko) Chrome/120.0.0.0 Safari/537.36";

export interface DiscoveredContact {
  type: "email" | "telegram" | "discord" | "facebook" | "twitter" | "linkedin" | "whatsapp" | "skype" | "phone" | "other";
  value: string;
  source: string;
  confidence: "high" | "medium" | "low";
}

export interface ContactDiscoveryResult {
  contacts: DiscoveredContact[];
  sources: string[];
  error?: string;
}

// ─── Google Search for Contacts ─────────────────────────────────────────────

async function searchGoogleForContacts(domain: string): Promise<string[]> {
  const queries = [
    `site:${domain} "contact" OR "advertise" OR "about"`,
    `"${domain}" telegram OR discord OR "contact us" OR "advertise with us"`,
    `"${domain}" email contact advertise`,
    `"${domain}" "@gmail.com" OR "@yahoo.com" OR "@proton"`,
  ];

  const results: string[] = [];
  let context;
  let page;

  try {
    const browser = await getDiscoveryBrowser();
    context = await browser.newContext({ userAgent: PW_USER_AGENT });
    page = await context.newPage();

    for (const query of queries) {
      try {
        const url = `https://www.google.com/search?q=${encodeURIComponent(query)}&num=5`;
        await page.goto(url, { waitUntil: "domcontentloaded", timeout: 20_000 });
        await page.waitForTimeout(1500);

        const data = await page.evaluate((dom: string) => {
          const snippets = Array.from(
            document.querySelectorAll(
              ".VwiC3b, .s3v9rd, .IsZvec, span.aCOpRe, .lEBKkf"
            )
          )
            .map(el => (el.textContent as string) || "")
            .join(" ");
          const links = (
            Array.from(document.querySelectorAll("a[href]")) as HTMLAnchorElement[]
          )
            .map(a => a.href || "")
            .filter(
              h =>
                h.includes(dom) ||
                h.includes("telegram") ||
                h.includes("discord") ||
                h.includes("facebook") ||
                h.includes("twitter")
            );
          return {
            snippets: snippets.substring(0, 3000),
            links: links.slice(0, 20),
          };
        }, domain);

        if (data.snippets) results.push(data.snippets);
        if (data.links?.length) results.push(...data.links);
      } catch {
        // Continue with next query
      }
    }
  } catch {
    // Browser launch / context failed — return whatever we have
  } finally {
    try {
      await page?.close();
    } catch {}
    try {
      await context?.close();
    } catch {}
  }

  return results;
}

// ─── WHOIS Lookup ────────────────────────────────────────────────────────────

async function whoisLookup(domain: string): Promise<string> {
  try {
    const { stdout } = await execAsync(`whois ${domain} 2>/dev/null | head -60`, { timeout: 10000 });
    return stdout;
  } catch (e) {
    return "";
  }
}

// ─── Playwright Deep Scrape with Popup Bypass ────────────────────────────────

async function playwrightDeepScrape(domain: string): Promise<string> {
  const pagesToCheck = [
    `https://${domain}`,
    `https://${domain}/contact`,
    `https://${domain}/contact-us`,
    `https://${domain}/about`,
    `https://${domain}/advertise`,
    `https://${domain}/advertising`,
  ];

  let allText = "";
  let context;
  let page;

  try {
    const browser = await getDiscoveryBrowser();
    context = await browser.newContext({ userAgent: PW_USER_AGENT });
    page = await context.newPage();

    // Auto-dismiss any browser dialogs (alert/confirm/prompt)
    page.on("dialog", async dialog => {
      try {
        await dialog.dismiss();
      } catch {
        /* ignore */
      }
    });

    for (const url of pagesToCheck.slice(0, 3)) {
      try {
        await page.goto(url, {
          waitUntil: "domcontentloaded",
          timeout: 20_000,
        });
        await page.waitForTimeout(2000);

        // Aggressively click common close/dismiss buttons (cookie banners, popups)
        await page
          .evaluate(() => {
            const closeSelectors = [
              '[class*="close"]',
              '[class*="dismiss"]',
              '[class*="modal"]',
              '[id*="close"]',
              '[id*="popup"]',
              'button[aria-label="Close"]',
              ".fc-button-close",
              ".qc-cmp2-summary-buttons button",
              '[class*="cookie"] button',
              '[class*="consent"] button',
              '[class*="overlay"] button',
              '[class*="banner"] button',
            ];
            for (const sel of closeSelectors) {
              try {
                document.querySelectorAll(sel).forEach(el => {
                  if ((el as HTMLElement).offsetParent !== null) {
                    (el as HTMLElement).click();
                  }
                });
              } catch {
                /* ignore */
              }
            }
          })
          .catch(() => {});

        await page.waitForTimeout(800);

        const data = await page.evaluate(() => {
          const text = (document.body?.innerText as string) || "";
          const scripts = Array.from(
            document.querySelectorAll("script:not([src])")
          )
            .map(s => (s.textContent as string) || "")
            .join(" ");
          const links = (
            Array.from(document.querySelectorAll("a[href]")) as HTMLAnchorElement[]
          )
            .map(a => `${a.href} ${a.textContent || ""}`)
            .join(" ");
          return {
            text: text.substring(0, 5000),
            scripts: scripts.substring(0, 2000),
            links: links.substring(0, 3000),
            url: window.location.href,
          };
        });

        allText += `\n\n=== ${url} ===\n${data.text || ""}\n${data.links || ""}`;
      } catch {
        // Continue with next URL
      }
    }
  } catch {
    // Browser/context failed — return what we have
  } finally {
    try {
      await page?.close();
    } catch {}
    try {
      await context?.close();
    } catch {}
  }

  return allText;
}

// ─── Extract Contacts with Regex ─────────────────────────────────────────────

function extractContactsWithRegex(text: string, source: string): DiscoveredContact[] {
  const contacts: DiscoveredContact[] = [];
  const seen = new Set<string>();

  const addContact = (type: DiscoveredContact['type'], value: string, confidence: DiscoveredContact['confidence']) => {
    const key = `${type}:${value.toLowerCase()}`;
    if (!seen.has(key) && value.length > 3) {
      seen.add(key);
      contacts.push({ type, value, source, confidence });
    }
  };

  // Emails
  const emailRegex = /[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g;
  const emails = text.match(emailRegex) || [];
  for (const email of emails) {
    if (!email.includes('example.') && !email.includes('sentry.') && !email.endsWith('.png')) {
      addContact('email', email.toLowerCase(), 'high');
    }
  }

  // Telegram
  const telegramRegex = /(?:t\.me|telegram\.me|telegram\.org)\/([a-zA-Z0-9_]{3,})/gi;
  const telegramHandles = text.match(telegramRegex) || [];
  for (const tg of telegramHandles) {
    addContact('telegram', tg, 'high');
  }
  // Also @username patterns near "telegram"
  const tgContextRegex = /telegram[^\n]{0,50}@([a-zA-Z0-9_]{3,})/gi;
  let match;
  while ((match = tgContextRegex.exec(text)) !== null) {
    addContact('telegram', `@${match[1]}`, 'medium');
  }

  // Discord
  const discordRegex = /discord(?:\.gg|\.com\/invite)\/([a-zA-Z0-9\-_]{2,})/gi;
  const discordLinks = text.match(discordRegex) || [];
  for (const dc of discordLinks) {
    addContact('discord', dc, 'high');
  }
  // discord.gg/xxx
  const discordGgRegex = /discord\.gg\/([a-zA-Z0-9\-_]{2,})/gi;
  while ((match = discordGgRegex.exec(text)) !== null) {
    addContact('discord', `discord.gg/${match[1]}`, 'high');
  }

  // Facebook
  const fbRegex = /facebook\.com\/(?!sharer|share|dialog|photo|video|watch|pages\/category|hashtag|groups\/\d)([a-zA-Z0-9.\-_]{2,})/gi;
  while ((match = fbRegex.exec(text)) !== null) {
    if (!['www', 'l', 'login', 'home', 'profile', 'help', 'legal', 'privacy', 'terms'].includes(match[1].toLowerCase())) {
      addContact('facebook', `facebook.com/${match[1]}`, 'high');
    }
  }

  // Twitter/X
  const twitterRegex = /(?:twitter\.com|x\.com)\/([a-zA-Z0-9_]{1,})/gi;
  while ((match = twitterRegex.exec(text)) !== null) {
    if (!['i', 'intent', 'share', 'home', 'login', 'signup', 'explore'].includes(match[1].toLowerCase())) {
      addContact('twitter', `twitter.com/${match[1]}`, 'high');
    }
  }

  // LinkedIn
  const linkedinRegex = /linkedin\.com\/(?:in|company)\/([a-zA-Z0-9\-_]{2,})/gi;
  while ((match = linkedinRegex.exec(text)) !== null) {
    addContact('linkedin', `linkedin.com/${match[0].split('linkedin.com/')[1]}`, 'high');
  }

  // WhatsApp
  const waRegex = /(?:wa\.me|whatsapp\.com\/send\?phone=|api\.whatsapp\.com\/send\?phone=)([0-9+\-\s]{7,})/gi;
  while ((match = waRegex.exec(text)) !== null) {
    addContact('whatsapp', `wa.me/${match[1].replace(/[\s\-]/g, '')}`, 'high');
  }

  // Phone numbers (basic)
  const phoneRegex = /(?:tel:|phone:|call us:?\s*)([+\d\s\-()]{7,20})/gi;
  while ((match = phoneRegex.exec(text)) !== null) {
    const phone = match[1].trim();
    if (phone.replace(/\D/g, '').length >= 7) {
      addContact('phone', phone, 'medium');
    }
  }

  return contacts;
}

// ─── Main Discovery Function ──────────────────────────────────────────────────

export async function deepContactDiscovery(domain: string): Promise<ContactDiscoveryResult> {
  const allContacts: DiscoveredContact[] = [];
  const sources: string[] = [];
  const allText: string[] = [];

  // 1. WHOIS lookup (fast, often has registrant email)
  try {
    const whoisData = await whoisLookup(domain);
    if (whoisData) {
      sources.push("WHOIS");
      allText.push(whoisData);
      const whoisContacts = extractContactsWithRegex(whoisData, "WHOIS");
      allContacts.push(...whoisContacts);
    }
  } catch (e) { /* skip */ }

  // 2. Playwright deep scrape with popup bypass
  try {
    const pageText = await playwrightDeepScrape(domain);
    if (pageText) {
      sources.push("Website Scrape");
      allText.push(pageText);
      const pageContacts = extractContactsWithRegex(pageText, "Website");
      allContacts.push(...pageContacts);
    }
  } catch (e) { /* skip */ }

  // 3. Google search for contact info
  try {
    const googleResults = await searchGoogleForContacts(domain);
    if (googleResults.length > 0) {
      sources.push("Google Search");
      const combinedGoogle = googleResults.join('\n');
      allText.push(combinedGoogle);
      const googleContacts = extractContactsWithRegex(combinedGoogle, "Google");
      allContacts.push(...googleContacts);
    }
  } catch (e) { /* skip */ }

  // 4. Use LLM to extract any remaining contacts from all gathered text
  if (allText.length > 0) {
    try {
      const combinedText = allText.join('\n\n').substring(0, 8000);
      const response = await invokeLLM({
        messages: [
          {
            role: "system",
            content: `You are a contact information extractor. Given website content, extract ALL contact information.
Return ONLY valid JSON with a "contacts" array. Each contact has: type (email/telegram/discord/facebook/twitter/linkedin/whatsapp/phone/other), value (the actual contact value), confidence (high/medium/low).
Focus on: advertise@ emails, contact@ emails, Telegram groups/channels, Discord servers, Facebook pages, Twitter handles.
DO NOT include generic social media links like facebook.com/sharer or twitter.com/intent.`
          },
          {
            role: "user",
            content: `Extract all contact information for ${domain} from this content:\n\n${combinedText}`
          }
        ],
        response_format: {
          type: "json_schema",
          json_schema: {
            name: "contacts",
            strict: true,
            schema: {
              type: "object",
              properties: {
                contacts: {
                  type: "array",
                  items: {
                    type: "object",
                    properties: {
                      type: { type: "string" },
                      value: { type: "string" },
                      confidence: { type: "string" },
                    },
                    required: ["type", "value", "confidence"],
                    additionalProperties: false,
                  },
                },
              },
              required: ["contacts"],
              additionalProperties: false,
            },
          },
        },
      });

      const llmResult = parseLLMJson<{ contacts: DiscoveredContact[] }>(
        response.choices[0].message.content,
        { contacts: [] }
      );

      if (llmResult.contacts && llmResult.contacts.length > 0) {
        sources.push("AI Extraction");
        // Add LLM-found contacts that aren't already in our list
        const existingValues = new Set(allContacts.map(c => c.value.toLowerCase()));
        for (const c of llmResult.contacts) {
          if (!existingValues.has(c.value.toLowerCase())) {
            allContacts.push({ ...c, source: "AI" });
          }
        }
      }
    } catch (e) { /* skip LLM extraction */ }
  }

  // Deduplicate by value
  const seen = new Set<string>();
  const uniqueContacts = allContacts.filter(c => {
    const key = c.value.toLowerCase();
    if (seen.has(key)) return false;
    seen.add(key);
    return true;
  });

  return {
    contacts: uniqueContacts,
    sources,
  };
}
