import { COOKIE_NAME } from "@shared/const";
import { getSessionCookieOptions } from "./_core/cookies";
import { systemRouter } from "./_core/systemRouter";
import { publicProcedure, protectedProcedure, router } from "./_core/trpc";
import { z } from "zod";
import {
  createPublisher, bulkCreatePublishers, getPublishers, getPublisherById, getPublisherByDomain,
  updatePublisher, updatePublisherStatus, deletePublisher, getPublisherStats,
  getContactsByPublisher, createContact, deleteContact,
  getOutreachByPublisher, createOutreachEntry,
  getDraftsByPublisher, createEmailDraft,
  getNotifications, createNotification, markNotificationRead, markAllNotificationsRead,
  saveAdDetections, getAdDetectionsByPublisher,
} from "./db";
import { invokeLLM } from "./_core/llm";
import { notifyOwner } from "./_core/notification";
import { fetchSimilarWebData } from "./similarweb";
import { sendEmailViaGmail, scrapeContactsFromWebsite } from "./mcp-integrations";
import { snovDomainSearch, snovVerifyEmail } from "./snov";
import { detectAdsOnWebsite } from "./ad-detection";
import { apifyScrapeContacts, apifyScrapeAdNetworks } from "./apify";
import { scrapeWebsite, detectAdNetworksPuppeteer } from "./browser-scraper";
import { parseLLMJson } from "./llm-utils";
import { deepContactDiscovery } from "./contact-discovery";
import { runCompetitorDiscovery, findSimilarSitesForCompetitor, TARGET_COMPETITORS } from "./competitor-discovery";
import {
  scrapeContacts as orchestratedScrapeContacts,
  detectAds as orchestratedDetectAds,
  getScraperStatus,
  type ScraperStrategy,
} from "./scrape-orchestrator";
import { getCacheStats, clearCache } from "./_core/llm-cache";

// Helper to map network name to format type
function getFormatForNetwork(network: string): string {
  const map: Record<string, string> = {
    "Monetag": "Pop-under",
    "AdSterra": "Pop-under",
    "PropellerAds": "Pop-under/Push",
    "AdMaven": "Pop-under",
    "PopAds": "Pop-under",
    "PopCash": "Pop-under",
    "ClickAdu": "Pop-under",
    "AdCash": "Interstitial/Push",
    "RichPush": "Push",
    "Pushground": "Push",
    "Google AdSense": "Banner/Display",
    "Media.net": "Banner/Display",
    "Ezoic": "Banner/Display",
    "Infolinks": "In-text/Banner",
    "Taboola": "Native",
    "Outbrain": "Native",
    "MGID": "Native",
    "ExoClick": "Video/Pop",
    "TrafficStars": "Video/Banner",
    "HilltopAds": "Pop/Banner",
  };
  return map[network] || "Display";
}

export const appRouter = router({
  system: systemRouter,
  auth: router({
    me: publicProcedure.query(opts => opts.ctx.user),
    logout: publicProcedure.mutation(({ ctx }) => {
      const cookieOptions = getSessionCookieOptions(ctx.req);
      ctx.res.clearCookie(COOKIE_NAME, { ...cookieOptions, maxAge: -1 });
      return { success: true } as const;
    }),
  }),

  // ─── Publishers ─────────────────────────────────────────────────────────
  publishers: router({
    list: protectedProcedure
      .input(z.object({ status: z.string().optional(), minScore: z.number().optional() }).optional())
      .query(async ({ input }) => {
        return await getPublishers(input);
      }),

    getById: protectedProcedure
      .input(z.object({ id: z.number() }))
      .query(async ({ input }) => {
        return await getPublisherById(input.id);
      }),

    create: protectedProcedure
      .input(z.object({
        domain: z.string(),
        url: z.string().optional(),
        category: z.string().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input, ctx }) => {
        const domain = input.domain.toLowerCase().replace(/^https?:\/\//, '').replace(/\/.*$/, '').trim();
        return await createPublisher({
          domain,
          url: input.url || `https://${domain}`,
          category: input.category,
          notes: input.notes,
          addedBy: ctx.user.id,
        });
      }),

    bulkImport: protectedProcedure
      .input(z.object({ domains: z.array(z.string()) }))
      .mutation(async ({ input }) => {
        return await bulkCreatePublishers(input.domains);
      }),

    update: protectedProcedure
      .input(z.object({
        id: z.number(),
        domain: z.string().optional(),
        url: z.string().optional(),
        status: z.string().optional(),
        category: z.string().optional(),
        trafficTier: z.string().optional(),
        estimatedMonthlyVisits: z.number().optional(),
        adFormats: z.any().optional(),
        language: z.string().optional(),
        description: z.string().optional(),
        score: z.number().optional(),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const { id, ...data } = input;
        return await updatePublisher(id, data as any);
      }),

    updateStatus: protectedProcedure
      .input(z.object({
        id: z.number(),
        status: z.enum(["new", "cold_outreach_sent", "follow_up", "warm", "converted", "rejected"]),
        notes: z.string().optional(),
      }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.id);
        const result = await updatePublisherStatus(input.id, input.status, input.notes);

        // Log status change in outreach history
        await createOutreachEntry({
          publisherId: input.id,
          type: "status_change",
          content: `Status changed from "${publisher?.status}" to "${input.status}"`,
          metadata: { from: publisher?.status, to: input.status },
        });

        // Send notification on Warm or Converted
        if (input.status === "warm" || input.status === "converted") {
          const notifType = input.status === "warm" ? "status_warm" as const : "status_converted" as const;
          await createNotification({
            publisherId: input.id,
            type: notifType,
            title: `Lead ${publisher?.domain} moved to ${input.status.charAt(0).toUpperCase() + input.status.slice(1)}`,
            message: `Publisher ${publisher?.domain} has been marked as ${input.status}. ${input.notes || ''}`,
          });
          await notifyOwner({
            title: `Lead Status: ${publisher?.domain} → ${input.status.toUpperCase()}`,
            content: `Publisher ${publisher?.domain} has been marked as ${input.status}. ${input.notes || ''}`,
          });
        }

        return result;
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deletePublisher(input.id);
        return { success: true };
      }),

    stats: protectedProcedure.query(async () => {
      return await getPublisherStats();
    }),

    enrich: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.id);
        if (!publisher) throw new Error("Publisher not found");

        // Try SimilarWeb enrichment first
        const swData = await fetchSimilarWebData(publisher.domain);

        // Use LLM to enrich domain data (enhanced with SimilarWeb data if available)
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a domain analysis expert. Given a website domain, provide enrichment data. Return ONLY valid JSON with these fields:
- category: string (e.g., "Gaming", "Software", "Entertainment", "News", "File Hosting", "Streaming")
- trafficTier: string ("Tier 1 (1M+)", "Tier 2 (100K-1M)", "Tier 3 (10K-100K)", "Tier 4 (<10K)")
- language: string (primary language, e.g., "English", "Spanish")
- description: string (1-2 sentence description of the site)
- adFormats: string[] (detected or likely ad formats, e.g., ["Pop-under", "Native", "Push", "Banner"])
- estimatedMonthlyVisits: number (rough estimate)
- score: number (0-100, publisher quality score for ad monetization potential)`
            },
            {
              role: "user",
              content: `Analyze and enrich this domain: ${publisher.domain}${swData ? `\n\nSimilarWeb data available:\n${JSON.stringify(swData, null, 2)}` : ''}`
            }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "domain_enrichment",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  category: { type: "string" },
                  trafficTier: { type: "string" },
                  language: { type: "string" },
                  description: { type: "string" },
                  adFormats: { type: "array", items: { type: "string" } },
                  estimatedMonthlyVisits: { type: "integer" },
                  score: { type: "integer" },
                },
                required: ["category", "trafficTier", "language", "description", "adFormats", "estimatedMonthlyVisits", "score"],
                additionalProperties: false,
              },
            },
          },
        });

        const enrichment = parseLLMJson<Record<string, any>>(response.choices[0].message.content, {});
        
        // Build update with both LLM and SimilarWeb data
        const updateData: any = {
          category: enrichment.category,
          trafficTier: enrichment.trafficTier,
          language: enrichment.language,
          description: enrichment.description,
          adFormats: enrichment.adFormats,
          estimatedMonthlyVisits: enrichment.estimatedMonthlyVisits,
          score: enrichment.score,
        };
        
        // Save SimilarWeb data if available
        if (swData) {
          if (swData.globalRank) updateData.globalRank = swData.globalRank;
          if (swData.bounceRate) updateData.bounceRate = swData.bounceRate;
          if (swData.trafficSources) updateData.trafficSources = swData.trafficSources;
          if (swData.topCountries) updateData.topCountries = swData.topCountries;
          if (swData.totalVisits) updateData.estimatedMonthlyVisits = swData.totalVisits;
        }
        
        return await updatePublisher(input.id, updateData);
      }),
  }),

  // ─── Contacts ───────────────────────────────────────────────────────────
  contacts: router({
    getByPublisher: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .query(async ({ input }) => {
        return await getContactsByPublisher(input.publisherId);
      }),

    create: protectedProcedure
      .input(z.object({
        publisherId: z.number(),
        type: z.enum(["email", "linkedin", "twitter", "telegram", "phone", "other"]),
        value: z.string(),
        name: z.string().optional(),
        role: z.string().optional(),
        isPrimary: z.boolean().optional(),
      }))
      .mutation(async ({ input }) => {
        return await createContact(input);
      }),

    delete: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await deleteContact(input.id);
        return { success: true };
      }),
  }),

  // ─── Outreach History ───────────────────────────────────────────────────
  outreach: router({
    getByPublisher: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .query(async ({ input }) => {
        return await getOutreachByPublisher(input.publisherId);
      }),

    create: protectedProcedure
      .input(z.object({
        publisherId: z.number(),
        type: z.enum(["email_sent", "email_opened", "email_replied", "status_change", "note", "call", "meeting"]),
        subject: z.string().optional(),
        content: z.string().optional(),
        metadata: z.any().optional(),
      }))
      .mutation(async ({ input }) => {
        await createOutreachEntry(input);

        // If reply received, create notification
        if (input.type === "email_replied") {
          const publisher = await getPublisherById(input.publisherId);
          await createNotification({
            publisherId: input.publisherId,
            type: "reply_received",
            title: `Reply received from ${publisher?.domain}`,
            message: input.content || "A publisher has replied to your outreach.",
          });
          await notifyOwner({
            title: `Reply from ${publisher?.domain}!`,
            content: `Publisher ${publisher?.domain} has replied to your outreach. ${input.content || ''}`,
          });
        }

        return { success: true };
      }),
  }),

  // ─── Email Drafts / AI Pitch Generator ─────────────────────────────────
  drafts: router({
    getByPublisher: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .query(async ({ input }) => {
        return await getDraftsByPublisher(input.publisherId);
      }),

    generate: protectedProcedure
      .input(z.object({
        publisherId: z.number(),
        type: z.enum(["cold", "warm", "follow_up"]),
      }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");
        const contactsList = await getContactsByPublisher(input.publisherId);

        const typeLabel = input.type === "cold" ? "Cold Outreach" : input.type === "warm" ? "Warm Follow-up" : "Follow-up";

        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a senior ad monetization sales expert at AdMaven. Generate personalized outreach emails for publishers.
AdMaven specializes in: Push notifications, Pop-under, Interstitial, Native ads, and Smart Link monetization.
Key selling points: High CPMs, weekly payouts, dedicated account manager, anti-adblock technology, header bidding.

Return ONLY valid JSON with:
- subjectVariantA: string (primary subject line)
- subjectVariantB: string (alternative subject line for A/B testing)
- body: string (full email body in HTML format, professional and personalized)`
            },
            {
              role: "user",
              content: `Generate a ${typeLabel} email for this publisher:
Domain: ${publisher.domain}
Category: ${publisher.category || "Unknown"}
Traffic Tier: ${publisher.trafficTier || "Unknown"}
Language: ${publisher.language || "English"}
Description: ${publisher.description || "N/A"}
Current Ad Formats: ${JSON.stringify(publisher.adFormats) || "Unknown"}
Score: ${publisher.score || "N/A"}
Contact: ${contactsList[0]?.name || "Publisher"}

The email should be highly personalized, reference their specific site, and propose concrete monetization improvements.`
            }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "email_draft",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  subjectVariantA: { type: "string" },
                  subjectVariantB: { type: "string" },
                  body: { type: "string" },
                },
                required: ["subjectVariantA", "subjectVariantB", "body"],
                additionalProperties: false,
              },
            },
          },
        });

        const draft = parseLLMJson<{ subjectVariantA?: string; subjectVariantB?: string; body?: string }>(response.choices[0].message.content, {});
        if (!draft.subjectVariantA || !draft.body) throw new Error("LLM returned invalid draft format");
        await createEmailDraft({
          publisherId: input.publisherId,
          type: input.type,
          subjectVariantA: draft.subjectVariantA,
          subjectVariantB: draft.subjectVariantB,
          body: draft.body,
        });

        return draft;
      }),
  }),

  // ─── Notifications ──────────────────────────────────────────────────────
  notifications: router({
    list: protectedProcedure
      .input(z.object({ unreadOnly: z.boolean().optional() }).optional())
      .query(async ({ input }) => {
        return await getNotifications(input?.unreadOnly);
      }),

    markRead: protectedProcedure
      .input(z.object({ id: z.number() }))
      .mutation(async ({ input }) => {
        await markNotificationRead(input.id);
        return { success: true };
      }),

    markAllRead: protectedProcedure
      .mutation(async () => {
        await markAllNotificationsRead();
        return { success: true };
      }),
  }),

  // ─── Discovery ─────────────────────────────────────────────────────────
  discovery: router({
    findSimilar: protectedProcedure
      .input(z.object({ seedDomains: z.array(z.string()) }))
      .mutation(async ({ input }) => {
        const response = await invokeLLM({
          messages: [
            {
              role: "system",
              content: `You are a web analyst expert. Given seed domains, suggest similar websites that could be potential publisher partners for an ad network (AdMaven).
Focus on sites with: high traffic, content-heavy pages, file hosting, streaming, gaming, software downloads, news aggregation.
Return ONLY valid JSON with a "domains" array of objects, each with "domain" and "reason" fields. Suggest 5-10 similar sites.`
            },
            {
              role: "user",
              content: `Find similar publisher websites to these seed domains: ${input.seedDomains.join(", ")}`
            }
          ],
          response_format: {
            type: "json_schema",
            json_schema: {
              name: "similar_domains",
              strict: true,
              schema: {
                type: "object",
                properties: {
                  domains: {
                    type: "array",
                    items: {
                      type: "object",
                      properties: {
                        domain: { type: "string" },
                        reason: { type: "string" },
                      },
                      required: ["domain", "reason"],
                      additionalProperties: false,
                    },
                  },
                },
                required: ["domains"],
                additionalProperties: false,
              },
            },
          },
        });
        const result = parseLLMJson(response.choices[0].message.content, { domains: [] });
        return result.domains || [];
      }),
  }),

  // ─── Gmail Integration ──────────────────────────────────────────────
  gmail: router({
    send: protectedProcedure
      .input(z.object({
        publisherId: z.number(),
        to: z.string(),
        subject: z.string(),
        content: z.string(),
        draftId: z.number().optional(),
      }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        const result = await sendEmailViaGmail({
          to: input.to,
          subject: input.subject,
          content: input.content,
        });

        if (result.success) {
          // Log in outreach history
          await createOutreachEntry({
            publisherId: input.publisherId,
            type: "email_sent",
            subject: input.subject,
            content: `Sent to: ${input.to}`,
            metadata: { to: input.to, subject: input.subject },
          });

          // Update publisher metrics
          await updatePublisher(input.publisherId, {
            emailsSent: (publisher.emailsSent || 0) + 1,
            status: publisher.status === "new" ? "cold_outreach_sent" : publisher.status,
          } as any);
        }

        return result;
      }),
  }),

    // ─── Competitor-Based Discovery ──────────────────────────────────────────
  competitorDiscovery: router({
    // Get list of target competitor networks
    getCompetitors: protectedProcedure.query(() => TARGET_COMPETITORS),

    // Find similar sites for a specific domain + competitor network
    findSimilar: protectedProcedure
      .input(z.object({
        domain: z.string(),
        competitorNetwork: z.string(),
        count: z.number().default(10),
      }))
      .mutation(async ({ input }) => {
        const sites = await findSimilarSitesForCompetitor(
          input.domain,
          input.competitorNetwork,
          input.count
        );
        return { sites };
      }),

    // Run full competitor discovery on multiple domains in parallel
    runBulk: protectedProcedure
      .input(z.object({
        seedDomains: z.array(z.string()),
        competitorNetworks: z.array(z.string()),
        similarPerDomain: z.number().default(10),
        autoImport: z.boolean().default(true),
      }))
      .mutation(async ({ input }) => {
        const result = await runCompetitorDiscovery(
          input.seedDomains,
          input.competitorNetworks,
          input.similarPerDomain
        );

        // Auto-import discovered domains to pipeline
        let importedCount = 0;
        if (input.autoImport && result.allDiscovered.length > 0) {
          const domains = result.allDiscovered.map(s => s.domain);
          const importResult = await bulkCreatePublishers(domains);
          importedCount = importResult.imported;

          // Pre-fill enrichment data from discovery
          for (const site of result.allDiscovered) {
            try {
              const publisher = await getPublisherByDomain(site.domain);
              if (publisher && !publisher.category) {
                await updatePublisher(publisher.id, {
                  category: site.category,
                  trafficTier: site.trafficTier,
                  description: site.reason,
                } as any);
              }
            } catch (e) { /* skip */ }
          }
        }

        return {
          ...result,
          importedCount,
        };
      }),
  }),

  // ─── Deep Contact Discovery ──────────────────────────────────────────
  deepSearch: router({
    findContacts: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        // Use puppeteer scraper + WHOIS + LLM for comprehensive discovery
        const [scrapeResult, whoisResult] = await Promise.allSettled([
          scrapeWebsite(publisher.domain),
          import('child_process').then(({ exec }) => {
            const { promisify } = require('util');
            return promisify(exec)(`whois ${publisher.domain} 2>/dev/null | head -60`, { timeout: 10000 });
          }).then(r => r.stdout).catch(() => ''),
        ]);

        const scraped = scrapeResult.status === 'fulfilled' ? scrapeResult.value : { emails: [], phones: [], socialLinks: [], title: '', description: '', scripts: [] };
        const whoisText = whoisResult.status === 'fulfilled' ? whoisResult.value : '';

        // Extract contacts from WHOIS
        const whoisEmails = (whoisText.match(/[a-zA-Z0-9._%+\-]+@[a-zA-Z0-9.\-]+\.[a-zA-Z]{2,}/g) || []);

        // Build combined result
        const result = {
          contacts: [
            ...scraped.emails.map((e: string) => ({ type: 'email' as const, value: e, source: 'Website', confidence: 'high' as const })),
            ...whoisEmails.filter((e: string) => !e.includes('example.') && !e.includes('sentry.')).map((e: string) => ({ type: 'email' as const, value: e, source: 'WHOIS', confidence: 'high' as const })),
            ...scraped.socialLinks.map((l: any) => ({ type: (l.type || 'other') as any, value: l.url || l, source: 'Website', confidence: 'high' as const })),
          ],
          sources: ['Website Scrape', ...(whoisText ? ['WHOIS'] : [])],
        };

        // Save all discovered contacts
        const existingContacts = await getContactsByPublisher(input.publisherId);
        const existingValues = new Set(existingContacts.map((c: any) => c.value.toLowerCase()));
        let addedCount = 0;

        for (const contact of result.contacts) {
          if (!existingValues.has(contact.value.toLowerCase())) {
            const type = (['email', 'linkedin', 'twitter', 'telegram', 'phone', 'other'].includes(contact.type)
              ? contact.type : 'other') as any;
            await createContact({
              publisherId: input.publisherId,
              type,
              value: contact.value,
            });
            addedCount++;
          }
        }

        return {
          contacts: result.contacts,
          sources: result.sources,
          addedCount,
          total: result.contacts.length,
        };
      }),
  }),

  // ─── Browser Scraping (Puppeteer) ──────────────────────────────────────────
  scraper: router({
    scrapeContacts: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        // Use puppeteer-based scraper (works in production)
        const scraped = await scrapeWebsite(publisher.domain);

        // Auto-save discovered contacts
        let addedCount = 0;
        const existingContacts = await getContactsByPublisher(input.publisherId);
        const existingValues = new Set(existingContacts.map((c: any) => c.value.toLowerCase()));

        for (const email of scraped.emails) {
          if (!existingValues.has(email.toLowerCase())) {
            await createContact({
              publisherId: input.publisherId,
              type: "email",
              value: email,
            });
            addedCount++;
          }
        }

        for (const link of scraped.socialLinks) {
          const linkValue = typeof link === 'string' ? link : (link as any).url;
          const linkType = typeof link === 'string' ? 'other' : (link as any).type;
          if (!existingValues.has(linkValue.toLowerCase())) {
            const type = (['email', 'linkedin', 'twitter', 'telegram', 'phone', 'other'].includes(linkType)
              ? linkType : 'other') as any;
            await createContact({
              publisherId: input.publisherId,
              type,
              value: linkValue,
            });
            addedCount++;
          }
        }

        return {
          emails: scraped.emails,
          phones: scraped.phones,
          socialLinks: scraped.socialLinks.map((l: any) => typeof l === 'string' ? l : l.url),
          addedCount,
          error: scraped.error,
        };
      }),
  }),

  // ─── Smart Scrape (Apify-first, Playwright-fallback) ─────────────────────
  // Use these endpoints from the frontend going forward. They auto-pick the
  // best engine based on env config and per-call overrides.
  scrape: router({
    // Diagnostic: returns which engine is active and whether Apify is wired.
    status: protectedProcedure.query(() => {
      return getScraperStatus();
    }),

    // Smart contact discovery with auto-routing + persistence.
    contacts: protectedProcedure
      .input(z.object({
        publisherId: z.number(),
        strategy: z.enum(["auto", "apify", "playwright", "merge"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        const result = await orchestratedScrapeContacts(
          publisher.domain,
          input.strategy as ScraperStrategy | undefined
        );

        if (!result.success) {
          return { ...result, addedCount: 0 };
        }

        // Persist new contacts (dedup against existing by lowercase value)
        const existingContacts = await getContactsByPublisher(input.publisherId);
        const existingValues = new Set(
          existingContacts.map((c: any) => c.value.toLowerCase())
        );
        let addedCount = 0;

        for (const email of result.emails) {
          if (!existingValues.has(email.toLowerCase())) {
            await createContact({
              publisherId: input.publisherId,
              type: "email",
              value: email,
            });
            addedCount++;
          }
        }

        for (const link of result.socialLinks) {
          if (existingValues.has(link.toLowerCase())) continue;
          const lower = link.toLowerCase();
          const type = lower.includes("linkedin")
            ? ("linkedin" as const)
            : lower.includes("twitter") || lower.includes("x.com")
            ? ("twitter" as const)
            : lower.includes("t.me")
            ? ("telegram" as const)
            : ("other" as const);
          await createContact({
            publisherId: input.publisherId,
            type,
            value: link,
          });
          addedCount++;
        }

        // Opportunistically backfill description if we got one
        if (result.description && !publisher.description) {
          await updatePublisher(input.publisherId, {
            description: result.description,
          } as any);
        }

        return { ...result, addedCount };
      }),

    // Smart ad-network detection with auto-routing + persistence.
    ads: protectedProcedure
      .input(z.object({
        publisherId: z.number(),
        strategy: z.enum(["auto", "apify", "playwright", "merge"]).optional(),
      }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        const result = await orchestratedDetectAds(
          publisher.domain,
          input.strategy as ScraperStrategy | undefined
        );

        if (result.success && result.detectedAds.length > 0) {
          await saveAdDetections(input.publisherId, result.detectedAds);
          await updatePublisher(input.publisherId, {
            adFormats: result.detectedAds.map(
              ad => `${ad.network} (${ad.format})`
            ),
          } as any);
        }

        return result;
      }),
  }),

  // ─── LLM Cache management ────────────────────────────────────────────────
  // Use these to monitor savings or wipe the cache after prompt changes.
  cache: router({
    stats: protectedProcedure.query(async () => {
      return await getCacheStats();
    }),

    clear: protectedProcedure.mutation(async () => {
      const removed = await clearCache();
      return { success: true, removed };
    }),
  }),

  // ─── Apify Scraping (legacy — use scrape.* instead) ──────────────────────
  apify: router({
    scrapeContacts: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        const result = await apifyScrapeContacts(publisher.domain);

        if (result.success) {
          const existingContacts = await getContactsByPublisher(input.publisherId);
          const existingValues = new Set(existingContacts.map((c: any) => c.value.toLowerCase()));
          let addedCount = 0;

          for (const email of result.emails) {
            if (!existingValues.has(email.toLowerCase())) {
              await createContact({ publisherId: input.publisherId, type: "email", value: email });
              addedCount++;
            }
          }
          for (const link of result.socialLinks) {
            if (!existingValues.has(link.toLowerCase())) {
              const type = link.includes('linkedin') ? 'linkedin' as const :
                           link.includes('twitter') ? 'twitter' as const :
                           link.includes('t.me') ? 'telegram' as const : 'other' as const;
              await createContact({ publisherId: input.publisherId, type, value: link });
              addedCount++;
            }
          }

          // Update publisher description/title if found
          if (result.title || result.description) {
            await updatePublisher(input.publisherId, {
              description: result.description || publisher.description,
            } as any);
          }

          return { ...result, addedCount };
        }

        return { ...result, addedCount: 0 };
      }),

    detectAds: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        const result = await apifyScrapeAdNetworks(publisher.domain);

        if (result.success && result.adSignals.length > 0) {
          // Map to structured detections and persist
          const detections = result.adSignals.map(network => ({
            network,
            format: getFormatForNetwork(network),
            confidence: "high" as const,
            evidence: `Detected via Apify scraper`,
          }));
          await saveAdDetections(input.publisherId, detections);
          await updatePublisher(input.publisherId, {
            adFormats: result.adSignals.map(n => `${n} (${getFormatForNetwork(n)})`),
          } as any);
        }

        return result;
      }),
  }),

  // ─── Ad Network Detection ──────────────────────────────────────────
  adDetection: router({
    detect: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        // Use puppeteer-based detection (works in production)
        const result = await detectAdNetworksPuppeteer(publisher.domain);

        // Persist structured detection results to DB
        if (result.detectedNetworks.length > 0) {
          await saveAdDetections(input.publisherId, result.detectedNetworks);
          const adFormats = result.detectedNetworks.map(a => `${a.network} (${a.format})`);
          await updatePublisher(input.publisherId, { adFormats } as any);
        }

        return {
          detectedAds: result.detectedNetworks,
          scripts: [],
          error: result.error,
        };
      }),

    getDetections: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .query(async ({ input }) => {
        return await getAdDetectionsByPublisher(input.publisherId);
      }),
  }),

  // ─── Snov.io Integration ──────────────────────────────────────────
  snov: router({
    findEmails: protectedProcedure
      .input(z.object({ publisherId: z.number() }))
      .mutation(async ({ input }) => {
        const publisher = await getPublisherById(input.publisherId);
        if (!publisher) throw new Error("Publisher not found");

        const result = await snovDomainSearch(publisher.domain);

        if (result.success && result.emails.length > 0) {
          // Auto-save found emails as contacts
          const existingContacts = await getContactsByPublisher(input.publisherId);
          const existingValues = new Set(existingContacts.map((c: any) => c.value.toLowerCase()));
          let addedCount = 0;

          for (const found of result.emails) {
            if (!existingValues.has(found.email.toLowerCase())) {
              await createContact({
                publisherId: input.publisherId,
                type: "email",
                value: found.email,
                name: [found.firstName, found.lastName].filter(Boolean).join(" ") || undefined,
                role: found.position || undefined,
              });
              addedCount++;
            }
          }

          return { ...result, addedCount };
        }

        return { ...result, addedCount: 0 };
      }),

    verifyEmail: protectedProcedure
      .input(z.object({ email: z.string() }))
      .mutation(async ({ input }) => {
        return await snovVerifyEmail(input.email);
      }),
  }),

  // ─── Agent Workflow (Full Pipeline Automation) ───────────────────────
  agent: router({
    // Run full pipeline: discover similar sites, add to pipeline, enrich, scrape, generate pitch
    runFullPipeline: protectedProcedure
      .input(z.object({
        seedDomains: z.array(z.string()),
        autoEnrich: z.boolean().default(true),
        autoScrape: z.boolean().default(true),
        autoGeneratePitch: z.boolean().default(true),
      }))
      .mutation(async ({ input }) => {
        const log: Array<{ step: string; status: string; detail?: string }> = [];

        // Step 1: Discover similar sites
        log.push({ step: "discovery", status: "running", detail: `Finding sites similar to: ${input.seedDomains.join(", ")}` });
        let discoveredDomains: string[] = [];
        try {
          const response = await invokeLLM({
            messages: [
              {
                role: "system",
                content: `You are a web analyst expert. Given seed domains, suggest similar websites that could be potential publisher partners for an ad network (AdMaven). Focus on sites with: high traffic, content-heavy pages, file hosting, streaming, gaming, software downloads, news aggregation. Return ONLY valid JSON with a "domains" array of strings (just domain names).`
              },
              {
                role: "user",
                content: `Find 8-12 similar publisher websites to these seed domains: ${input.seedDomains.join(", ")}`
              }
            ],
            response_format: {
              type: "json_schema",
              json_schema: {
                name: "discovered_domains",
                strict: true,
                schema: {
                  type: "object",
                  properties: {
                    domains: { type: "array", items: { type: "string" } },
                  },
                  required: ["domains"],
                  additionalProperties: false,
                },
              },
            },
          });
          const result = parseLLMJson(response.choices[0].message.content, { domains: [] });
          discoveredDomains = result.domains || [];
          log.push({ step: "discovery", status: "done", detail: `Found ${discoveredDomains.length} domains` });
        } catch (e: any) {
          log.push({ step: "discovery", status: "error", detail: e.message });
        }

        // Step 2: Add to pipeline
        log.push({ step: "import", status: "running", detail: `Importing ${discoveredDomains.length} domains` });
        let importedCount = 0;
        try {
          const importResult = await bulkCreatePublishers(discoveredDomains);
          importedCount = importResult.imported;
          log.push({ step: "import", status: "done", detail: `Imported ${importedCount} domains` });
        } catch (e: any) {
          log.push({ step: "import", status: "error", detail: e.message });
        }

        // Step 3: Enrich all new leads
        let enrichedCount = 0;
        if (input.autoEnrich) {
          log.push({ step: "enrich", status: "running" });
          const allPublishers = await getPublishers({ status: "new" });
          const toEnrich = allPublishers.filter((p: any) => !p.category).slice(0, 10);
          for (const pub of toEnrich) {
            try {
              const swData = await fetchSimilarWebData(pub.domain);
              const response = await invokeLLM({
                messages: [
                  { role: "system", content: `You are a domain analysis expert. Return ONLY valid JSON with: category (string), trafficTier (string), language (string), description (string), adFormats (string[]), estimatedMonthlyVisits (integer), score (integer 0-100).` },
                  { role: "user", content: `Analyze: ${pub.domain}${swData ? ` SimilarWeb: ${JSON.stringify(swData)}` : ''}` }
                ],
                response_format: {
                  type: "json_schema",
                  json_schema: {
                    name: "enrichment",
                    strict: true,
                    schema: {
                      type: "object",
                      properties: {
                        category: { type: "string" },
                        trafficTier: { type: "string" },
                        language: { type: "string" },
                        description: { type: "string" },
                        adFormats: { type: "array", items: { type: "string" } },
                        estimatedMonthlyVisits: { type: "integer" },
                        score: { type: "integer" },
                      },
                      required: ["category", "trafficTier", "language", "description", "adFormats", "estimatedMonthlyVisits", "score"],
                      additionalProperties: false,
                    },
                  },
                },
              });
              const enrichment = parseLLMJson(response.choices[0].message.content, {});
              await updatePublisher(pub.id, { ...enrichment, ...(swData?.globalRank ? { globalRank: swData.globalRank } : {}), ...(swData?.bounceRate ? { bounceRate: swData.bounceRate } : {}) } as any);
              enrichedCount++;
            } catch (e) {
              // Skip failed enrichments
            }
          }
          log.push({ step: "enrich", status: "done", detail: `Enriched ${enrichedCount} leads` });
        }

        // Step 4: Scrape contacts
        let scrapedCount = 0;
        if (input.autoScrape) {
          log.push({ step: "scrape", status: "running" });
          const allPublishers = await getPublishers();
          const toScrape = allPublishers.slice(0, 5);
          for (const pub of toScrape) {
            try {
              const contacts = await getContactsByPublisher(pub.id);
              if (contacts.length === 0) {
                const scraped = await scrapeContactsFromWebsite(pub.domain);
                for (const email of scraped.emails) {
                  await createContact({ publisherId: pub.id, type: "email", value: email });
                  scrapedCount++;
                }
                for (const link of scraped.socialLinks) {
                  const type = link.includes('linkedin') ? 'linkedin' as const : link.includes('twitter') ? 'twitter' as const : 'other' as const;
                  await createContact({ publisherId: pub.id, type, value: link });
                  scrapedCount++;
                }
              }
            } catch (e) {
              // Skip failed scrapes
            }
          }
          log.push({ step: "scrape", status: "done", detail: `Added ${scrapedCount} contacts` });
        }

        // Step 5: Generate pitches for top leads
        let pitchesGenerated = 0;
        if (input.autoGeneratePitch) {
          log.push({ step: "pitch", status: "running" });
          const allPublishers = await getPublishers();
          const topLeads = allPublishers.filter((p: any) => p.score && p.score >= 60).slice(0, 5);
          for (const pub of topLeads) {
            try {
              const existingDrafts = await getDraftsByPublisher(pub.id);
              if (existingDrafts.length === 0) {
                const contacts = await getContactsByPublisher(pub.id);
                const response = await invokeLLM({
                  messages: [
                    { role: "system", content: `You are a senior ad monetization sales expert at AdMaven. Generate a cold outreach email. Return ONLY valid JSON with: subjectVariantA (string), subjectVariantB (string), body (string in HTML).` },
                    { role: "user", content: `Cold email for: ${pub.domain}, Category: ${pub.category || "Unknown"}, Traffic: ${pub.trafficTier || "Unknown"}, Contact: ${contacts[0]?.name || "Publisher"}` }
                  ],
                  response_format: {
                    type: "json_schema",
                    json_schema: {
                      name: "email_draft",
                      strict: true,
                      schema: {
                        type: "object",
                        properties: {
                          subjectVariantA: { type: "string" },
                          subjectVariantB: { type: "string" },
                          body: { type: "string" },
                        },
                        required: ["subjectVariantA", "subjectVariantB", "body"],
                        additionalProperties: false,
                      },
                    },
                  },
                });
                const draft = parseLLMJson<{ subjectVariantA?: string; subjectVariantB?: string; body?: string }>(response.choices[0].message.content, {});
                if (draft.subjectVariantA && draft.body) {
                  await createEmailDraft({ publisherId: pub.id, type: "cold", subjectVariantA: draft.subjectVariantA, subjectVariantB: draft.subjectVariantB, body: draft.body });
                }
                pitchesGenerated++;
              }
            } catch (e) {
              // Skip failed pitch generation
            }
          }
          log.push({ step: "pitch", status: "done", detail: `Generated ${pitchesGenerated} pitches` });
        }

        return {
          log,
          summary: {
            discovered: discoveredDomains.length,
            imported: importedCount,
            enriched: enrichedCount,
            contactsScraped: scrapedCount,
            pitchesGenerated,
          },
        };
      }),

    // Bulk enrich all unenriched leads
    bulkEnrich: protectedProcedure
      .input(z.object({ limit: z.number().default(10) }))
      .mutation(async ({ input }) => {
        const allPublishers = await getPublishers();
        const toEnrich = allPublishers.filter((p: any) => !p.category).slice(0, input.limit);
        let enrichedCount = 0;
        for (const pub of toEnrich) {
          try {
            const response = await invokeLLM({
              messages: [
                { role: "system", content: `Domain analysis expert. Return JSON: category, trafficTier, language, description, adFormats (array), estimatedMonthlyVisits (int), score (int 0-100).` },
                { role: "user", content: `Analyze: ${pub.domain}` }
              ],
              response_format: {
                type: "json_schema",
                json_schema: {
                  name: "enrichment",
                  strict: true,
                  schema: {
                    type: "object",
                    properties: {
                      category: { type: "string" },
                      trafficTier: { type: "string" },
                      language: { type: "string" },
                      description: { type: "string" },
                      adFormats: { type: "array", items: { type: "string" } },
                      estimatedMonthlyVisits: { type: "integer" },
                      score: { type: "integer" },
                    },
                    required: ["category", "trafficTier", "language", "description", "adFormats", "estimatedMonthlyVisits", "score"],
                    additionalProperties: false,
                  },
                },
              },
            });
            const enrichment = parseLLMJson(response.choices[0].message.content, {});
            await updatePublisher(pub.id, enrichment as any);
            enrichedCount++;
          } catch (e) { /* skip */ }
        }
        return { enriched: enrichedCount, total: toEnrich.length };
      }),
  }),
});

export type AppRouter = typeof appRouter;
