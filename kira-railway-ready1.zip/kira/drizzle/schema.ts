import { int, mysqlEnum, mysqlTable, text, timestamp, varchar, float, json, boolean } from "drizzle-orm/mysql-core";

/**
 * Core user table backing auth flow.
 */
export const users = mysqlTable("users", {
  id: int("id").autoincrement().primaryKey(),
  openId: varchar("openId", { length: 64 }).notNull().unique(),
  name: text("name"),
  email: varchar("email", { length: 320 }),
  loginMethod: varchar("loginMethod", { length: 64 }),
  role: mysqlEnum("role", ["user", "admin"]).default("user").notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
  lastSignedIn: timestamp("lastSignedIn").defaultNow().notNull(),
});

export type User = typeof users.$inferSelect;
export type InsertUser = typeof users.$inferInsert;

/**
 * Publisher leads table - core CRM entity
 */
export const publishers = mysqlTable("publishers", {
  id: int("id").autoincrement().primaryKey(),
  domain: varchar("domain", { length: 255 }).notNull().unique(),
  url: varchar("url", { length: 512 }),
  status: mysqlEnum("status", ["new", "cold_outreach_sent", "follow_up", "warm", "converted", "rejected"]).default("new").notNull(),
  // Domain enrichment
  category: varchar("category", { length: 128 }),
  trafficTier: varchar("trafficTier", { length: 32 }),
  estimatedMonthlyVisits: int("estimatedMonthlyVisits"),
  adFormats: json("adFormats"),
  language: varchar("language", { length: 32 }),
  description: text("description"),
  // SimilarWeb data
  globalRank: int("globalRank"),
  bounceRate: float("bounceRate"),
  trafficSources: json("trafficSources"),
  topCountries: json("topCountries"),
  // Scoring
  score: int("score"),
  // Campaign metrics
  emailsSent: int("emailsSent").default(0),
  emailsOpened: int("emailsOpened").default(0),
  emailsReplied: int("emailsReplied").default(0),
  // Metadata
  notes: text("notes"),
  addedBy: int("addedBy"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  updatedAt: timestamp("updatedAt").defaultNow().onUpdateNow().notNull(),
});

export type Publisher = typeof publishers.$inferSelect;
export type InsertPublisher = typeof publishers.$inferInsert;

/**
 * Contact information per publisher
 */
export const contacts = mysqlTable("contacts", {
  id: int("id").autoincrement().primaryKey(),
  publisherId: int("publisherId").notNull(),
  type: mysqlEnum("type", ["email", "linkedin", "twitter", "telegram", "phone", "other"]).notNull(),
  value: varchar("value", { length: 512 }).notNull(),
  name: varchar("name", { length: 255 }),
  role: varchar("role", { length: 128 }),
  isPrimary: boolean("isPrimary").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Contact = typeof contacts.$inferSelect;
export type InsertContact = typeof contacts.$inferInsert;

/**
 * Outreach history - timeline of all interactions
 */
export const outreachHistory = mysqlTable("outreach_history", {
  id: int("id").autoincrement().primaryKey(),
  publisherId: int("publisherId").notNull(),
  type: mysqlEnum("type", ["email_sent", "email_opened", "email_replied", "status_change", "note", "call", "meeting"]).notNull(),
  subject: varchar("subject", { length: 512 }),
  content: text("content"),
  metadata: json("metadata"),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type OutreachHistory = typeof outreachHistory.$inferSelect;
export type InsertOutreachHistory = typeof outreachHistory.$inferInsert;

/**
 * Generated email drafts with A/B variants
 */
export const emailDrafts = mysqlTable("email_drafts", {
  id: int("id").autoincrement().primaryKey(),
  publisherId: int("publisherId").notNull(),
  type: mysqlEnum("type", ["cold", "warm", "follow_up"]).notNull(),
  subjectVariantA: varchar("subjectVariantA", { length: 512 }).notNull(),
  subjectVariantB: varchar("subjectVariantB", { length: 512 }),
  body: text("body").notNull(),
  isUsed: boolean("isUsed").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type EmailDraft = typeof emailDrafts.$inferSelect;
export type InsertEmailDraft = typeof emailDrafts.$inferInsert;

/**
 * Notifications for account manager
 */
export const notifications = mysqlTable("notifications", {
  id: int("id").autoincrement().primaryKey(),
  publisherId: int("publisherId"),
  type: mysqlEnum("type", ["reply_received", "status_warm", "status_converted", "system"]).notNull(),
  title: varchar("title", { length: 255 }).notNull(),
  message: text("message"),
  isRead: boolean("isRead").default(false),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
});

export type Notification = typeof notifications.$inferSelect;
export type InsertNotification = typeof notifications.$inferInsert;

/**
 * Ad network detection results per publisher
 */
export const adDetections = mysqlTable("ad_detections", {
  id: int("id").autoincrement().primaryKey(),
  publisherId: int("publisherId").notNull(),
  network: varchar("network", { length: 128 }).notNull(),
  format: varchar("format", { length: 128 }).notNull(),
  confidence: mysqlEnum("confidence", ["high", "medium", "low"]).notNull(),
  evidence: text("evidence"),
  detectedAt: timestamp("detectedAt").defaultNow().notNull(),
});

export type AdDetection = typeof adDetections.$inferSelect;
export type InsertAdDetection = typeof adDetections.$inferInsert;

/**
 * LLM response cache. Keyed by a SHA-256 hash of the deterministic request
 * inputs (model + system + messages + schema). Entries are reused for
 * identical requests until `expiresAt`.
 *
 * `responseJson` stores the full InvokeResult so callers get back exactly
 * what they would have gotten from a live call (text, tool calls, usage).
 *
 * `inputTokens` / `outputTokens` mirror the live response's usage so we can
 * compute total tokens saved for cost reporting.
 */
export const llmCache = mysqlTable("llm_cache", {
  id: int("id").autoincrement().primaryKey(),
  cacheKey: varchar("cacheKey", { length: 64 }).notNull().unique(),
  model: varchar("model", { length: 128 }).notNull(),
  responseJson: json("responseJson").notNull(),
  inputTokens: int("inputTokens").default(0),
  outputTokens: int("outputTokens").default(0),
  hitCount: int("hitCount").default(0).notNull(),
  createdAt: timestamp("createdAt").defaultNow().notNull(),
  lastHitAt: timestamp("lastHitAt").defaultNow().notNull(),
  expiresAt: timestamp("expiresAt").notNull(),
});

export type LlmCacheRow = typeof llmCache.$inferSelect;
export type InsertLlmCache = typeof llmCache.$inferInsert;
