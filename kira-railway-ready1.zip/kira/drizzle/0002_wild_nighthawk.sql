ALTER TABLE `publishers` ADD `globalRank` int;--> statement-breakpoint
ALTER TABLE `publishers` ADD `bounceRate` float;--> statement-breakpoint
ALTER TABLE `publishers` ADD `trafficSources` json;--> statement-breakpoint
ALTER TABLE `publishers` ADD `topCountries` json;