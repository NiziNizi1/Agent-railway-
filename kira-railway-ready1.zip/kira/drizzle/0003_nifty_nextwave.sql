CREATE TABLE `ad_detections` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publisherId` int NOT NULL,
	`network` varchar(128) NOT NULL,
	`format` varchar(128) NOT NULL,
	`confidence` enum('high','medium','low') NOT NULL,
	`evidence` text,
	`detectedAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `ad_detections_id` PRIMARY KEY(`id`)
);
