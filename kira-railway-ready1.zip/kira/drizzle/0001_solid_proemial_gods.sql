CREATE TABLE `contacts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publisherId` int NOT NULL,
	`type` enum('email','linkedin','twitter','telegram','phone','other') NOT NULL,
	`value` varchar(512) NOT NULL,
	`name` varchar(255),
	`role` varchar(128),
	`isPrimary` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `contacts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `email_drafts` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publisherId` int NOT NULL,
	`type` enum('cold','warm','follow_up') NOT NULL,
	`subjectVariantA` varchar(512) NOT NULL,
	`subjectVariantB` varchar(512),
	`body` text NOT NULL,
	`isUsed` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `email_drafts_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `notifications` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publisherId` int,
	`type` enum('reply_received','status_warm','status_converted','system') NOT NULL,
	`title` varchar(255) NOT NULL,
	`message` text,
	`isRead` boolean DEFAULT false,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `notifications_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `outreach_history` (
	`id` int AUTO_INCREMENT NOT NULL,
	`publisherId` int NOT NULL,
	`type` enum('email_sent','email_opened','email_replied','status_change','note','call','meeting') NOT NULL,
	`subject` varchar(512),
	`content` text,
	`metadata` json,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	CONSTRAINT `outreach_history_id` PRIMARY KEY(`id`)
);
--> statement-breakpoint
CREATE TABLE `publishers` (
	`id` int AUTO_INCREMENT NOT NULL,
	`domain` varchar(255) NOT NULL,
	`url` varchar(512),
	`status` enum('new','cold_outreach_sent','follow_up','warm','converted','rejected') NOT NULL DEFAULT 'new',
	`category` varchar(128),
	`trafficTier` varchar(32),
	`estimatedMonthlyVisits` int,
	`adFormats` json,
	`language` varchar(32),
	`description` text,
	`score` int,
	`emailsSent` int DEFAULT 0,
	`emailsOpened` int DEFAULT 0,
	`emailsReplied` int DEFAULT 0,
	`notes` text,
	`addedBy` int,
	`createdAt` timestamp NOT NULL DEFAULT (now()),
	`updatedAt` timestamp NOT NULL DEFAULT (now()) ON UPDATE CURRENT_TIMESTAMP,
	CONSTRAINT `publishers_id` PRIMARY KEY(`id`),
	CONSTRAINT `publishers_domain_unique` UNIQUE(`domain`)
);
