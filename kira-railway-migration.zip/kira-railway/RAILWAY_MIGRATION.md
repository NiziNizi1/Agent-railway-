# Kira Agent → Railway Deployment

This is the **migration package** to take Kira out of Manus and deploy on Railway with persistent data.

---

## What's in this package

| File | Replaces | Purpose |
|------|----------|---------|
| `llm.ts` | `_core/llm.ts` | Anthropic Claude SDK — no Manus wrapper |
| `mcp-integrations.ts` | original (MCP CLI version) | Direct googleapis + Playwright |
| `ad-detection.ts` | original (MCP CLI version) | Direct Playwright |
| `notification.ts` | `_core/notification.ts` | Telegram bot |
| `railway.json` | — | Railway build config |
| `Dockerfile` | — | Container with Chromium |
| `.env.example` | — | All required env vars |

---

## Step-by-step migration

### 1. Clone Kira locally

```bash
git clone YOUR_KIRA_REPO kira-railway
cd kira-railway
```

### 2. Replace files

```bash
# Backup originals
mv server/_core/llm.ts server/_core/llm.ts.bak
mv server/mcp-integrations.ts server/mcp-integrations.ts.bak
mv server/ad-detection.ts server/ad-detection.ts.bak
mv server/_core/notification.ts server/_core/notification.ts.bak

# Drop in new files
cp llm.ts server/_core/llm.ts
cp mcp-integrations.ts server/mcp-integrations.ts
cp ad-detection.ts server/ad-detection.ts
cp notification.ts server/_core/notification.ts
```

### 3. Install dependencies

Add to `package.json`:

```json
{
  "dependencies": {
    "@anthropic-ai/sdk": "^0.30.0",
    "googleapis": "^144.0.0",
    "playwright": "^1.48.0"
  }
}
```

```bash
npm install
npx playwright install chromium --with-deps
```

### 4. Get Gmail OAuth refresh token (one-time)

1. Go to [Google Cloud Console](https://console.cloud.google.com/) → create project
2. Enable Gmail API
3. Create OAuth 2.0 Client ID (Desktop app)
4. Use [OAuth Playground](https://developers.google.com/oauthplayground/):
   - Settings (gear icon) → Use your own OAuth credentials → paste Client ID + Secret
   - Select scope: `https://www.googleapis.com/auth/gmail.send`
   - Authorize → Exchange code for token → copy the **Refresh token**

### 5. Set up Railway

1. Open [railway.app](https://railway.app) (works from iPhone Safari)
2. **New Project** → Deploy from GitHub
3. Add **MySQL plugin** — Railway will auto-set `DATABASE_URL`
4. **Variables** tab — add:

```env
ANTHROPIC_API_KEY=sk-ant-...
GOOGLE_CLIENT_ID=xxx.apps.googleusercontent.com
GOOGLE_CLIENT_SECRET=GOCSPX-...
GOOGLE_REFRESH_TOKEN=1//0g...
TELEGRAM_BOT_TOKEN=123456:ABC-DEF...
TELEGRAM_CHAT_ID=12345678
SNOV_CLIENT_ID=xxx
SNOV_CLIENT_SECRET=xxx
SIMILARWEB_API_KEY=xxx
SESSION_SECRET=$(openssl rand -hex 32)
PORT=3000
```

5. **Settings** → set start command: `npm start`
6. Push the migration → Railway auto-deploys

### 6. Run DB migrations

In Railway shell or locally with the Railway DATABASE_URL:

```bash
npx drizzle-kit push:mysql
```

---

## Auth note

Manus has its own auth flow (`getLoginUrl`, `useAuth`). For Railway you have two options:

**Option A — Single-user mode (fastest):**
Disable auth checks. Replace `protectedProcedure` with `publicProcedure` in routers, OR add a hardcoded user check by IP/secret header.

**Option B — Real auth:**
Add NextAuth or a simple JWT layer. Email/password against the `users` table.

For personal use → Option A. For team → Option B.

---

## What works after migration

| Feature | Status |
|---------|--------|
| Dashboard, Pipeline, Discovery, Import, Agent | ✅ Persistent (MySQL) |
| LLM enrichment, pitch generation | ✅ Claude API |
| Gmail send | ✅ googleapis OAuth |
| Playwright scraping | ✅ Direct |
| Snov.io | ✅ (already used axios) |
| SimilarWeb | ✅ (already used axios) |
| Notifications | ✅ Telegram |
| Ad detection | ✅ Direct Playwright |

Open `https://YOUR-PROJECT.up.railway.app` from your iPhone → full Kira, persistent, works from anywhere.
