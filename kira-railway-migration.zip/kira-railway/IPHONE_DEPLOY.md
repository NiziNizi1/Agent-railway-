# Quick Deploy from iPhone — Kira → Railway

הקובץ הזה הוא חבילת ההגירה. הוא **לא** Kira מלא — הוא רק הקבצים שצריך להחליף ב-Kira שלך.

## תהליך מהאייפון (15 דקות)

### שלב 1: הוצא את Kira מ-Manus

1. פתח את הפרויקט שלך ב-Manus (Safari)
2. Settings → Export Project → הורד ZIP

### שלב 2: צור GitHub repo

1. github.com → New Repository → "kira-railway" → Create
2. בעמוד החדש: "uploading an existing file"
3. העלה את ה-ZIP של Manus → Commit

### שלב 3: החלף את הקבצים מהחבילה הזו

ב-GitHub, לכל אחד מהקבצים האלה:

| בחבילה (קובץ במייל/הורדה) | שים ב-GitHub במיקום |
|--------------------------|----------------------|
| `server/_core/llm.ts` | `server/_core/llm.ts` (מחק את הישן) |
| `server/_core/notification.ts` | `server/_core/notification.ts` (מחק את הישן) |
| `server/mcp-integrations.ts` | `server/mcp-integrations.ts` (מחק את הישן) |
| `server/ad-detection.ts` | `server/ad-detection.ts` (מחק את הישן) |
| `Dockerfile` | בשורש (חדש) |
| `railway.json` | בשורש (חדש) |
| `.env.example` | בשורש (חדש) |
| `.gitignore` | בשורש (אם אין) |

ב-GitHub mobile: Edit file → מחק תוכן → הדבק חדש → Commit.

### שלב 4: עדכן package.json

הוסף בתוך `dependencies`:

```json
"@anthropic-ai/sdk": "^0.30.0",
"googleapis": "^144.0.0",
"playwright": "^1.48.0"
```

### שלב 5: Railway

1. railway.app → New Project → **Deploy from GitHub** → בחר `kira-railway`
2. **+ New** → Database → **MySQL** (Railway יחבר אוטומטית את DATABASE_URL)
3. בכרטיסיית **Variables** של ה-app, הדבק:

```
ANTHROPIC_API_KEY=sk-ant-...
SNOV_CLIENT_ID=...
SNOV_CLIENT_SECRET=...
GOOGLE_CLIENT_ID=...
GOOGLE_CLIENT_SECRET=...
GOOGLE_REFRESH_TOKEN=...
TELEGRAM_BOT_TOKEN=...
TELEGRAM_CHAT_ID=...
SESSION_SECRET=any-random-32-char-string
PORT=3000
```

4. Deploy יתחיל אוטומטית. כש-build מסתיים → Settings → Generate Domain
5. תקבל URL כמו `kira-xxx.up.railway.app` — פתח מהאייפון

### שלב 6: DB migration (פעם אחת)

ב-Railway → ה-app → Settings → **Deploy Trigger** → רוץ פעם אחת:
```
npx drizzle-kit push:mysql
```

או חבר Railway CLI מהמחשב פעם אחת.

---

## לקבל את המפתחות

### Anthropic
console.anthropic.com → Settings → API Keys → Create

### Gmail Refresh Token
1. console.cloud.google.com → New Project
2. APIs & Services → Enable **Gmail API**
3. Credentials → OAuth 2.0 Client ID (Desktop app)
4. developers.google.com/oauthplayground:
   - Settings (גלגל) → "Use your own OAuth credentials" → הדבק Client ID + Secret
   - בחר scope: `https://www.googleapis.com/auth/gmail.send`
   - Authorize APIs → Exchange authorization code for tokens
   - העתק את **Refresh token**

### Telegram (אופציונלי, לnotifications)
1. בטלגרם → @BotFather → /newbot → קבל TOKEN
2. שלח הודעה כלשהי לבוט
3. פתח: `api.telegram.org/bot<TOKEN>/getUpdates` → קח את `chat.id`

---

## אחרי deploy

- פתח את ה-URL מהאייפון
- הנתונים נשמרים ב-MySQL (לא נמחק כשאתה יוצא)
- כל הפיצ'רים של Kira עובדים: Discovery, Pipeline, Agent, Snov, Gmail send, Ad Detection
- כשתעדכן את ה-GitHub → Railway יבנה מחדש אוטומטית
