/**
 * Ad Network Detection — direct Playwright (no MCP CLI).
 * Drop-in replacement for original ad-detection.ts.
 */
import { chromium, Browser } from "playwright";

export interface DetectedAd {
  network: string;
  format: string;
  confidence: "high" | "medium" | "low";
  evidence: string;
}

export interface AdDetectionResult {
  detectedAds: DetectedAd[];
  scripts: string[];
  error?: string;
}

const AD_SIGNATURES: Array<{ network: string; format: string; patterns: string[] }> = [
  { network: "Monetag", format: "Pop-under", patterns: ["monetag.com", "trk.monetag", "d-aa.com", "mczbf.com"] },
  { network: "AdSterra", format: "Pop-under", patterns: ["adsterra.com", "astrfrm.com", "ad6media", "susession.com"] },
  { network: "PropellerAds", format: "Pop-under", patterns: ["propellerads.com", "propu.sh", "pushprofit.net"] },
  { network: "AdMaven", format: "Pop-under", patterns: ["admaven.com", "ad-maven.com", "admnv.com"] },
  { network: "PopAds", format: "Pop-under", patterns: ["popads.net", "serve.popads"] },
  { network: "PopCash", format: "Pop-under", patterns: ["popcash.net"] },
  { network: "Clickadu", format: "Pop-under", patterns: ["clickadu.com", "vfrfrm.com"] },
  { network: "AdCash", format: "Interstitial/Push", patterns: ["adcash.com", "surfe.pro"] },
  { network: "RichPush", format: "Push", patterns: ["richpush.com", "richpush.co"] },
  { network: "Pushground", format: "Push", patterns: ["pushground.com"] },
  { network: "Evadav", format: "Push/Native", patterns: ["evadav.com"] },
  { network: "Google AdSense", format: "Banner/Display", patterns: ["pagead2.googlesyndication.com", "adsbygoogle"] },
  { network: "Media.net", format: "Banner/Display", patterns: ["media.net", "contextual.media.net"] },
  { network: "Ezoic", format: "Banner/Display", patterns: ["ezoic.com", "ezoic.net", "ezodn.com"] },
  { network: "Infolinks", format: "Banner/In-text", patterns: ["infolinks.com"] },
  { network: "Taboola", format: "Native", patterns: ["taboola.com", "trc.taboola"] },
  { network: "Outbrain", format: "Native", patterns: ["outbrain.com", "widgets.outbrain.com"] },
  { network: "MGID", format: "Native", patterns: ["mgid.com", "servicer.mgid.com"] },
  { network: "RevContent", format: "Native", patterns: ["revcontent.com"] },
  { network: "ExoClick", format: "Video/Pop", patterns: ["exoclick.com", "exosrv.com"] },
  { network: "TrafficStars", format: "Video/Banner", patterns: ["trafficstars.com", "tsyndicate.com"] },
  { network: "JuicyAds", format: "Video/Banner", patterns: ["juicyads.com"] },
  { network: "HilltopAds", format: "Pop/Banner", patterns: ["hilltopads.com"] },
  { network: "TrafficForce", format: "Banner/Pop", patterns: ["trafficforce.com"] },
  { network: "Bidvertiser", format: "Banner/Pop", patterns: ["bidvertiser.com"] },
];

let browserInstance: Browser | null = null;

async function getBrowser(): Promise<Browser> {
  if (browserInstance && browserInstance.isConnected()) return browserInstance;
  browserInstance = await chromium.launch({ headless: true });
  return browserInstance;
}

export async function detectAdsOnWebsite(domain: string): Promise<AdDetectionResult> {
  const result: AdDetectionResult = { detectedAds: [], scripts: [] };
  let context: any = null;

  try {
    const browser = await getBrowser();
    context = await browser.newContext({ ignoreHTTPSErrors: true });
    const page = await context.newPage();

    // Capture network requests
    const networkRequests: string[] = [];
    page.on("request", (req: any) => networkRequests.push(req.url()));

    await page.goto(`https://${domain}`, { timeout: 30000, waitUntil: "domcontentloaded" });
    await page.waitForTimeout(3000);

    const pageData = await page.evaluate(() => {
      const scripts = Array.from(document.querySelectorAll("script[src]")).map((s: any) => s.src);
      const iframes = Array.from(document.querySelectorAll("iframe[src]")).map((f: any) => f.src);
      const inlineScripts = Array.from(document.querySelectorAll("script:not([src])"))
        .map((s: any) => (s.textContent || "").substring(0, 500));
      return { scripts, iframes, inlineScripts, html: document.documentElement.innerHTML.substring(0, 50000) };
    });

    const allUrls = [...pageData.scripts, ...pageData.iframes, ...networkRequests];
    const allContent = [...allUrls, ...pageData.inlineScripts, pageData.html].join(" ").toLowerCase();

    result.scripts = pageData.scripts.slice(0, 20);

    for (const sig of AD_SIGNATURES) {
      for (const pattern of sig.patterns) {
        const p = pattern.toLowerCase();
        if (allContent.includes(p)) {
          if (result.detectedAds.find((a) => a.network === sig.network)) break;
          let confidence: "high" | "medium" | "low" = "low";
          if (allUrls.some((u) => u.toLowerCase().includes(p))) confidence = "high";
          else if (pageData.inlineScripts.some((s) => s.toLowerCase().includes(p))) confidence = "medium";
          result.detectedAds.push({
            network: sig.network,
            format: sig.format,
            confidence,
            evidence: `Found "${pattern}" in page resources`,
          });
          break;
        }
      }
    }
  } catch (error: any) {
    result.error = error.message || "Ad detection failed";
  } finally {
    if (context) await context.close().catch(() => {});
  }

  return result;
}

export function getAdSignatures() {
  return AD_SIGNATURES.map((s) => ({ network: s.network, format: s.format }));
}
