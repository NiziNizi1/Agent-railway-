/**
 * Notification — replaces _core/notification (Manus owner notify).
 * Sends to your Telegram bot.
 */
import axios from "axios";

export interface NotifyParams {
  title: string;
  content: string;
}

export async function notifyOwner(params: NotifyParams): Promise<void> {
  const botToken = process.env.TELEGRAM_BOT_TOKEN;
  const chatId = process.env.TELEGRAM_CHAT_ID;

  if (!botToken || !chatId) {
    console.log(`[Notify] ${params.title}: ${params.content}`);
    return;
  }

  const text = `*${params.title}*\n\n${params.content}`;

  try {
    await axios.post(`https://api.telegram.org/bot${botToken}/sendMessage`, {
      chat_id: chatId,
      text,
      parse_mode: "Markdown",
    });
  } catch (error: any) {
    console.error("[Notify] Telegram failed:", error.message);
  }
}
