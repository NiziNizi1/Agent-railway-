/**
 * LLM wrapper — replaces Manus _core/llm.
 * Uses Anthropic Claude API directly with structured JSON output.
 */
import Anthropic from "@anthropic-ai/sdk";

const client = new Anthropic({ apiKey: process.env.ANTHROPIC_API_KEY });

export interface LLMMessage {
  role: "system" | "user" | "assistant";
  content: string;
}

export interface LLMRequest {
  messages: LLMMessage[];
  response_format?: {
    type: "json_schema";
    json_schema: {
      name: string;
      strict?: boolean;
      schema: any;
    };
  };
  model?: string;
  max_tokens?: number;
}

export interface LLMResponse {
  choices: Array<{
    message: { content: string };
  }>;
}

/**
 * Calls Claude with messages, optionally enforcing a JSON schema.
 * Returns OpenAI-compatible shape so existing routers.ts works unchanged.
 */
export async function invokeLLM(req: LLMRequest): Promise<LLMResponse> {
  const systemMsg = req.messages.find((m) => m.role === "system");
  const userMsgs = req.messages.filter((m) => m.role !== "system");

  let systemPrompt = systemMsg?.content || "";

  // If schema requested, append explicit JSON instruction
  if (req.response_format?.type === "json_schema") {
    const schema = req.response_format.json_schema.schema;
    systemPrompt += `\n\nYou MUST respond with valid JSON matching this exact schema:\n${JSON.stringify(
      schema,
      null,
      2
    )}\n\nReturn ONLY the JSON object, no markdown fences, no preamble.`;
  }

  const response = await client.messages.create({
    model: req.model || "claude-sonnet-4-5",
    max_tokens: req.max_tokens || 2048,
    system: systemPrompt,
    messages: userMsgs.map((m) => ({
      role: m.role as "user" | "assistant",
      content: m.content,
    })),
  });

  // Extract text content
  const textBlock = response.content.find((b) => b.type === "text");
  let content = textBlock && textBlock.type === "text" ? textBlock.text : "";

  // Strip markdown code fences if present
  content = content
    .replace(/^```(?:json)?\s*/i, "")
    .replace(/\s*```\s*$/, "")
    .trim();

  return {
    choices: [{ message: { content } }],
  };
}
