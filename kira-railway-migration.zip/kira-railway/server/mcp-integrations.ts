/**
 * Direct integrations — replaces mcp-integrations.ts (Manus MCP CLI).
 * - Gmail: googleapis OAuth2
 * - Scraping: Playwright direct
 * Works on Railway / VPS / any Node.js server.
 */
import { google } from "googleapis";
import { chromium, Browser } from "playwright";

// ─── Gmail Integration ──────────────────────────────────────────────────────

export interface SendEmailParams {
  to: string;
  subject: string;
  content: string;
  cc?: string[];
}

let oauth2Client: any = null;

function getOAuth2Client() {
  if (oauth2Client) return oauth2Client;
  oauth2Client = new google.auth.OAuth2(
    process.env.GOOGLE_CLIENT_ID,
    process.env.GOOGLE_CLIENT_SECRET,
    process.env.GOOGLE_REDIRECT_URI
  );
  if (process.env.GOOGLE_REFRESH_TOKEN) {
    oauth2Client.setCredentials({
      refresh_token: process.env.GOOGLE_REFRESH_TOKEN,
    });
  }
  return oauth2Client;
}

function buildEmail(params: SendEmailParams): string {
  const headers = [
    `To: ${params.to}`,
    params.cc?.length ? `Cc: ${params.cc.join(", ")}` : null,
    `Subject: ${params.subject}`,
    "Content-Type: text/html; charset=UTF-8",
    "MIME-Version: 1.0",
  ].filter(Boolean).join("\r\n");

  const message = `${headers}\r\n\r\n${params.content}`;
  return Buffer.from(message)
    .toString("base64")
    .replace(/\+/g, "-")
    .replace(/\//g, "_")
    .replace(/=+$/, "");
}

export async function sendEmailViaGmail(
  params: SendEmailParams
): Promise<{ success: boolean; error?: string }> {
  try {
    if (!process.env.GOOGLE_REFRESH_TOKEN) {
      return { success: false, error: "Gmail not configured (missing GOOGLE_REFRESH_TOKEN)" };
    }
    const auth = getOAuth2Client();
    const gmail = google.gmail({ version: "v1", auth });

    await gmail.users.messages.send({
      userId: "me",
      requestBody: { raw: buildEmail(params) },
    });

    return { success: true };
  } catch (error: any) {
    return { success: false, error: error.message || "Failed to send email" };
  }
}

// ─── Playwright Scraping (Direct) ───────────────────────────────────────────

export interface ScrapedContacts {
  emails: string[];
  phones: string[];
  socialLinks: string[];
  error?: string;
}

let browserInstance: Browser | null = null;

async function getBrowser(): Promise<Browser> {
  if (browserInstance && browserInstance.isConnected()) {
    return browserInstance;
  }
  browserInstance = await chromium.launch({ headless: true });
  return browserInstance;
}

const EMAIL_REGEX = /[a-zA-Z0-9._%+-]+@[a-zA-Z0-9.-]+\.[a-zA-Z]{2,}/g;
const PHONE_REGEX = /[\+]?[(]?[0-9]{1,4}[)]?[\-\s\.]?[0-9]{1,4}[\-\s\.]?[0-9]{4,6}/g;

const JUNK_DOMAINS = ["example.com", "wixpress", "sentry", "cloudflare", "googleapis", "schema.org"];
const JUNK_EXTENSIONS = [".png", ".jpg", ".jpeg", ".gif", ".svg", ".webp"];

function cleanEmails(raw: string[]): string[] {
  return [...new Set(raw)].filter((e) => {
    const lower = e.toLowerCase();
    if (JUNK_EXTENSIONS.some((ext) => lower.endsWith(ext))) return false;
    if (JUNK_DOMAINS.some((d) => lower.includes(d))) return false;
    if (lower.startsWith("noreply@") || lower.startsWith("no-reply@")) return false;
    if (lower.length > 80 || lower.length < 6) return false;
    return true;
  });
}

async function scrapePage(page: any, url: string): Promise<{
  emails: string[];
  phones: string[];
  socialLinks: string[];
  contactLinks: string[];
}> {
  const result = { emails: [], phones: [], socialLinks: [], contactLinks: [] } as any;
  try {
    const response = await page.goto(url, { timeout: 25000, waitUntil: "domcontentloaded" });
    if (!response || response.status() >= 400) return result;

    // Kill popups / overlays
    await page.evaluate(() => {
      document.querySelectorAll("div, section, aside").forEach((el: any) => {
        const s = window.getComputedStyle(el);
        if ((s.position === "fixed" || s.position === "sticky") && parseInt(s.zIndex || "0") > 100) {
          el.remove();
        }
      });
      document.body.style.overflow = "auto";
    });

    const data = await page.evaluate(() => {
      const text = document.body.innerText || "";
      const html = document.body.innerHTML || "";
      const links = Array.from(document.querySelectorAll("a[href]")).map((a: any) => a.href);

      return { text, html, links };
    });

    // Deobfuscate then extract emails
    const deobfuscated = data.text
      .replace(/\s*\[\s*at\s*\]\s*/gi, "@")
      .replace(/\s*\(\s*at\s*\)\s*/gi, "@")
      .replace(/\s+at\s+/gi, "@")
      .replace(/\s*\[\s*dot\s*\]\s*/gi, ".")
      .replace(/\s*\(\s*dot\s*\)\s*/gi, ".")
      .replace(/\s+dot\s+/gi, ".");

    result.emails = (deobfuscated.match(EMAIL_REGEX) || []).concat(
      data.html.match(EMAIL_REGEX) || []
    );

    result.phones = (data.text.match(PHONE_REGEX) || []).filter((p: string) => p.length >= 7);

    result.socialLinks = data.links.filter(
      (h: string) =>
        h.includes("linkedin.com") ||
        h.includes("twitter.com") ||
        h.includes("t.me") ||
        h.includes("facebook.com")
    );

    result.contactLinks = data.links.filter((h: string) => {
      const lower = h.toLowerCase();
      return lower.includes("contact") || lower.includes("about") || lower.includes("advertis");
    });
  } catch {
    /* ignore */
  }
  return result;
}

export async function scrapeContactsFromWebsite(domain: string): Promise<ScrapedContacts> {
  const result: ScrapedContacts = { emails: [], phones: [], socialLinks: [] };
  let context: any = null;

  try {
    const browser = await getBrowser();
    context = await browser.newContext({
      ignoreHTTPSErrors: true,
      userAgent:
        "Mozilla/5.0 (Windows NT 10.0; Win64; x64) AppleWebKit/537.36 (KHTML, like Gecko) Chrome/124.0.0.0 Safari/537.36",
    });

    // Block ad / tracker requests
    await context.route("**/*", (route: any) => {
      const url = route.request().url().toLowerCase();
      if (
        url.includes("doubleclick") ||
        url.includes("googlesyndication") ||
        url.includes("propellerads") ||
        url.includes("adsterra")
      ) {
        return route.abort();
      }
      return route.continue();
    });

    const page = await context.newPage();

    // Homepage
    const home = await scrapePage(page, `https://${domain}`);
    result.emails.push(...home.emails);
    result.phones.push(...home.phones);
    result.socialLinks.push(...home.socialLinks);

    // /ads.txt for CONTACT= directives
    try {
      const adsResp = await context.request.get(`https://${domain}/ads.txt`);
      if (adsResp.ok()) {
        const text = await adsResp.text();
        for (const line of text.split("\n")) {
          if (line.toLowerCase().startsWith("contact=")) {
            const v = line.split("=", 2)[1]?.trim();
            if (v && v.includes("@")) result.emails.push(v.toLowerCase());
          }
        }
        result.emails.push(...(text.match(EMAIL_REGEX) || []));
      }
    } catch {
      /* ignore */
    }

    // Contact page
    if (home.contactLinks.length > 0) {
      const contact = await scrapePage(page, home.contactLinks[0]);
      result.emails.push(...contact.emails);
      result.phones.push(...contact.phones);
      result.socialLinks.push(...contact.socialLinks);
    }

    result.emails = cleanEmails(result.emails);
    result.phones = [...new Set(result.phones)];
    result.socialLinks = [...new Set(result.socialLinks)];
  } catch (error: any) {
    result.error = error.message || "Scraping failed";
  } finally {
    if (context) await context.close().catch(() => {});
  }

  return result;
}
